Замена звуков записями
======================
Положите сюда WAV-файл с именем звука, и игра возьмёт его вместо синтезированного.
Несколько вариантов (игра чередует их случайно): имя_1.wav, имя_2.wav ... имя_8.wav.
Поддерживается PCM 8/16/24/32 бит и float, моно/стерео, любая частота (пересчитывается в 48 кГц).
Громкость подгоняется автоматически под уровень встроенного звука.

Имена: ak47 m4a4 awp deagle glock usp knife_swing knife_hit knife_stab empty reload_out reload_in bolt deploy zoom
step0 (камень/бетон) step1 (песок) step2 (дерево) step3 (металл) jump land hit_body hit_head helmet
impact_stone impact_wood impact_metal impact_sand explosion smoke flash bounce throw beep planted defused
round_start round_win round_lose ui_hover ui_click buy pickup shell kill

Где брать бесплатно: freesound.org (фильтр лицензии CC0), Sonniss GDC Game Audio Bundle (royalty-free), 
opengameart.org. Звуки из самой CS2 защищены авторским правом, их использовать нельзя.
