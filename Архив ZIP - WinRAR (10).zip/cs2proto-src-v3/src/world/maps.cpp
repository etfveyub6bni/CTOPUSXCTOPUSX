// Map content. Units are Hammer units (1 unit = 1 inch), Z up.
#include "assets/textures.h"
#include "world/map_builder.h"

namespace {

uint32_t rgb(float r, float g, float b) { return MapBuilder::rgb(r, g, b); }

void door(MapBuilder& b, vec3 hinge, float len, float yawDeg, float height) {
    vec3 dir(std::cos(yawDeg * kDeg), std::sin(yawDeg * kDeg), 0);
    b.obox(hinge + dir * (len * 0.5f) + vec3(0, 0, height * 0.5f), {len * 0.5f, 3.5f, height * 0.5f}, yawDeg, MAT_DOOR);
}

void barrel(MapBuilder& b, float x, float y, uint32_t tint) {
    Brush& br = b.prism(x, y, 16, 10, 0, 50, MAT_METAL);
    br.tint = tint;
}

void buildDust(GameMap& m) {
    m.info.id = "dust";
    m.info.title = "Dust II";
    m.info.subtitle = "Классика: длинный A, мид, туннели B";
    m.info.env = Environment();
    m.info.lobbyCamPos = {1480, 1260, 140};
    m.info.lobbyCamPitch = -6;
    m.info.lobbyCamYaw = 150;
    m.info.thumbPos = {1500, -880, 190};
    m.info.thumbPitch = -8;
    m.info.thumbYaw = 98;

    MapBuilder b(m, -2048, -2176, 2048, 2048, 32);
    b.wallStyle(-2048, -2176, 2048, 2048, 288, MAT_PLASTER, MAT_SANDSTONE, 80);
    b.wallStyle(-1728, -2112, -1024, -320, 320, MAT_SANDSTONE, MAT_TRIM, 40);
    b.wallStyle(1088, -2112, 1856, 400, 256, MAT_SANDSTONE, MAT_TRIM, 40);
    b.wallStyle(-640, 1216, 736, 2048, 320, MAT_PLASTER, MAT_TRIM, 56);

    // T spawn and the route to Long.
    b.carve(-640, -2048, 704, -1600, 0, MAT_SAND);
    b.carve(704, -1984, 1152, -1664, 0, MAT_SAND);
    b.carve(1152, -1984, 1600, -1056, 0, MAT_SAND);
    b.carve(1280, -1056, 1440, -992, 0, MAT_TILES);
    b.roof(1280, -1056, 1440, -992, 144, MAT_TRIM);
    // Long A and A site.
    b.carve(1152, -992, 1792, 320, 0, MAT_SAND);
    b.carve(1216, 320, 1792, 1024, 0, MAT_SAND);
    b.carve(640, 1024, 1792, 1920, 0, MAT_TILES);
    b.carve(832, 1216, 1600, 1856, 48, MAT_TILES);
    // Mid, mid doors, CT mid, CT spawn.
    b.carve(-128, -1600, 128, -1536, 0, MAT_SAND);
    b.carve(-256, -1536, 256, 832, 0, MAT_SAND);
    b.carve(-96, 832, 96, 896, 0, MAT_TILES);
    b.roof(-96, 832, 96, 896, 144, MAT_TRIM);
    b.carve(-256, 896, 256, 1280, 0, MAT_TILES);
    b.carve(-576, 1280, 448, 1920, 0, MAT_TILES);
    b.carve(448, 1280, 704, 1600, 0, MAT_TILES);
    // Catwalk / short A (raised).
    b.carve(256, -96, 320, 64, 0, MAT_TILES);
    b.carve(320, -96, 512, 832, 64, MAT_TILES);
    b.carve(512, 640, 704, 832, 64, MAT_TILES);
    b.carve(576, 832, 704, 1024, 0, MAT_TILES);
    // CT -> B with B doors.
    b.carve(-1216, 1408, -576, 1728, 0, MAT_TILES);
    b.fill(-1024, 1408, -960, 1728);
    b.carve(-1024, 1472, -960, 1664, 0, MAT_TILES);
    b.roof(-1024, 1472, -960, 1664, 160, MAT_TRIM);
    // B site with back platform.
    b.carve(-1920, 640, -1216, 1920, 0, MAT_TILES);
    b.carve(-1920, 1600, -1600, 1920, 32, MAT_TILES);
    // Tunnels.
    b.carve(-1152, -1984, -640, -1728, 0, MAT_SAND);
    b.carve(-1600, -1984, -1152, -448, 0, MAT_COBBLE);
    b.roof(-1600, -1792, -1152, -448, 176, MAT_TRIM);
    b.carve(-1600, -448, -1344, 640, 0, MAT_COBBLE);
    b.roof(-1600, -448, -1344, 320, 176, MAT_TRIM);
    b.carve(-1152, -960, -256, -768, 0, MAT_COBBLE);
    b.roof(-1152, -960, -384, -768, 144, MAT_TRIM);

    // Ramps and stairs.
    b.wedge({1600, 1344, 0}, {1728, 1600, 48}, 1, MAT_TILES);
    b.stairs(896, 1120, 1088, 1216, 0, 3, 16, 2, MAT_TRIM);
    b.stairs(192, -96, 320, 64, 0, 4, 16, 0, MAT_TRIM);
    b.wedge({576, 832, 0}, {704, 1024, 64}, 3, MAT_TILES);
    b.stairs(-1856, 1536, -1664, 1600, 0, 2, 16, 2, MAT_TRIM);

    // Doors.
    door(b, {-96, 896, 0}, 92, 90, 136);
    door(b, {96, 896, 0}, 92, 135, 136);
    door(b, {1280, -992, 0}, 78, 90, 140);
    door(b, {1440, -992, 0}, 78, 125, 140);
    door(b, {-1024, 1472, 0}, 92, 200, 150);
    door(b, {-1024, 1664, 0}, 92, 160, 150);

    // Cover.
    b.crate(-560, -1690, 0, 64);
    b.crate(-496, -1690, 0, 64);
    b.crate(-528, -1690, 64, 56, 14);
    b.crate(420, -1760, 0, 64, 12);
    b.crate(0, -712, 0, 64);
    b.crate(-60, -690, 0, 48, 20);
    b.crate(-200, 740, 0, 64);
    b.crate(1240, -560, 0, 64);
    b.crate(1240, -496, 0, 64);
    b.crate(1240, -528, 64, 64);
    b.crate(1700, -300, 0, 64, 20);
    b.crate(1728, 240, 0, 64);
    b.crate(1728, 176, 0, 64);
    b.crate(1150, 1500, 48, 64);
    b.crate(1214, 1500, 48, 64);
    b.crate(1182, 1500, 112, 52, 15);
    b.crate(1540, 1790, 48, 64);
    b.crate(1476, 1790, 48, 64);
    b.crate(330, 1856, 0, 64);
    b.crate(394, 1856, 0, 64);
    b.crate(362, 1856, 64, 64);
    b.crate(-400, 1480, 0, 64, 30);
    b.crate(-1500, 1150, 0, 64);
    b.crate(-1436, 1150, 0, 64);
    b.crate(-1468, 1150, 64, 64);
    b.crate(-1330, 1560, 0, 64, 20);
    b.crate(-1780, 880, 0, 64);
    b.crate(-1420, -1260, 0, 64);
    b.box({-1700, 1250, 0}, {-1604, 1346, 80}, MAT_TRIM);
    barrel(b, 720, 1150, rgb(0.55f, 0.18f, 0.12f));
    barrel(b, 756, 1186, rgb(0.25f, 0.33f, 0.45f));
    barrel(b, -1260, 760, rgb(0.55f, 0.18f, 0.12f));
    barrel(b, 1660, -760, rgb(0.30f, 0.40f, 0.28f));
    // A car.
    uint32_t carTint = rgb(0.62f, 0.24f, 0.16f);
    b.box({1300, 640, 14}, {1460, 720, 50}, MAT_METAL, carTint);
    b.box({1336, 646, 50}, {1420, 714, 80}, MAT_METAL, carTint);
    for (float wx : {1320.0f, 1440.0f})
        for (float wy : {640.0f, 720.0f}) b.box({wx - 12, wy - 6, 0}, {wx + 12, wy + 6, 24}, MAT_METAL, rgb(0.12f, 0.12f, 0.12f));

    for (int i = 0; i < 10; i++) {
        b.spawn(TEAM_T, -256.0f + (i % 5) * 128.0f, -1920.0f + (i / 5) * 120.0f, 0, 90);
        b.spawn(TEAM_CT, -384.0f + (i % 5) * 128.0f, 1640.0f + (i / 5) * 120.0f, 0, -90);
    }
    b.site('A', 832, 1216, 1600, 1856);
    b.site('B', -1856, 704, -1280, 1856);
    b.finish();
}

void buildArena(GameMap& m) {
    m.info.id = "arena";
    m.info.title = "Arena";
    m.info.subtitle = "Контейнерный двор на закате";
    Environment e;
    e.sunDir = normalize(vec3(-0.62f, 0.35f, 0.34f));
    e.sunColor = vec3(1.0f, 0.72f, 0.48f) * 3.4f;
    e.skyZenith = {0.16f, 0.26f, 0.50f};
    e.skyHorizon = {0.90f, 0.62f, 0.44f};
    e.groundColor = {0.30f, 0.25f, 0.22f};
    e.fogColor = {0.78f, 0.60f, 0.50f};
    e.fogDensity = 0.00008f;
    e.grade = {1.04f, 0.99f, 0.94f};
    e.cloudiness = 0.55f;
    m.info.env = e;
    m.info.lobbyCamPos = {-900, -700, 150};
    m.info.lobbyCamPitch = -5;
    m.info.lobbyCamYaw = 40;
    m.info.thumbPos = {-1000, -1000, 260};
    m.info.thumbPitch = -10;
    m.info.thumbYaw = 45;

    MapBuilder b(m, -1344, -1344, 1344, 1344, 32);
    b.wallStyle(-1344, -1344, 1344, 1344, 256, MAT_CONCRETE, MAT_BRICK, 96);
    b.carve(-1152, -1152, 1152, 1152, 0, MAT_CONCRETE);
    b.carve(-256, -256, 256, 256, 64, MAT_CONCRETE);
    b.wedge({-96, 256, 0}, {96, 448, 64}, 3, MAT_CONCRETE);
    b.wedge({-96, -448, 0}, {96, -256, 64}, 2, MAT_CONCRETE);
    b.stairs(256, -64, 384, 64, 0, 4, 16, 1, MAT_TRIM);
    b.stairs(-384, -64, -256, 64, 0, 4, 16, 0, MAT_TRIM);

    auto container = [&](float x, float y, bool alongY, uint32_t tint, float z) {
        vec3 h = alongY ? vec3(60, 150, 64) : vec3(150, 60, 64);
        b.box({x - h.x, y - h.y, z}, {x + h.x, y + h.y, z + 128}, MAT_CORRUGATED, tint);
    };
    uint32_t red = rgb(0.62f, 0.17f, 0.12f), blue = rgb(0.16f, 0.33f, 0.58f), green = rgb(0.22f, 0.44f, 0.27f);
    uint32_t orange = rgb(0.85f, 0.47f, 0.14f), grey = rgb(0.58f, 0.59f, 0.60f);
    container(-640, 360, true, red, 0);
    container(640, -360, true, red, 0);
    container(640, 360, true, blue, 0);
    container(-640, -360, true, blue, 0);
    container(-880, 880, false, green, 0);
    container(-880, 880, false, orange, 128);
    container(880, -880, false, green, 0);
    container(880, -880, false, orange, 128);
    container(880, 880, false, grey, 0);
    container(-880, -880, false, grey, 0);
    container(0, 780, false, blue, 0);
    container(0, -780, false, red, 0);
    b.crate(-420, 0, 0, 64);
    b.crate(420, 0, 0, 64, 25);
    b.crate(-300, 620, 0, 64, 10);
    b.crate(300, -620, 0, 64, -10);
    b.crate(900, 300, 0, 64);
    b.crate(900, 364, 0, 64);
    b.crate(-900, -300, 0, 64);
    b.crate(-900, -364, 0, 64);
    b.crate(-160, 160, 64, 48, 30);
    b.crate(160, -160, 64, 48, 60);
    barrel(b, -1080, 520, rgb(0.20f, 0.30f, 0.50f));
    barrel(b, 1080, -520, rgb(0.55f, 0.18f, 0.12f));

    for (int i = 0; i < 10; i++) {
        b.spawn(TEAM_T, -320.0f + (i % 5) * 160.0f, -1060.0f + (i / 5) * 70.0f, 0, 90);
        b.spawn(TEAM_CT, -320.0f + (i % 5) * 160.0f, 1060.0f - (i / 5) * 70.0f, 0, -90);
    }
    b.site('A', 500, -300, 1100, 300);
    b.site('B', -1100, -300, -500, 300);
    b.finish();
}


// Fortress: a large symmetric "base vs base" map. Each team starts in a walled fort with a rampart along the front
// wall (shoot out of the base over the parapet), three exits (north gate, mid gate, south gate) and three routes
// across: the open north road (to A), the mid road with a central ruin, and the covered south tunnels (to B).
void buildFortress(GameMap& m) {
    m.info.id = "fortress";
    m.info.title = "Fortress";
    m.info.subtitle = "База против базы, 3 маршрута";
    Environment e;
    e.sunDir = normalize(vec3(0.52f, 0.30f, 0.62f));
    e.sunColor = vec3(1.0f, 0.82f, 0.62f) * 3.9f;
    e.skyZenith = {0.14f, 0.30f, 0.72f};
    e.skyHorizon = {0.66f, 0.70f, 0.80f};
    e.groundColor = {0.44f, 0.35f, 0.25f};
    e.fogColor = {0.72f, 0.72f, 0.76f};
    e.fogDensity = 0.00005f;
    e.cloudiness = 0.45f;
    m.info.env = e;
    m.info.lobbyCamPos = {2240, 1500, 150};
    m.info.lobbyCamPitch = -4;
    m.info.lobbyCamYaw = 200;
    m.info.thumbPos = {3000, 1780, 260};
    m.info.thumbPitch = -9;
    m.info.thumbYaw = 190;

    const float X = 3584, Y = 2304;
    MapBuilder b(m, -X, -Y, X, Y, 32);
    // Mirror helpers: every piece of layout exists on the T side (x < 0) and the CT side (x > 0).
    auto carveM = [&](float x0, float y0, float x1, float y1, float z, int mat) {
        b.carve(x0, y0, x1, y1, z, mat);
        b.carve(-x1, y0, -x0, y1, z, mat);
    };
    auto roofM = [&](float x0, float y0, float x1, float y1, float z, int mat) {
        b.roof(x0, y0, x1, y1, z, mat);
        b.roof(-x1, y0, -x0, y1, z, mat);
    };
    auto styleM = [&](float x0, float y0, float x1, float y1, float top, int mat, int lower, float band) {
        b.wallStyle(x0, y0, x1, y1, top, mat, lower, band);
        b.wallStyle(-x1, y0, -x0, y1, top, mat, lower, band);
    };
    auto stairsM = [&](float x0, float y0, float x1, float y1, int steps, float rise, int dir) {
        b.stairs(x0, y0, x1, y1, 0, steps, rise, dir, MAT_TRIM);
        int md = dir == 0 ? 1 : dir == 1 ? 0 : dir;
        b.stairs(-x1, y0, -x0, y1, 0, steps, rise, md, MAT_TRIM);
    };
    auto crateM = [&](float x, float y, float z, float size, float yaw = 0) {
        b.crate(x, y, z, size, yaw);
        b.crate(-x, y, z, size, -yaw);
    };
    auto boxM = [&](vec3 mn, vec3 mx, int mat, uint32_t tint) {
        b.box(mn, mx, mat, tint);
        b.box({-mx.x, mn.y, mn.z}, {-mn.x, mx.y, mx.z}, mat, tint);
    };

    // Wall styles: town walls between routes, tall fortress walls, low parapet in front of each rampart.
    b.wallStyle(-X, -Y, X, Y, 288, MAT_PLASTER, MAT_SANDSTONE, 72);
    styleM(-X, -1152, -2560, 1152, 400, MAT_SANDSTONE, MAT_BRICK, 56);
    styleM(-2560, -1024, -2496, 1024, 200, MAT_SANDSTONE, MAT_TRIM, 30);
    styleM(-1300, -2304, 1300, -1250, 320, MAT_CONCRETE, MAT_BRICK, 64);

    // --- Bases (T on the west, mirrored CT on the east).
    carveM(-3392, -960, -2688, 960, 0, MAT_COBBLE);              // courtyard
    carveM(-2688, -960, -2560, 960, 160, MAT_TILES);             // rampart walkway behind the parapet
    carveM(-2688, -160, -2432, 160, 0, MAT_COBBLE);              // mid gate through the rampart
    roofM(-2688, -160, -2432, 160, 136, MAT_TRIM);               // gate arch (flush with the rampart)
    carveM(-3264, 960, -2944, 1344, 0, MAT_COBBLE);              // north gate
    roofM(-3264, 1024, -2944, 1216, 176, MAT_TRIM);
    carveM(-3264, -1344, -2944, -960, 0, MAT_COBBLE);            // south gate
    roofM(-3264, -1216, -2944, -1024, 176, MAT_TRIM);
    roofM(-3392, -352, -3136, 352, 192, MAT_TRIM);               // covered armoury at the back of the fort
    // Stairs up to both halves of the rampart.
    stairsM(-2912, 704, -2688, 832, 10, 16, 0);
    stairsM(-2912, -832, -2688, -704, 10, 16, 0);
    // Tower platforms in the front corners of the fort.
    carveM(-2816, 832, -2688, 960, 160, MAT_TILES);
    carveM(-2816, -960, -2688, -832, 160, MAT_TILES);

    // Open field in front of each fort: the rampart overlooks it, low walls and crates give attackers cover.
    carveM(-2496, -1024, -1792, 1024, 0, MAT_SAND);
    for (float y : {-620.0f, 620.0f}) boxM({-2140, y - 110, 0}, {-2104, y + 110, 52}, MAT_SANDSTONE, 0xFFFFFFFFu);
    boxM({-1930, 340, 0}, {-1894, 520, 52}, MAT_SANDSTONE, 0xFFFFFFFFu);
    boxM({-1930, -520, 0}, {-1894, -340, 52}, MAT_SANDSTONE, 0xFFFFFFFFu);
    crateM(-2320, 820, 0, 64, 12);
    crateM(-2320, -820, 0, 64);
    crateM(-2256, -820, 0, 64, 20);
    crateM(-1880, 900, 0, 64);

    // --- North road (open, long sightlines) and south tunnels.
    b.carve(-3264, 1344, 3264, 1920, 0, MAT_SAND);
    b.carve(-3264, -1920, 3264, -1344, 0, MAT_COBBLE);
    b.roof(-1280, -1920, 1280, -1344, 192, MAT_TRIM);
    b.carve(-256, -1344, 256, -1280, 0, MAT_COBBLE);               // lights in the tunnel ceiling gap
    // Raised dune in the middle of the north road with ramps.
    b.carve(-512, 1600, 512, 1920, 48, MAT_SAND);
    b.wedge({512, 1600, 0}, {704, 1920, 48}, 1, MAT_SAND);
    b.wedge({-704, 1600, 0}, {-512, 1920, 48}, 0, MAT_SAND);

    // --- Sites plazas (CT side holds the bomb sites; the T side has matching open yards).
    carveM(-2688, 1088, -1664, 2176, 0, MAT_TILES);
    carveM(-2560, 1792, -2048, 2176, 48, MAT_TILES);
    b.wedge({1920, 1792, 0}, {2048, 1984, 48}, 0, MAT_TILES);
    b.wedge({-2048, 1792, 0}, {-1920, 1984, 48}, 1, MAT_TILES);
    carveM(-2688, -2176, -1664, -1088, 0, MAT_TILES);
    carveM(-2560, -2176, -2048, -1792, 32, MAT_TILES);
    stairsM(-2048, -2048, -1920, -1856, 2, 16, 1);

    // --- Mid road, central plaza with a ruined block, cross alleys between the routes.
    b.carve(-2432, -256, 2432, 256, 0, MAT_SAND);
    b.carve(-704, -768, 704, 768, 0, MAT_TILES);
    b.fill(-224, -224, 224, 224);
    b.wallStyle(-224, -224, 224, 224, 256, MAT_PLASTER, MAT_BRICK, 96);
    b.carve(-96, 768, 96, 1344, 0, MAT_TILES);                      // mid doors to the north road
    b.roof(-96, 896, 96, 992, 144, MAT_TRIM);
    b.carve(-96, -1280, 96, -768, 0, MAT_COBBLE);                   // stairs down to the tunnels
    b.roof(-96, -1280, 96, -896, 160, MAT_TRIM);
    carveM(-1600, 256, -1408, 1344, 0, MAT_SAND);                   // north alleys
    carveM(-1600, -1344, -1408, -256, 0, MAT_COBBLE);               // south alleys
    roofM(-1600, -1120, -1408, -864, 160, MAT_TRIM);
    carveM(-2240, 256, -2048, 704, 0, MAT_SAND);                    // side yard near each base
    carveM(-2240, 704, -1664, 896, 0, MAT_SAND);
    carveM(-1856, 896, -1664, 1088, 0, MAT_SAND);

    // Doors.
    door(b, {-96, 992, 0}, 92, 90 - 45, 136);
    door(b, {96, 992, 0}, 92, 90 + 45, 136);

    // Cover: base courtyard crates, gate cover, road clutter, site boxes.
    crateM(-3200, 560, 0, 64);
    crateM(-3136, 560, 0, 64);
    crateM(-3168, 560, 64, 56, 12);
    crateM(-3200, -560, 0, 64, 18);
    crateM(-2880, 320, 0, 64);
    crateM(-2880, -320, 0, 64, 25);
    crateM(-2300, 90, 0, 64);
    crateM(-2300, -40, 0, 48, 20);
    crateM(-1900, -150, 0, 64);
    crateM(-1250, 150, 0, 64, 15);
    crateM(-1250, 86, 0, 64);
    crateM(-800, -140, 0, 64);
    crateM(-500, 560, 0, 64);
    crateM(-436, 560, 0, 64);
    crateM(-468, 560, 64, 56, 10);
    crateM(-500, -560, 0, 64, 30);
    crateM(-2300, 1500, 0, 64);
    crateM(-2236, 1500, 0, 64);
    crateM(-2268, 1500, 64, 64);
    crateM(-1900, 1300, 0, 64, 20);
    crateM(-1760, 1980, 0, 64);
    crateM(-1400, 1700, 0, 64);
    crateM(-1000, 1420, 0, 64, 18);
    crateM(-1000, 1484, 0, 64);
    crateM(-2300, -1500, 0, 64);
    crateM(-2236, -1500, 0, 64);
    crateM(-2268, -1500, 64, 64, 8);
    crateM(-1850, -1300, 0, 64, 15);
    crateM(-2380, -1950, 32, 64);
    crateM(-1000, -1640, 0, 64);
    crateM(-600, -1450, 0, 64, 22);
    crateM(-1560, 600, 0, 48);
    crateM(-1450, -700, 0, 64);
    uint32_t red = rgb(0.55f, 0.18f, 0.12f), blue = rgb(0.25f, 0.33f, 0.45f), olive = rgb(0.30f, 0.40f, 0.28f);
    for (float sx : {-1.0f, 1.0f}) {
        barrel(b, sx * 3000, 880, red);
        barrel(b, sx * 3040, 850, blue);
        barrel(b, sx * 2140, 600, olive);
        barrel(b, sx * 1200, 1860, red);
        barrel(b, sx * 1700, -1400, blue);
    }
    // Wrecked trucks on the north road.
    uint32_t truck = rgb(0.34f, 0.38f, 0.30f), rust = rgb(0.52f, 0.28f, 0.16f);
    boxM({-1260, 1560, 14}, {-1020, 1650, 70}, MAT_METAL, truck);
    boxM({-1260, 1566, 70}, {-1170, 1644, 118}, MAT_METAL, truck);
    boxM({700, 1400, 12}, {860, 1480, 50}, MAT_METAL, rust);
    // Sandbag walls on each rampart (extra cover while shooting from the base).
    for (float y : {-620.0f, -380.0f, 380.0f, 620.0f}) boxM({-2600, y - 48, 160}, {-2572, y + 48, 196}, MAT_SANDSTONE, 0xFFFFFFFFu);

    for (int i = 0; i < 10; i++) {
        float yy = -256.0f + (i % 5) * 128.0f, xx = -3280.0f + (i / 5) * 120.0f;
        b.spawn(TEAM_T, xx, yy, 0, 0);
        b.spawn(TEAM_CT, -xx, yy, 0, 180);
    }
    b.site('A', 1664, 1088, 2688, 2176);
    b.site('B', 1664, -2176, 2688, -1088);
    b.finish();
}

}  // namespace

const std::vector<MapListEntry>& mapList() {
    static const std::vector<MapListEntry> list = {
        {"dust", "Dust II", "Классика: длинный A, мид, туннели B"},
        {"arena", "Arena", "Контейнерный двор на закате"},
        {"fortress", "Fortress", "База против базы, 3 маршрута"},
    };
    return list;
}

bool buildMapById(const std::string& id, GameMap& m) {
    if (id == "dust") buildDust(m);
    else if (id == "arena") buildArena(m);
    else if (id == "fortress") buildFortress(m);
    else return false;
    return true;
}
