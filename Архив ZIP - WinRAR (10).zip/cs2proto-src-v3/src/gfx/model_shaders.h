// GLSL for skinned/rigid models (weapons, arms, agents). Linked after kNoise and kLighting from shaders.h.
#pragma once

namespace glsl {

inline const char* kModelVS = R"GLSL(
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec4 aColor;
layout(location = 3) in vec4 aMat;
layout(location = 4) in vec4 aExtra;
uniform mat4 uViewProj;
uniform mat4 uModel;
uniform mat4 uBones[48];
out vec3 vPos; out vec3 vNormal; out vec3 vObj; out vec4 vColor; out vec3 vMat; out vec2 vWear;
void main() {
    int b = int(aMat.w * 255.0 + 0.5);
    mat4 M = uModel * uBones[b];
    vec4 wp = M * vec4(aPos, 1.0);
    vPos = wp.xyz;
    vNormal = mat3(M) * aNormal;
    vObj = aPos; vColor = aColor; vMat = aMat.xyz; vWear = aExtra.xy;
    gl_Position = uViewProj * wp;
}
)GLSL";

inline const char* kModelFS = R"GLSL(
uniform vec4 uTint;
uniform vec3 uAmbUp;
uniform vec3 uAmbDown;
uniform float uIsViewmodel;
uniform vec3 uPatternA;
uniform vec3 uPatternB;
in vec3 vPos; in vec3 vNormal; in vec3 vObj; in vec4 vColor; in vec3 vMat; in vec2 vWear;
out vec4 oColor;
vec3 toLinear(vec3 c) { return pow(c, vec3(2.2)); }

// Bump mapping without tangents: perturbs N by the screen-space gradient of a height in world units.
// Derivatives must be taken in uniform control flow (outside the per-material branches), otherwise
// they are undefined at material borders inside a pixel quad and can produce NaNs.
vec3 bumpNormal(vec3 N, float h, vec3 dpdx, vec3 dpdy) {
    vec3 r1 = cross(dpdy, N), r2 = cross(N, dpdx);
    float det = dot(dpdx, r1);
    vec3 grad = sign(det) * (dFdx(h) * r1 + dFdy(h) * r2);
    float gl = length(grad), lim = abs(det) * 0.8;  // caps the tilt (height jumps at material borders)
    if (gl > lim) grad *= lim / max(gl, 1e-30);
    vec3 n = abs(det) * N - grad;
    float len = length(n);
    // Tiny or degenerate footprints (and material borders) fall back to the smooth normal.
    if (!(len > 1e-20) || abs(det) < 1e-16) return N;
    n /= len;
    return dot(n, N) < 0.2 ? N : n;
}
float g_pixelFootprint;
// Light probes are dominated by the blue sky; used raw they tint steel and gloves blue/purple.
// Models get probes with most of the chroma removed and a slight warm bias from sunlit ground bounce.
vec3 g_ambUp, g_ambDown;
vec3 neutralAmb(vec3 a, float k) {
    float l = dot(a, vec3(0.3, 0.59, 0.11));
    return mix(a, vec3(l) * vec3(1.03, 1.0, 0.95), k);
}
// Fades detail whose period is close to the pixel footprint (avoids sparkle).
float detailFade(float period) { return 1.0 - smoothstep(0.35, 1.0, g_pixelFootprint / period); }
float weave(vec3 q, float f) {
    return sin(q.x * f + sin(q.z * f * 0.5) * 0.5) * sin((q.y + q.z) * f);
}


// Scratches: short, tapered, randomly placed segments with a preferred direction per layer (handling marks run
// in bundles). Width never drops below the pixel footprint; thinner scratches get fainter instead of aliasing.
float scratchLayer(vec2 p, float seed, float dirBias, float width) {
    vec2 c = floor(p);
    float s = 0.0;
    for (int j = -1; j <= 1; j++)
        for (int i = -1; i <= 1; i++) {
            vec2 cell = c + vec2(float(i), float(j));
            float h = hash12(cell + seed);
            if (h > 0.6) continue;
            vec2 o = vec2(hash12(cell + seed + 7.13), hash12(cell + seed + 3.37));
            float ang = dirBias + (hash12(cell + seed + 11.7) - 0.5) * 1.3;
            vec2 d = vec2(cos(ang), sin(ang));
            float len = 0.35 + 1.1 * hash12(cell + seed + 5.91);
            vec2 a = cell + o - d * len * 0.5;
            vec2 pa = p - a;
            float t = clamp(dot(pa, d), 0.0, len);
            float dist = length(pa - d * t);
            float w0 = width * (0.4 + hash12(cell + seed + 19.3));
            float w = max(w0, g_pixelFootprint * 0.9);
            float taper = sin(3.14159 * t / len);
            s = max(s, (1.0 - smoothstep(0.0, w, dist)) * taper * (w0 / w) * (0.5 + 0.5 * h / 0.6));
        }
    return s;
}
float scratches(vec3 q, vec3 on) {
    vec3 an = abs(on);
    vec2 p = an.x > an.y && an.x > an.z ? q.yz : (an.y > an.z ? q.xz : q.xy);
    float s = scratchLayer(p * 0.9, 1.7, 0.15, 0.010);
    s = max(s, scratchLayer(p * 2.1 + 13.0, 9.3, 1.9, 0.018) * 0.7);
    return s;
}

// Like shadeSurface, but reflections come mostly from the local probe (walls, ground) instead of
// the open sky, so metal and varnish do not turn blue or purple in enclosed places.
vec3 shadeModel(vec3 albedo, float rough, float metal, vec3 N, vec3 V, vec3 P, vec3 indirect, float ao, float shadow) {
    vec3 direct = shadeSurface(albedo, rough, metal, N, V, P, vec3(0.0), 1.0, shadow);
    ao *= ssaoFactor();
    rough = clamp(rough, 0.05, 1.0);
    vec3 F0 = mix(vec3(0.04), albedo, metal);
    vec3 diffCol = albedo * (1.0 - metal);
    float NoV = max(dot(N, V), 1e-4);
    vec3 R = reflect(-V, N);
    vec3 local = mix(g_ambDown, g_ambUp, clamp(R.z * 0.5 + 0.5, 0.0, 1.0)) * 1.15;
    float openSky = clamp(R.z * 1.6, 0.0, 1.0) * clamp(dot(g_ambUp, vec3(0.3, 0.59, 0.11)) / max(uSkyLum, 1e-3), 0.0, 1.0);
    vec3 env = mix(local, envSpecular(R, rough), openSky * 0.35 * (1.0 - rough));
    env = mix(env, vec3(dot(env, vec3(0.3, 0.59, 0.11))), 0.4 + 0.3 * metal);
    vec2 ab = envBRDF(NoV, rough);
    float specOcc = clamp(pow(NoV + ao, exp2(-16.0 * rough - 1.0)) - 1.0 + ao, 0.0, 1.0);
    return direct + diffCol * indirect * ao + env * (F0 * ab.x + ab.y) * specOcc;
}

void main() {
    g_ambUp = neutralAmb(uAmbUp, uIsViewmodel > 0.5 ? 0.7 : 0.45);
    g_ambDown = neutralAmb(uAmbDown, 0.35);
    vec3 albedo = toLinear(vColor.rgb) * uTint.rgb;
    float rough = vMat.x, metal = vMat.y;
    int pattern = int(vMat.z * 255.0 + 0.5);
    float ao = vColor.a;
    vec3 N = normalize(vNormal);
    vec3 q = vObj;
    // All screen-space derivatives are evaluated here, before any per-material branching.
    vec3 dpdx = dFdx(vPos), dpdy = dFdy(vPos);
    g_pixelFootprint = length(fwidth(vObj));
    float curvature = length(fwidth(N)) / max(length(fwidth(vPos)), 1e-5);
    vec3 objN = cross(dFdx(vObj), dFdy(vObj));
    float h = 0.0;
    float emissive = 0.0, sss = 0.0, sheen = 0.0;
    if (pattern == 1) {            // varnished wood, grain along model X
        float g = fbm3(q * vec3(0.16, 2.6, 2.6));
        float rings = sin(q.y * 6.0 + q.z * 4.0 + g * 11.0) * 0.5 + 0.5;
        float fine = vnoise3(q * vec3(0.5, 36.0, 36.0));
        float pores = smoothstep(0.62, 0.8, vnoise3(q * vec3(1.2, 55.0, 55.0)));
        albedo *= mix(0.55, 1.12, smoothstep(0.15, 0.85, rings)) * (0.9 + 0.16 * fine) * (1.0 - 0.25 * pores);
        rough = clamp(rough + (0.5 - rings) * 0.1 + pores * 0.15, 0.15, 0.95);
        h = (rings * 0.006 - pores * 0.004) * detailFade(0.08);
    } else if (pattern == 2) {     // woven fabric
        float w = weave(q, 42.0);
        float m = fbm3(q * 1.2);
        albedo *= 0.9 + 0.08 * w + (m - 0.5) * 0.3;
        rough = clamp(rough + 0.05 * w, 0.4, 1.0);
        h = w * 0.004 * detailFade(0.15) + (m - 0.5) * 0.02;
        sheen = 0.25;
    } else if (pattern == 3) {     // camo fabric
        float c1 = fbm3(q * 0.28 + 3.1), c2 = fbm3(q * 0.42 + 9.7);
        albedo = mix(albedo, toLinear(uPatternA), smoothstep(0.47, 0.51, c1));
        albedo = mix(albedo, toLinear(uPatternB), smoothstep(0.54, 0.58, c2));
        float w = weave(q, 42.0);
        float m = fbm3(q * 1.2);
        albedo *= 0.92 + 0.07 * w + (m - 0.5) * 0.22;
        h = w * 0.004 * detailFade(0.15) + (m - 0.5) * 0.02;
        sheen = 0.25;
    } else if (pattern == 4) {     // stippled polymer
        float s = vnoise3(q * 16.0), s2 = vnoise3(q * 41.0);
        albedo *= 0.92 + 0.12 * s;
        rough = clamp(rough + (s - 0.5) * 0.2, 0.2, 0.95);
        h = (s * 0.006 + s2 * 0.003) * detailFade(0.07);
    } else if (pattern == 5) {     // parkerized / blued steel with worn edges
        float n1 = fbm3(q * 1.1), n2 = vnoise3(q * 7.0), n3 = vnoise3(q * 38.0);
        albedo *= 0.82 + 0.3 * n1;
        rough = clamp(rough + (n1 - 0.5) * 0.22 + (n3 - 0.5) * 0.08, 0.12, 0.95);
        float wear = smoothstep(0.5, 0.9, smoothstep(6.0, 22.0, curvature) * (0.5 + n2));
        albedo = mix(albedo, vec3(0.42, 0.42, 0.44), wear * 0.45);
        metal = mix(metal, 1.0, wear);
        rough = mix(rough, 0.28, wear);
        h = n3 * 0.0025 * detailFade(0.05);
    } else if (pattern == 6) {     // leather / glove material
        float n = vnoise3(q * 22.0), m = fbm3(q * 1.6), c = vnoise3(q * 60.0);
        albedo *= 0.88 + 0.16 * n + (m - 0.5) * 0.25;
        rough = clamp(rough + (n - 0.5) * 0.2, 0.25, 0.95);
        h = (n * 0.005 + c * 0.002) * detailFade(0.08) + (m - 0.5) * 0.015;
        sheen = 0.1;
    } else if (pattern == 7) {     // skin
        float m = fbm3(q * 2.2), pores = vnoise3(q * 70.0);
        albedo *= 0.93 + 0.14 * m;
        albedo = mix(albedo, albedo * vec3(1.08, 0.9, 0.86), smoothstep(0.55, 0.75, fbm3(q * 0.9 + 4.0)) * 0.5);
        rough = clamp(0.5 + (pores - 0.5) * 0.15, 0.3, 0.8);
        h = pores * 0.0015 * detailFade(0.03) + (m - 0.5) * 0.004;
        sss = 1.0;
    } else if (pattern == 8) {     // emissive
        emissive = 1.0;
    } else if (pattern == 9) {     // lens glass
        rough = 0.04; metal = 0.0;
    } else if (pattern == 10) {    // brushed / machined bare metal
        float b = vnoise3(q * vec3(2.0, 90.0, 90.0));
        rough = clamp(rough + (b - 0.5) * 0.12, 0.08, 0.9);
        albedo *= 0.94 + 0.08 * b;
        h = b * 0.0015 * detailFade(0.02);
    }
    // ---- Wear: paint and finish rubbed through on edges, handling scratches, dust in crevices ----
    // Edge and crease masks are baked per vertex from mesh curvature; noise breaks them into chips and patches.
    bool hard = pattern == 0 || pattern == 1 || pattern == 4 || pattern == 5 || pattern == 10;
    if (hard && vWear.x + vWear.y > -1.0) {
        float fp = detailFade(0.04);
        float n1 = fbm3(q * 1.9 + 7.0), n2 = vnoise3(q * 9.0), n3 = vnoise3(q * 31.0);
        float breakup = n1 * 0.6 + n2 * 0.3 + n3 * 0.1;
        float edgeMask = vWear.x;
        float wear = smoothstep(0.55, 0.75, edgeMask * (0.3 + 0.9 * breakup)) * 0.85;
        // Soft halo of polished finish around the chipped areas.
        float polish = smoothstep(0.3, 0.7, edgeMask * (0.4 + breakup)) * (1.0 - wear);
        float scr = scratches(q, objN) * fp * (0.35 + 0.65 * smoothstep(0.35, 0.65, fbm3(q * 0.7 + 3.0)));
        float lum = dot(albedo, vec3(0.3, 0.59, 0.11));
        float chroma = max(albedo.r, max(albedo.g, albedo.b)) - min(albedo.r, min(albedo.g, albedo.b));
        if (pattern == 1) {
            // Varnished wood: varnish and stain worn off, lighter raw wood; scratches are pale dents.
            albedo = mix(albedo, albedo * 1.25 + vec3(0.01, 0.006, 0.002), wear * 0.6);
            rough = mix(rough, 0.7, wear);
            albedo = mix(albedo, albedo * 1.35 + vec3(0.015), scr * 0.6);
            rough = mix(rough, 0.6, scr * 0.5);
            h -= scr * 0.002;
        } else if (pattern == 10) {
            // Bare machined metal: edges polished bright, scratches catch light across the grain.
            rough = mix(rough, rough * 0.45, max(wear, polish * 0.5));
            albedo = mix(albedo, min(albedo * 1.15, vec3(0.9)), wear);
            rough = mix(rough, 0.16, scr * 0.8);
            albedo *= 1.0 + scr * 0.12;
            h -= scr * 0.0012;
        } else if (metal > 0.2) {
            // Coated steel (parkerized, blued, anodized): coating worn through to bright bare steel.
            vec3 bare = vec3(0.56, 0.56, 0.57) * (0.85 + 0.3 * n3);
            albedo = mix(albedo, bare, wear * 0.55);
            metal = mix(metal, 1.0, wear);
            rough = mix(rough, 0.24 + 0.1 * n2, wear);
            rough = mix(rough, rough * 0.75, polish * 0.6);
            albedo = mix(albedo, bare * 0.9, scr * 0.75);
            metal = mix(metal, 1.0, scr * 0.8);
            rough = mix(rough, 0.2, scr * 0.8);
            h -= scr * 0.0015;
        } else if (chroma > 0.06) {
            // Painted polymer / stock (AWP green): paint chips reveal the dark substrate, scratches are pale.
            albedo = mix(albedo, vec3(0.035, 0.035, 0.037), wear * 0.85);
            rough = mix(rough, 0.45, wear);
            albedo = mix(albedo, albedo * 1.4 + vec3(0.03), scr * 0.6);
            h -= scr * 0.002;
        } else {
            // Black polymer: rubbed edges turn lighter and glossier, scratches show whitish stress marks.
            albedo = mix(albedo, albedo * 1.6 + vec3(0.018), max(wear * 0.7, polish * 0.3));
            rough = mix(rough, rough * 0.6, max(wear, polish * 0.5));
            albedo += vec3(0.05) * scr * (1.0 - lum);
            rough = mix(rough, 0.35, scr * 0.5);
            h -= scr * 0.0015;
        }
        // Dust, oil and carbon in crevices and around parts.
        float grime = smoothstep(0.15, 0.7, vWear.y) * (0.5 + 0.5 * n1);
        albedo = mix(albedo, albedo * 0.55 + vec3(0.045, 0.04, 0.034), grime * 0.55);
        rough = mix(rough, 0.85, grime * 0.5);
        metal *= 1.0 - grime * 0.4;
        // Fingerprints and handling smudges: low-frequency roughness variation on glossy parts.
        float smudge = smoothstep(0.45, 0.75, fbm3(q * 0.9 + 1.3)) * smoothstep(0.3, 0.7, vnoise3(q * 5.0));
        rough = clamp(rough + (smudge - 0.25) * 0.12 * (1.0 - rough), 0.05, 1.0);
    }
    N = bumpNormal(N, h, dpdx, dpdy);
    // Metals need a bright F0 (real steel reflects 50%+); dark metallic albedo rendered as pure black.
    albedo = mix(albedo, max(albedo, vec3(0.22)), clamp(metal, 0.0, 1.0) * 0.75);
    albedo = max(albedo, vec3(0.012));

    vec3 V = normalize(uCamPos - vPos);
    float sh = shadowFactor(vPos, N);
    vec3 indirect = mix(g_ambDown, g_ambUp, N.z * 0.5 + 0.5);
    if (uIsViewmodel > 0.5) indirect = indirect * 1.7 + vec3(0.03);
    else indirect *= 1.3;  // probes miss light bounced by the ground right next to the character
    vec3 col = shadeModel(albedo, rough, metal, N, V, vPos, indirect, ao, sh * mix(1.0, ao, 0.35));
    float NoL = dot(N, uSunDir);
    if (sss > 0.0) {
        // Light bleeding past the terminator, reddened by scattering under the skin.
        float wrap = clamp((NoL + 0.45) / 1.45, 0.0, 1.0) - clamp(NoL, 0.0, 1.0);
        col += albedo * vec3(1.0, 0.5, 0.36) * uSunColor * wrap * 0.15 * sh;
        col += albedo * vec3(0.9, 0.4, 0.3) * indirect * 0.06 * ao;
    }
    if (sheen > 0.0) {
        float rim = pow(1.0 - max(dot(N, V), 0.0), 4.0);
        col += albedo * (indirect + uSunColor * max(NoL, 0.0) * sh) * rim * sheen;
    }
    // Soft fill from the camera keeps viewmodels readable in dark corners, as in CS2.
    if (uIsViewmodel > 0.5) {
        float facing = max(dot(N, V), 0.0);
        vec3 fillCol = g_ambUp * 0.75 + uSunColor * 0.035 + vec3(0.06);
        col += albedo * (1.0 - metal * 0.5) * fillCol * (0.35 + 0.65 * facing * facing) * ao;
        // Soft top key from above the camera: keeps receiver edges and glove folds readable.
        vec3 keyDir = normalize(uSunDir * 0.35 + vec3(0.0, 0.0, 1.0));
        float kd = max(dot(N, keyDir), 0.0);
        vec3 Hk = normalize(keyDir + V);
        float ks = pow(max(dot(N, Hk), 0.0), mix(8.0, 64.0, 1.0 - rough)) * (1.0 - rough) * 0.6;
        col += (albedo * (1.0 - metal) * kd * 0.35 + mix(vec3(0.04), albedo, metal) * ks) * (g_ambUp + uSunColor * 0.06) * ao;
    }
    col += albedo * emissive * 6.0;
    if (uIsViewmodel < 0.5) col = applyFog(col, vPos);
    // A single NaN or extreme highlight would be smeared into a large blob by bloom.
    if (any(isnan(col)) || any(isinf(col))) col = vec3(0.0);
    oColor = vec4(min(col, vec3(48.0)), 1.0);
}
)GLSL";

}  // namespace glsl
