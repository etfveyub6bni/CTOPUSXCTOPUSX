#include "assets/models.h"

namespace {

// Albedo values follow measured references (black oxide/parkerized steel ~0.12-0.18 linear, black polymer ~0.04):
// the old near-black values made weapons read as silhouettes even in full sun.
const Mat kGunmetal{{0.25f, 0.25f, 0.26f}, 0.44f, 0.40f, 5};
const Mat kDarkSteel{{0.23f, 0.23f, 0.24f}, 0.38f, 0.55f, 5};
const Mat kSatin{{0.66f, 0.66f, 0.67f}, 0.30f, 1.0f, 10};
const Mat kBlade{{0.80f, 0.80f, 0.82f}, 0.20f, 1.0f, 10};
const Mat kWood{{0.42f, 0.20f, 0.09f}, 0.36f, 0.0f, 1};
const Mat kGripBrown{{0.30f, 0.12f, 0.06f}, 0.42f, 0.0f, 4};
const Mat kPolymer{{0.15f, 0.15f, 0.155f}, 0.62f, 0.0f, 4};
const Mat kPolySmooth{{0.14f, 0.14f, 0.145f}, 0.45f, 0.0f, 0};
const Mat kAnodized{{0.18f, 0.18f, 0.185f}, 0.50f, 0.30f, 5};
const Mat kAwpGreen{{0.31f, 0.36f, 0.24f}, 0.58f, 0.0f, 4};
const Mat kLens{{0.08f, 0.12f, 0.16f}, 0.05f, 0.0f, 9};
const Mat kMagSteel{{0.24f, 0.24f, 0.25f}, 0.46f, 0.5f, 5};
const Mat kRubber{{0.15f, 0.15f, 0.155f}, 0.85f, 0.0f, 4};

Xform gripFrame(vec3 axisPoint, vec3 fingerDir, vec3 dorsal, vec3 localAxisPoint) {
    Xform h = xformFromBasis(vec3(0), fingerDir, dorsal);
    h.p = axisPoint - rotate(h.q, localAxisPoint);
    return h;
}

FingerPose poseFrom(std::initializer_list<float> v) {
    FingerPose p;
    auto it = v.begin();
    for (int f = 0; f < 5; f++)
        for (int j = 0; j < 3; j++) p.curl[f][j] = *it++;
    for (int f = 0; f < 5 && it != v.end(); f++) p.spread[f] = *it++;
    if (it != v.end()) p.thumbTwist = *it++;
    return p;
}

// Right hand wrapped around a pistol grip, index finger on the trigger.
FingerPose poseTriggerGrip() {
    return poseFrom({0.25f, 0.95f, 0.55f,  1.35f, 1.45f, 0.85f,  1.40f, 1.45f, 0.85f,  1.40f, 1.40f, 0.85f,
                     0.55f, 0.55f, 0.45f,  0.02f, 0, -0.03f, -0.07f, 0, 0.35f});
}
// Support hand wrapped around a handguard.
FingerPose poseHandguard() {
    return poseFrom({1.05f, 1.15f, 0.75f,  1.10f, 1.20f, 0.75f,  1.12f, 1.15f, 0.75f,  1.12f, 1.10f, 0.70f,
                     0.35f, 0.25f, 0.20f,  0.05f, 0, -0.04f, -0.09f, 0, 0.2f});
}
// Support hand under a rifle handguard: fingers wrap the far side, thumb lies forward along the near side.
FingerPose poseUnderHandguard() {
    FingerPose p = poseHandguard();
    for (int f = 0; f < 4; f++) {
        p.curl[f][0] = 0.95f;
        p.curl[f][1] = 1.05f;
        p.curl[f][2] = 0.7f;
    }
    p.thumbTwist = 1.7f;
    p.spread[4] = -0.25f;
    p.curl[4][0] = 0.45f;
    return p;
}
// Places the support hand below a handguard whose axis passes through `axis` (weapon space).
Xform supportUnderHandguard(vec3 axis, float drop = 1.35f) {
    return gripFrame(axis, normalize(vec3(0.55f, -0.8f, 0.25f)), {0, 0.35f, -0.94f}, {2.3f, 0.15f, -drop});
}
FingerPose poseSupportPistol() {
    return poseFrom({1.15f, 1.25f, 0.8f,  1.25f, 1.30f, 0.8f,  1.30f, 1.30f, 0.8f,  1.30f, 1.25f, 0.75f,
                     0.25f, 0.15f, 0.10f,  0.0f, 0, -0.03f, -0.07f, 0, 0.1f});
}
FingerPose poseFist() {
    return poseFrom({1.45f, 1.50f, 0.95f,  1.50f, 1.55f, 0.95f,  1.52f, 1.52f, 0.95f,  1.50f, 1.48f, 0.90f,
                     0.75f, 0.70f, 0.55f,  0.0f, 0, -0.03f, -0.06f, 0, 0.5f});
}
FingerPose poseMag() {
    return poseFrom({0.85f, 0.95f, 0.6f,  0.95f, 1.05f, 0.65f,  1.0f, 1.05f, 0.65f,  1.0f, 1.0f, 0.6f,
                     0.3f, 0.3f, 0.25f,  0.05f, 0, -0.05f, -0.1f, 0, 0.2f});
}

// Banana/straight magazine outline in XZ: centerline starts at `top` pointing down and bends forward.
std::vector<vec2> magOutline(vec2 top, float R, float arcLen, float depthTop, float depthBot, float topExtra, int n = 10) {
    std::vector<vec2> front, back;
    for (int i = 0; i <= n; i++) {
        float t = (float)i / n, phi = (arcLen / R) * t;
        vec2 c(top.x + R - R * std::cos(phi), top.y - R * std::sin(phi));
        vec2 nr(std::cos(phi), std::sin(phi));
        float d = lerpf(depthTop, depthBot, t) * 0.5f;
        front.push_back(c + nr * d);
        back.push_back(c - nr * d);
    }
    std::vector<vec2> out;
    out.push_back(back[0] + vec2(0, topExtra));
    for (auto& p : back) out.push_back(p);
    for (int i = n; i >= 0; i--) out.push_back(front[i]);
    out.push_back(front[0] + vec2(0, topExtra));
    return out;
}

// Band between two offsets across a curved magazine (for ribs); offsets are fractions of the depth (-0.5..0.5).
std::vector<vec2> magBand(vec2 top, float R, float arcLen, float depthTop, float depthBot, float f0, float f1, float t0, float t1, int n = 10) {
    std::vector<vec2> a, b;
    for (int i = 0; i <= n; i++) {
        float t = lerpf(t0, t1, (float)i / n), phi = (arcLen / R) * t;
        vec2 c(top.x + R - R * std::cos(phi), top.y - R * std::sin(phi));
        vec2 nr(std::cos(phi), std::sin(phi));
        float d = lerpf(depthTop, depthBot, t);
        a.push_back(c + nr * (d * f0));
        b.push_back(c + nr * (d * f1));
    }
    std::vector<vec2> out(a.begin(), a.end());
    for (int i = n; i >= 0; i--) out.push_back(b[i]);
    return out;
}

void rivet(MeshBuilder& m, vec3 p, float side, float r = 0.085f) {
    m.sphere(p + vec3(0, side * 0.01f, 0), {r, 0.045f, r}, 10, 5);
}

void railTeeth(MeshBuilder& m, float x0, float x1, float z, float hw) {
    for (float x = x0; x < x1; x += 0.55f) m.box({x + 0.14f, 0, z}, {0.14f, hw, 0.07f}, 0.02f);
}


// ---- Detail helpers -------------------------------------------------------------------------------------------
// Cross-section loft along X: each station is (x, zCenter, halfWidth(Y), halfHeight(Z), cornerRadius).
struct Sect { float x, zc, hw, hh, r; };
void sectX(MeshBuilder& m, std::initializer_list<Sect> st, bool capA = true, bool capB = true, int cs = 4, float y = 0) {
    std::vector<Ring> rings;
    for (const Sect& s : st) rings.push_back(ringRoundRect({s.x, y, s.zc}, {0, 1, 0}, {0, 0, 1}, s.hw, s.hh, s.r, cs));
    m.loft(rings, capA, capB);
}
// Closed band around an open 2D path (XZ): trigger guards, sling loops, spoons. Thickness is total width in XZ.
std::vector<vec2> bandOutline(const std::vector<vec2>& path, float thick) {
    std::vector<vec2> a, b;
    size_t n = path.size();
    for (size_t i = 0; i < n; i++) {
        vec2 d = i == 0 ? path[1] - path[0] : i == n - 1 ? path[n - 1] - path[n - 2] : path[i + 1] - path[i - 1];
        d = normalize(d);
        vec2 nr(-d.y, d.x);
        a.push_back(path[i] + nr * (thick * 0.5f));
        b.push_back(path[i] - nr * (thick * 0.5f));
    }
    std::vector<vec2> out(a.begin(), a.end());
    for (size_t i = n; i-- > 0;) out.push_back(b[i]);
    return out;
}
// Arc points (XZ) from angle a0 to a1 (degrees, 0 = +X, 90 = +Z).
std::vector<vec2> arcPts(vec2 c, float rx, float rz, float a0, float a1, int n) {
    std::vector<vec2> p;
    for (int i = 0; i <= n; i++) {
        float a = lerpf(a0, a1, (float)i / n) * kDeg;
        p.push_back({c.x + std::cos(a) * rx, c.y + std::sin(a) * rz});
    }
    return p;
}
std::vector<vec2> cat(std::vector<vec2> a, const std::vector<vec2>& b) { a.insert(a.end(), b.begin(), b.end()); return a; }
// Torus around `axis` (rings, pull rings).
void torus(MeshBuilder& m, vec3 c, vec3 axis, float R, float r, int seg = 20, int side = 8) {
    axis = normalize(axis);
    vec3 u = normalize(std::fabs(axis.z) < 0.9f ? cross(axis, vec3(0, 0, 1)) : cross(axis, vec3(1, 0, 0)));
    vec3 v = cross(axis, u);
    uint32_t base = (uint32_t)m.verts.size();
    for (int i = 0; i <= seg; i++) {
        float a = kTwoPi * i / seg;
        vec3 d = u * std::cos(a) + v * std::sin(a);
        for (int j = 0; j <= side; j++) {
            float b = kTwoPi * j / side;
            vec3 n = d * std::cos(b) + axis * std::sin(b);
            m.vtx(c + d * R + n * r, n);
        }
    }
    for (int i = 0; i < seg; i++)
        for (int j = 0; j < side; j++) {
            uint32_t a = base + i * (side + 1) + j, b = a + side + 1;
            m.quad(a, b, b + 1, a + 1);
        }
}
// Screw / pin head on a side face (s = +1 left, -1 right), with a slot.
void screwHead(MeshBuilder& m, vec3 p, float s, float r = 0.12f, bool slot = true) {
    Mat keep = m.mat;
    m.cylinder(p, p + vec3(0, s * 0.05f, 0), r, r * 0.85f, 12, true, 0.02f);
    if (slot) {
        m.mat.color = keep.color * 0.4f;
        m.box(p + vec3(0, s * 0.052f, 0), {r * 0.85f, 0.012f, r * 0.16f}, 0.0f);
    }
    m.mat = keep;
}
void pinEnd(MeshBuilder& m, vec3 p, float s, float r = 0.07f) { m.cylinder(p - vec3(0, s * 0.02f, 0), p + vec3(0, s * 0.03f, 0), r, r, 10, true, 0.015f); }
// Picatinny rail running along X on top (dir = +Z) or sides/bottom (dir given as unit axis in YZ).
void picatinny(MeshBuilder& m, float x0, float x1, vec3 base, vec3 up, float hw = 0.42f) {
    up = normalize(up);
    vec3 side = normalize(cross(up, vec3(1, 0, 0)));
    mat4 keep = m.xform();
    mat4 f;  // columns: X, side, up
    f.m[0] = 1; f.m[1] = 0; f.m[2] = 0;
    f.m[4] = side.x; f.m[5] = side.y; f.m[6] = side.z;
    f.m[8] = up.x; f.m[9] = up.y; f.m[10] = up.z;
    f.m[12] = base.x; f.m[13] = base.y; f.m[14] = base.z;
    m.setXform(keep * f);
    float len = x1 - x0, cx = (x0 + x1) * 0.5f;
    m.box({cx, 0, 0.08f}, {len * 0.5f, hw * 0.62f, 0.08f}, 0.02f);           // spine
    m.extrude({{x0, 0.14f}, {x1, 0.14f}, {x1, 0.2f}, {x0, 0.2f}}, hw, 0.05f);  // dovetail lips (clamping surface)
    const float pitch = 0.394f;
    for (float x = x0 + 0.1f; x + 0.2f <= x1; x += pitch) m.box({x + 0.1f, 0, 0.3f}, {0.1f, hw * 0.9f, 0.1f}, 0.025f);
    m.setXform(keep);
}
// Row of slot-shaped recesses: darker thin boxes that read as cuts (vents, serrations).
void slots(MeshBuilder& m, vec3 start, vec3 step, int n, vec3 half, float darkK = 0.35f) {
    Mat keep = m.mat;
    m.mat.color = keep.color * darkK;
    m.mat.rough = std::min(1.0f, keep.rough + 0.2f);
    for (int i = 0; i < n; i++) m.box(start + step * (float)i, half, std::min(half.x, half.z) * 0.6f);
    m.mat = keep;
}

// Ring of an arbitrary closed XZ-profile placed at X = x (for slanted cuts etc.): helper for loft().
Ring ringCircleX(float x, float zc, float r, int n, float slant = 0.0f) {
    Ring rg;
    for (int i = 0; i < n; i++) {
        float a = kTwoPi * i / n;
        float y = std::cos(a) * r, z = std::sin(a) * r;
        // slant > 0: the lower lip reaches further forward (AKM slant brake).
        rg.push_back({x - slant * (z / r + 1.0f) * 0.5f, y, zc + z});
    }
    return rg;
}
// Rounded section in the YV plane where V is an arbitrary in-plane XZ axis (slanted pistol grips).
Ring ringSlanted(vec3 c, vec3 v, float hu, float hv, float r, int cs = 4) { return ringRoundRect(c, {0, 1, 0}, v, hu, hv, r, cs); }

void buildAK(MeshBuilder& m, WeaponModel& w) {
    const float bore = 1.0f;
    const vec3 Y(0, 1, 0), Z(0, 0, 1);
    // AKM materials: black-oxide stamped steel, laminated birch furniture, bakelite grip.
    const Mat steel{{0.205f, 0.205f, 0.215f}, 0.42f, 0.55f, 5};
    const Mat steelDk{{0.14f, 0.14f, 0.15f}, 0.38f, 0.65f, 5};
    const Mat steelBare{{0.46f, 0.46f, 0.47f}, 0.32f, 1.0f, 10};
    const Mat cut{{0.035f, 0.035f, 0.04f}, 0.7f, 0.2f, 0};
    const Mat wood{{0.45f, 0.27f, 0.165f}, 0.38f, 0.0f, 1};
    const Mat woodDk{{0.36f, 0.2f, 0.11f}, 0.42f, 0.0f, 1};
    const Mat bake{{0.33f, 0.2f, 0.14f}, 0.5f, 0.0f, 4};
    const Mat magMat{{0.23f, 0.23f, 0.24f}, 0.5f, 0.45f, 5};
    m.bone = WB_BODY;

    // ---------------- Receiver ----------------
    m.mat = steel;
    m.extrude({{-6.45f, 1.2f}, {-6.45f, -0.18f}, {-6.2f, -0.36f}, {-2.25f, -0.4f}, {-1.5f, -0.8f}, {2.2f, -0.8f},
               {2.36f, -0.38f}, {3.72f, -0.38f}, {3.92f, -0.8f}, {4.22f, -0.8f}, {4.22f, 1.2f}}, 0.56f, 0.05f, 30);
    // Stiffening lip along the top edges of the stamped sides (where the dust cover sits).
    for (float s : {-1.0f, 1.0f}) m.box({-1.1f, s * 0.575f, 1.02f}, {5.3f, 0.02f, 0.06f}, 0.015f);
    // Front trunnion and rear trunnion bosses, riveted: slightly proud plates.
    for (float s : {-1.0f, 1.0f}) {
        m.mat = steel;
        for (vec2 p : {vec2(2.85f, 0.55f), vec2(3.6f, 0.55f), vec2(3.2f, -0.45f), vec2(3.95f, -0.2f)}) rivet(m, {p.x, s * 0.59f, p.y}, s, 0.085f);
        for (vec2 p : {vec2(-6.05f, -0.05f), vec2(-5.45f, -0.05f), vec2(-5.75f, 0.45f)}) rivet(m, {p.x, s * 0.59f, p.y}, s, 0.08f);
        // Trigger group: hammer and trigger pins with the retaining spring bar (shepherd's hook ends).
        m.mat = steelDk;
        for (float rx : {-0.45f, 0.7f}) pinEnd(m, {rx, s * 0.575f, -0.15f}, s, 0.095f);
        pinEnd(m, {-2.9f, s * 0.575f, -0.08f}, s, 0.07f);
        rivet(m, {-1.6f, s * 0.585f, 0.3f}, s, 0.07f);
    }
    // Magazine guide dimples above the well and bolt-hold-open dimple.
    m.mat = steel;
    for (float s : {-1.0f, 1.0f}) m.sphere({3.0f, s * 0.55f, 0.32f}, {0.52f, 0.035f, 0.24f}, 14, 6);
    // Side scope rail (left).
    m.mat = {{0.13f, 0.13f, 0.14f}, 0.45f, 0.15f, 0};
    m.box({-2.35f, 0.6f, 0.42f}, {2.35f, 0.045f, 0.27f}, 0.04f);
    m.box({-2.35f, 0.65f, 0.42f}, {2.2f, 0.02f, 0.13f}, 0.015f);
    for (float rx : {-4.2f, -0.5f}) rivet(m, {rx, 0.655f, 0.42f}, 1.0f, 0.075f);
    // Ejection port (right) with the bolt carrier face showing through, and the bolt head.
    m.mat = cut;
    m.box({1.75f, -0.566f, 0.83f}, {1.45f, 0.012f, 0.25f}, 0.01f);
    m.mat = steelBare;
    m.mat.color = {0.36f, 0.36f, 0.37f};
    m.box({1.2f, -0.572f, 0.86f}, {0.85f, 0.01f, 0.15f}, 0.02f);
    m.mat = steelDk;
    m.cylinder({2.25f, -0.52f, 0.86f}, {2.25f, -0.58f, 0.86f}, 0.13f, 0.13f, 10);
    // Safety/selector lever (right side): long stamped plate pivoting at the rear, finger tab at the back.
    m.mat = steel;
    m.extrude({{-5.95f, 0.62f}, {-5.3f, 0.86f}, {1.9f, 0.86f}, {2.25f, 0.74f}, {1.9f, 0.62f}, {-4.7f, 0.56f},
               {-5.05f, 0.1f}, {-5.35f, -0.1f}, {-5.8f, 0.05f}, {-5.95f, 0.3f}}, 0.025f, 0.012f, 30, -0.605f);
    m.mat = steelDk;
    m.cylinder({-5.55f, -0.57f, 0.4f}, {-5.55f, -0.66f, 0.4f}, 0.13f, 0.12f, 12, true, 0.02f);
    // Detent stamps on the right side for the lever.
    for (float dz : {0.0f, -0.28f, -0.56f}) m.sphere({-4.9f, -0.57f, 0.35f + dz * 0.5f}, {0.05f, 0.02f, 0.05f}, 6, 4);

    // ---------------- Dust cover ----------------
    {
        m.mat = steel;
        std::vector<Ring> r;
        const float xs[] = {-6.7f, -6.58f, -6.3f, 3.35f, 3.6f, 3.7f};
        const float hw[] = {0.38f, 0.54f, 0.585f, 0.585f, 0.55f, 0.42f}, hh[] = {0.18f, 0.28f, 0.32f, 0.32f, 0.29f, 0.2f};
        for (int i = 0; i < 6; i++) r.push_back(ringRoundRect({xs[i], 0, 1.25f}, Y, Z, hw[i], hh[i], std::min(hw[i], hh[i]) * 0.92f, 6));
        m.loft(r);
        // Stamped transverse stiffening ribs.
        for (int k = 0; k < 7; k++) {
            float rx = -5.55f + k * 1.2f;
            std::vector<Ring> rr;
            rr.push_back(ringRoundRect({rx - 0.13f, 0, 1.25f}, Y, Z, 0.586f, 0.321f, 0.3f, 6));
            rr.push_back(ringRoundRect({rx - 0.04f, 0, 1.251f}, Y, Z, 0.594f, 0.33f, 0.305f, 6));
            rr.push_back(ringRoundRect({rx + 0.04f, 0, 1.251f}, Y, Z, 0.594f, 0.33f, 0.305f, 6));
            rr.push_back(ringRoundRect({rx + 0.13f, 0, 1.25f}, Y, Z, 0.588f, 0.322f, 0.3f, 6));
            m.loft(rr, false, false);
        }
        // Recoil spring guide button through the rear of the cover.
        m.mat = steelDk;
        m.cylinder({-6.62f, 0, 1.12f}, {-6.86f, 0, 1.12f}, 0.14f, 0.13f, 12, true, 0.03f);
    }

    // ---------------- Rear sight block and leaf ----------------
    m.mat = steel;
    m.extrude({{4.05f, 1.32f}, {6.45f, 1.32f}, {6.5f, 1.05f}, {6.2f, 0.62f}, {4.05f, 0.35f}}, 0.42f, 0.08f, 30);
    m.box({4.9f, 0, 0.55f}, {0.8f, 0.52f, 0.6f}, 0.1f);  // front trunnion body
    m.mat = steelDk;
    // Leaf sloping forward, range slider with its spring catch, notch plate at the rear end.
    m.extrude({{4.25f, 1.36f}, {6.2f, 1.36f}, {6.25f, 1.46f}, {4.25f, 1.56f}}, 0.28f, 0.03f, 30);
    m.box({5.15f, 0, 1.55f}, {0.22f, 0.35f, 0.1f}, 0.04f);
    for (float s : {-1.0f, 1.0f}) m.box({5.15f, s * 0.36f, 1.5f}, {0.12f, 0.03f, 0.12f}, 0.02f);
    m.extrude({{4.18f, 1.5f}, {4.36f, 1.5f}, {4.36f, 1.78f}, {4.18f, 1.78f}}, 0.3f, 0.02f, 30);
    m.mat = cut;
    m.box({4.27f, 0, 1.74f}, {0.1f, 0.05f, 0.06f}, 0.0f);

    // ---------------- Barrel, gas system, front sight, muzzle ----------------
    m.mat = steel;
    m.lathe({6.2f, 0, bore}, {1, 0, 0}, {{0, 0}, {0, 0.4f}, {1.4f, 0.37f}, {1.5f, 0.34f}, {15.4f, 0.3f}, {15.4f, 0}}, 20);
    // Rear handguard retainer ring and front retainer with its lever.
    m.mat = steel;
    m.loft({ringRoundRect({6.35f, 0, bore - 0.12f}, Y, Z, 0.8f, 0.86f, 0.5f, 5), ringRoundRect({6.72f, 0, bore - 0.12f}, Y, Z, 0.84f, 0.9f, 0.52f, 5)});
    m.loft({ringRoundRect({14.35f, 0, bore - 0.2f}, Y, Z, 0.78f, 0.74f, 0.5f, 5), ringRoundRect({14.72f, 0, bore - 0.2f}, Y, Z, 0.74f, 0.7f, 0.48f, 5)});
    m.mat = steelDk;
    m.extrude({{14.25f, 0.05f}, {14.55f, 0.1f}, {14.62f, -0.55f}, {14.4f, -0.6f}}, 0.035f, 0.015f, 30, -0.8f);
    // Gas block: collar on the barrel, 45° port stem up to the gas tube, bayonet lug below.
    m.mat = steel;
    m.cylinder({15.3f, 0, bore}, {16.25f, 0, bore}, 0.46f, 0.46f, 18, true, 0.07f);
    m.extrude({{15.35f, bore + 0.2f}, {16.2f, bore + 0.2f}, {16.2f, bore + 0.95f}, {15.75f, bore + 1.3f}, {15.35f, bore + 1.3f}}, 0.34f, 0.08f, 30);
    m.cylinder({15.25f, 0, bore + 0.95f}, {16.35f, 0, bore + 0.95f}, 0.36f, 0.34f, 16, true, 0.06f);
    m.box({15.75f, 0, bore - 0.62f}, {0.55f, 0.16f, 0.2f}, 0.05f);
    m.mat = steelDk;
    m.box({16.05f, 0, bore - 0.8f}, {0.14f, 0.2f, 0.06f}, 0.02f);
    // Front sling swivel (left side of the gas block).
    torus(m, {15.8f, 0.52f, bore + 0.15f}, {0, 1, 0}, 0.28f, 0.045f, 16, 6);
    // Gas tube: exposed steel front section, then the wooden upper handguard over the rest.
    m.mat = steel;
    m.cylinder({12.3f, 0, bore + 0.95f}, {15.4f, 0, bore + 0.95f}, 0.3f, 0.3f, 16);
    m.cylinder({12.3f, 0, bore + 0.95f}, {12.55f, 0, bore + 0.95f}, 0.34f, 0.34f, 16, true, 0.04f);
    m.mat = cut;
    for (int i = 0; i < 3; i++) m.sphere({12.95f + i * 0.5f, 0.27f, bore + 0.95f}, {0.1f, 0.05f, 0.1f}, 8, 4);
    for (int i = 0; i < 3; i++) m.sphere({12.95f + i * 0.5f, -0.27f, bore + 0.95f}, {0.1f, 0.05f, 0.1f}, 8, 4);
    // Cleaning rod under the barrel, head notched into the front sight base.
    m.mat = steelDk;
    m.cylinder({14.8f, 0, bore - 0.5f}, {20.35f, 0, bore - 0.5f}, 0.095f, 0.095f, 10);
    m.cylinder({20.1f, 0, bore - 0.5f}, {20.45f, 0, bore - 0.5f}, 0.13f, 0.13f, 10, true, 0.03f);
    // Front sight base: barrel collar, triangular post column, open "ears" guarding the post.
    m.mat = steel;
    m.cylinder({19.95f, 0, bore}, {21.2f, 0, bore}, 0.45f, 0.45f, 18, true, 0.06f);
    m.box({20.58f, 0, bore - 0.46f}, {0.62f, 0.2f, 0.16f}, 0.05f);
    m.extrude({{20.05f, bore + 0.3f}, {21.15f, bore + 0.3f}, {20.95f, bore + 0.9f}, {20.3f, bore + 0.9f}}, 0.3f, 0.07f, 30);
    m.cylinder({20.35f, 0, bore + 1.08f}, {20.95f, 0, bore + 1.08f}, 0.3f, 0.3f, 14, true, 0.05f);
    for (float s : {-1.0f, 1.0f}) m.extrude({{20.35f, bore + 0.75f}, {20.95f, bore + 0.75f}, {20.95f, bore + 1.72f}, {20.7f, bore + 1.78f}, {20.35f, bore + 1.6f}}, 0.055f, 0.03f, 30, s * 0.36f);
    m.mat = steelDk;
    m.cylinder({20.65f, 0, bore + 1.2f}, {20.65f, 0, bore + 1.72f}, 0.06f, 0.05f, 8);
    m.sphere({20.65f, 0, bore + 1.72f}, {0.06f, 0.06f, 0.04f}, 8, 4);
    // Threaded muzzle nut and the slant brake (lower lip reaches further: pushes the muzzle down on each shot).
    m.mat = steel;
    m.cylinder({21.55f, 0, bore}, {21.75f, 0, bore}, 0.36f, 0.36f, 16, true, 0.03f);
    {
        std::vector<Ring> rg;
        rg.push_back(ringCircleX(21.7f, bore, 0.36f, 20));
        rg.push_back(ringCircleX(21.85f, bore, 0.41f, 20));
        rg.push_back(ringCircleX(23.2f, bore, 0.41f, 20, 0.0f));
        rg.push_back(ringCircleX(23.75f, bore, 0.41f, 20, 0.55f));
        rg.push_back(ringCircleX(23.72f, bore, 0.37f, 20, 0.55f));
        m.loft(rg, true, false);
        m.mat = cut;
        m.loft({ringCircleX(23.72f, bore, 0.37f, 20, 0.55f), ringCircleX(23.72f, bore, 0.2f, 20, 0.55f)}, false, true);
        m.cylinder({23.1f, 0, bore}, {23.73f, 0, bore}, 0.2f, 0.2f, 12, false);
    }

    // ---------------- Handguards (laminated wood) ----------------
    m.mat = wood;
    {
        // Lower: palm swells in the middle, a raised ridge along the top edge, rounded belly.
        std::vector<Ring> r;
        const float xs[] = {6.72f, 6.95f, 7.6f, 8.8f, 10.3f, 11.9f, 13.3f, 14.05f, 14.35f};
        const float ws[] = {0.76f, 0.8f, 0.86f, 0.9f, 0.88f, 0.9f, 0.85f, 0.79f, 0.74f};
        const float hs[] = {0.72f, 0.76f, 0.79f, 0.8f, 0.79f, 0.8f, 0.78f, 0.74f, 0.7f};
        for (int i = 0; i < 9; i++) r.push_back(ringRoundRect({xs[i], 0, bore - 0.2f}, Y, Z, ws[i], hs[i], 0.5f, 6));
        m.loft(r);
        m.mat = woodDk;
        // Finger ledge that runs along both sides (the AKM "swell" step).
        for (float s : {-1.0f, 1.0f}) {
            std::vector<Ring> rr;
            for (float x : {7.4f, 7.8f, 13.0f, 13.4f}) {
                float k = (x < 7.7f || x > 13.1f) ? 0.4f : 1.0f;
                rr.push_back(ringRoundRect({x, s * (0.86f + 0.02f * k), bore + 0.2f}, Y, Z, 0.03f * k + 0.005f, 0.07f, 0.02f, 2));
            }
            m.loft(rr);
        }
    }
    m.mat = wood;
    {
        // Upper: half-round cover over the gas tube with a flat bottom, three vent flutes on each side.
        std::vector<Ring> r;
        const float xs[] = {6.75f, 7.05f, 9.5f, 11.95f, 12.25f}, ws[] = {0.44f, 0.52f, 0.54f, 0.52f, 0.46f}, hs[] = {0.38f, 0.44f, 0.46f, 0.44f, 0.38f};
        for (int i = 0; i < 5; i++) r.push_back(ringRoundRect({xs[i], 0, bore + 0.98f}, Y, Z, ws[i], hs[i], 0.36f, 6));
        m.loft(r);
        m.mat = woodDk;
        m.mat.color = woodDk.color * 0.6f;
        for (float s : {-1.0f, 1.0f})
            for (int i = 0; i < 3; i++) m.box({8.1f + i * 1.3f, s * 0.525f, bore + 0.9f}, {0.42f, 0.02f, 0.07f}, 0.02f);
    }
    // Steel cap between the upper handguard and the rear sight block.
    m.mat = steel;
    m.cylinder({6.5f, 0, bore + 0.98f}, {6.8f, 0, bore + 0.98f}, 0.44f, 0.46f, 16, true, 0.05f);

    // ---------------- Stock ----------------
    m.mat = wood;
    // Wrist narrows behind the receiver, comb stays straight, the belly curves down to a tall butt.
    sectX(m, {{-6.3f, 0.2f, 0.5f, 0.86f, 0.36f}, {-6.9f, 0.08f, 0.52f, 0.95f, 0.4f}, {-8.0f, -0.18f, 0.55f, 1.06f, 0.44f},
              {-9.8f, -0.62f, 0.59f, 1.27f, 0.48f}, {-12.0f, -1.1f, 0.63f, 1.56f, 0.52f}, {-14.2f, -1.55f, 0.66f, 1.86f, 0.55f},
              {-15.6f, -1.86f, 0.67f, 2.02f, 0.55f}, {-16.02f, -1.95f, 0.66f, 2.04f, 0.52f}}, true, true, 6);
    // Stock tang strap on top (steel) running into the receiver.
    m.mat = steel;
    m.box({-7.2f, 0, 1.03f}, {0.9f, 0.3f, 0.05f}, 0.03f);
    screwHead(m, {-7.6f, 0, 1.06f}, 1.0f, 0.1f);
    // Sling loop (left side) and its rivets; butt plate with the cleaning kit trap door.
    torus(m, {-13.2f, 0.72f, -1.6f}, {0, 1, 0}, 0.34f, 0.05f, 16, 6);
    m.box({-13.2f, 0.67f, -1.22f}, {0.3f, 0.02f, 0.1f}, 0.02f);
    m.mat = steelDk;
    m.loft({ringRoundRect({-16.0f, 0, -1.95f}, Y, Z, 0.68f, 2.06f, 0.5f, 6), ringRoundRect({-16.3f, 0, -1.95f}, Y, Z, 0.66f, 2.04f, 0.48f, 6)});
    m.mat = steel;
    m.box({-16.32f, 0, -1.5f}, {0.03f, 0.42f, 0.55f}, 0.08f);
    screwHead(m, {-16.1f, 0.68f, -0.4f}, 1.0f, 0.08f);
    screwHead(m, {-16.1f, 0.68f, -3.4f}, 1.0f, 0.08f);

    // ---------------- Pistol grip, trigger guard, trigger, magazine release ----------------
    {
        m.mat = bake;
        vec3 up = normalize(vec3(0.356f, 0, 0.934f)), fwd(up.z, 0, -up.x);
        vec3 top(-0.65f, 0, -0.55f);
        struct G { float t, hu, hv, off; };
        const G g[] = {{0.0f, 0.44f, 0.64f, 0.0f}, {0.5f, 0.46f, 0.66f, 0.0f}, {1.3f, 0.49f, 0.67f, -0.03f}, {2.2f, 0.52f, 0.69f, -0.05f},
                       {3.1f, 0.53f, 0.7f, -0.04f}, {3.9f, 0.52f, 0.69f, 0.0f}, {4.45f, 0.49f, 0.65f, 0.03f}, {4.7f, 0.42f, 0.56f, 0.03f}, {4.78f, 0.3f, 0.4f, 0.03f}};
        std::vector<Ring> r;
        for (const G& s : g) r.push_back(ringSlanted(top - up * s.t + fwd * s.off, fwd, s.hu, s.hv, std::min(s.hu, s.hv) * 0.8f, 5));
        m.loft(r);
        // Finger swell on the front strap and the checkered panels on each side.
        m.mat = bake;
        m.mat.color = bake.color * 0.8f;
        for (float sd : {-1.0f, 1.0f}) {
            std::vector<Ring> pr;
            for (float t : {1.2f, 1.45f, 3.6f, 3.85f}) {
                float k = (t < 1.4f || t > 3.7f) ? 0.2f : 1.0f;
                pr.push_back(ringSlanted(top - up * t + Y * (sd * 0.5f), fwd, 0.02f * k + 0.005f, 0.42f, 0.02f, 2));
            }
            m.loft(pr);
        }
        m.mat = steelDk;
        m.cylinder(top - up * 4.72f, top - up * 4.86f, 0.13f, 0.12f, 12, true, 0.02f);  // grip screw
    }
    m.mat = steel;
    m.extrude(bandOutline({{1.02f, -0.72f}, {1.02f, -1.9f}, {0.86f, -2.2f}, {0.4f, -2.32f}, {-0.2f, -2.32f}, {-0.52f, -2.1f}, {-0.58f, -1.7f}}, 0.15f), 0.2f, 0.05f, 40);
    m.mat = steelDk;
    m.extrude(bandOutline(arcPts({-0.25f, -0.45f}, 0.75f, 1.3f, -38.0f, -86.0f, 10), 0.15f), 0.1f, 0.04f, 40);
    // Paddle magazine release behind the well.
    m.mat = steel;
    m.extrude({{1.1f, -0.75f}, {1.35f, -0.75f}, {1.45f, -1.35f}, {1.25f, -1.5f}, {1.05f, -1.4f}}, 0.24f, 0.05f, 30);

    // ---------------- Magazine (ribbed steel AKM) ----------------
    m.bone = WB_MAG;
    m.mat = magMat;
    {
        const vec2 top(2.4f, -0.75f);
        const float R = 15.0f, L = 9.0f, d0 = 2.8f, d1 = 3.3f;
        m.extrude(magOutline(top, R, L, d0, d1, 0.5f, 14), 0.5f, 0.1f, 30);
        // Raised stamped ribs following the curve, joined by the diagonal reinforcement near the base.
        for (float f : {-0.3f, -0.02f, 0.26f}) m.extrude(magBand(top, R, L, d0, d1, f - 0.06f, f + 0.06f, 0.1f, 0.86f, 14), 0.522f, 0.035f, 60);
        m.extrude(magBand(top, R, L, d0, d1, -0.36f, 0.32f, 0.86f, 0.9f, 6), 0.522f, 0.035f, 60);
        // Front and rear spines (folded seams).
        m.mat = magMat;
        m.mat.color = magMat.color * 0.85f;
        m.extrude(magBand(top, R, L, d0, d1, 0.47f, 0.52f, 0.02f, 0.94f, 14), 0.42f, 0.04f, 30);
        m.extrude(magBand(top, R, L, d0, d1, -0.52f, -0.47f, 0.02f, 0.94f, 14), 0.42f, 0.04f, 30);
        // Floor plate with its lip, locking lug at the front, feed lips on top.
        m.mat = steelDk;
        m.extrude(magBand(top, R, L, d0, d1, -0.56f, 0.58f, 0.94f, 1.0f, 4), 0.56f, 0.06f, 30);
        m.box({3.9f, 0, -0.95f}, {0.2f, 0.34f, 0.18f}, 0.05f);
        m.box({1.05f, 0, -0.9f}, {0.1f, 0.3f, 0.12f}, 0.03f);
    }

    // ---------------- Bolt carrier and charging handle ----------------
    m.bone = WB_BOLT;
    m.mat = steelBare;
    m.mat.color = {0.4f, 0.4f, 0.41f};
    m.cylinder({2.3f, -0.56f, 0.62f}, {2.3f, -0.95f, 0.62f}, 0.1f, 0.13f, 12);
    m.mat = steelDk;
    m.cylinder({2.3f, -0.93f, 0.62f}, {2.3f, -1.1f, 0.62f}, 0.19f, 0.18f, 14, true, 0.05f);
    m.sphere({2.3f, -1.1f, 0.62f}, {0.18f, 0.06f, 0.18f}, 12, 6);

    w.muzzle = {23.9f, 0, bore};
    w.eject = {1.2f, -0.6f, 1.0f};
    w.ejectDir = normalize(vec3(0.1f, -1.0f, 0.5f));
    w.magPivot = {3.9f, 0, -0.9f};
    w.magDrop = normalize(vec3(0.35f, 0, -1.0f));
    w.boltTravel = 3.6f;
    vec3 up = normalize(vec3(1.6f, 0, 4.2f));
    w.rightGrip = gripFrame(vec3(-0.65f, 0, -0.8f) - up * 1.75f, normalize(vec3(0.93f, 0.08f, -0.36f)), {0, -1, 0.15f}, {2.55f, 0.7f, -1.25f});
    w.leftGrip = supportUnderHandguard({8.2f, 0, bore - 0.22f});
    w.leftMagGrip = gripFrame({3.6f, 0.0f, -4.0f}, normalize(vec3(0.3f, -1.0f, -0.35f)), {-0.2f, 0.4f, -0.9f}, {2.3f, 0.2f, -1.2f});
    w.rightPose = poseTriggerGrip();
    w.leftPose = poseUnderHandguard();
    w.leftMagPose = poseMag();
    // Matches the CS2 framing: rifle parallel to the view, top of the receiver 2.7 below the eye.
    w.viewHold = {{17.6f, -8.6f, -4.85f}, quatFromEuler(0.6f, 1.8f, -1.5f)};
    w.shoulderL = {8.0f, 0.0f, -17.0f};
    w.poleL = {0.3f, 0.3f, -1.0f};
}

void buildM4(MeshBuilder& m, WeaponModel& w) {
    const float bore = 1.05f;
    const vec3 Y(0, 1, 0), Z(0, 0, 1);
    m.bone = WB_BODY;
    // --- Upper receiver (forged 7075, black hard anodized): flat-top with integral rail.
    m.mat = kAnodized;
    m.extrude({{-4.35f, 0.42f}, {3.95f, 0.42f}, {3.95f, 1.62f}, {3.7f, 1.78f}, {-4.1f, 1.78f}, {-4.35f, 1.55f}}, 0.5f, 0.09f);
    // Rounded barrel-nut shoulder at the front of the upper.
    m.cylinder({3.7f, 0, bore}, {4.25f, 0, bore}, 0.62f, 0.62f, 20, true, 0.05f);
    picatinny(m, -4.2f, 3.95f, {0, 0, 1.76f}, Z, 0.42f);
    // Ejection port (right side) with hinged dust cover, and the brass deflector bump behind it.
    m.mat = kDarkSteel;
    m.box({0.55f, -0.505f, 1.02f}, {1.15f, 0.02f, 0.3f}, 0.02f);
    m.mat = kAnodized;
    m.box({0.55f, -0.53f, 0.7f}, {1.2f, 0.035f, 0.05f}, 0.02f);   // dust cover hinge rod
    m.mat = kDarkSteel;
    slots(m, {0.05f, -0.54f, 1.02f}, {0.35f, 0, 0}, 4, {0.03f, 0.012f, 0.18f}, 0.6f);
    m.mat = kAnodized;
    m.extrude({{-1.05f, 0.9f}, {-0.55f, 0.9f}, {-0.7f, 1.55f}, {-1.05f, 1.6f}}, 0.18f, 0.06f, 30, -0.62f);
    // Forward assist: angled housing with a ribbed plunger.
    m.cylinder({-2.35f, -0.4f, 1.12f}, {-2.75f, -0.72f, 1.2f}, 0.27f, 0.25f, 16, true, 0.04f);
    m.mat = kDarkSteel;
    m.cylinder({-2.75f, -0.72f, 1.2f}, {-2.9f, -0.84f, 1.23f}, 0.22f, 0.22f, 16, true, 0.03f);
    for (int i = 0; i < 4; i++) m.box({-2.9f, -0.86f, 1.23f + (i - 1.5f) * 0.09f}, {0.03f, 0.02f, 0.03f}, 0.0f);
    // Rear takedown lugs and pivot pins.
    m.mat = kAnodized;
    for (float s : {-1.0f, 1.0f}) {
        pinEnd(m, {-3.85f, s * 0.5f, 0.3f}, s, 0.11f);
        pinEnd(m, {3.3f, s * 0.5f, 0.3f}, s, 0.11f);
    }

    // --- Lower receiver.
    m.mat = kAnodized;
    m.extrude({{-4.45f, 0.44f}, {3.8f, 0.44f}, {3.8f, -0.05f}, {3.55f, -0.35f}, {3.55f, -1.35f}, {3.2f, -1.55f}, {0.9f, -1.55f},
               {0.7f, -1.3f}, {0.7f, -0.45f}, {-1.55f, -0.45f}, {-2.9f, -0.35f}, {-4.45f, -0.25f}}, 0.49f, 0.08f);
    // Flared magwell lip and the raised fence around the magazine release (right side).
    m.extrude({{0.72f, -1.35f}, {3.62f, -1.35f}, {3.72f, -1.62f}, {0.6f, -1.62f}}, 0.56f, 0.07f);
    m.cylinder({2.9f, -0.5f, -0.35f}, {2.9f, -0.62f, -0.35f}, 0.2f, 0.2f, 14, true, 0.03f);
    m.mat = kDarkSteel;
    m.cylinder({2.9f, -0.6f, -0.35f}, {2.9f, -0.68f, -0.35f}, 0.14f, 0.14f, 14, true, 0.02f);
    // Bolt catch (left side), paddle shaped.
    m.mat = kAnodized;
    m.extrude({{2.5f, -0.1f}, {3.3f, 0.0f}, {3.35f, 0.3f}, {2.7f, 0.25f}}, 0.05f, 0.02f, 30, 0.52f);
    m.box({3.0f, 0.53f, 0.22f}, {0.25f, 0.04f, 0.04f}, 0.01f);
    // Selector: lever on the left over a detent plate.
    m.mat = kDarkSteel;
    m.cylinder({-1.9f, 0.5f, 0.02f}, {-1.9f, 0.58f, 0.02f}, 0.2f, 0.2f, 14, true, 0.03f);
    m.extrude({{-1.95f, -0.05f}, {-1.05f, 0.05f}, {-1.0f, 0.2f}, {-1.95f, 0.14f}}, 0.04f, 0.015f, 30, 0.6f);
    // Trigger guard (hinged loop) and curved trigger.
    m.mat = kAnodized;
    m.extrude(bandOutline({{0.72f, -0.5f}, {0.72f, -1.2f}, {0.55f, -1.38f}, {-0.35f, -1.38f}, {-0.6f, -1.3f}, {-0.7f, -1.05f}, {-0.7f, -0.55f}}, 0.13f), 0.2f, 0.05f, 40);
    m.mat = kDarkSteel;
    m.extrude(bandOutline(arcPts({-0.35f, -0.15f}, 0.85f, 0.95f, -70.0f, -110.0f, 8), 0.1f), 0.08f, 0.02f, 40);
    // A2 pistol grip with finger swell and stippled panels.
    m.mat = kPolymer;
    m.extrude({{-1.15f, -0.4f}, {0.02f, -0.4f}, {-0.18f, -1.3f}, {-0.5f, -2.1f}, {-0.45f, -2.4f}, {-0.62f, -2.65f}, {-0.85f, -3.3f},
               {-1.05f, -4.05f}, {-1.3f, -4.3f}, {-1.9f, -4.38f}, {-2.35f, -4.2f}, {-2.5f, -3.85f}, {-2.1f, -2.55f}, {-1.8f, -1.5f},
               {-1.6f, -0.85f}}, 0.52f, 0.24f, 35);
    m.mat = kRubber;
    m.box({-1.85f, 0, -4.34f}, {0.5f, 0.42f, 0.05f}, 0.03f);
    // Takedown screw on the grip side.
    m.mat = kDarkSteel;
    screwHead(m, {-1.45f, -0.53f, -1.05f}, -1.0f, 0.1f);
    // Receiver extension (buffer tube) with castle nut and end plate.
    m.mat = kAnodized;
    m.cylinder({-4.45f, 0, 1.0f}, {-11.3f, 0, 1.0f}, 0.58f, 0.58f, 20, true, 0.04f);
    m.box({-7.6f, 0, 0.45f}, {3.3f, 0.2f, 0.12f}, 0.04f);  // position rail on the tube bottom
    for (int i = 0; i < 7; i++) m.box({-5.2f - i * 0.72f, 0, 0.3f}, {0.09f, 0.14f, 0.06f}, 0.02f);
    m.mat = kDarkSteel;
    m.lathe({-4.45f, 0, 1.0f}, {-1, 0, 0}, {{0, 0.66f}, {0.45f, 0.66f}, {0.45f, 0.58f}}, 20);
    for (int i = 0; i < 8; i++) {
        float a = i * kTwoPi / 8;
        m.box({-4.68f, std::cos(a) * 0.67f, 1.0f + std::sin(a) * 0.67f}, {0.2f, 0.06f, 0.06f}, 0.01f);
    }
    m.mat = kAnodized;
    m.box({-4.52f, 0, 0.72f}, {0.08f, 0.62f, 0.55f}, 0.04f);  // end plate with sling loop
    torus(m, {-4.55f, 0.7f, 0.5f}, Y, 0.25f, 0.05f, 14, 6);
    // Collapsible stock: shell over the tube, cheek riser, latch lever, sling slot, rubber butt pad.
    m.mat = kPolymer;
    sectX(m, {{-7.7f, 1.05f, 0.58f, 0.78f, 0.45f}, {-8.2f, 1.02f, 0.66f, 0.88f, 0.5f}, {-11.6f, 0.95f, 0.72f, 0.95f, 0.52f},
              {-12.25f, 0.95f, 0.74f, 0.97f, 0.52f}});
    m.extrude({{-8.1f, 0.4f}, {-12.25f, 0.4f}, {-12.25f, -1.55f}, {-11.9f, -2.25f}, {-11.3f, -2.2f}, {-9.2f, -0.9f}, {-8.1f, -0.1f}}, 0.52f, 0.22f, 35);
    sectX(m, {{-8.4f, 1.85f, 0.36f, 0.12f, 0.1f}, {-9.0f, 2.05f, 0.5f, 0.12f, 0.1f}, {-12.0f, 2.1f, 0.55f, 0.14f, 0.12f}});
    m.mat = kPolySmooth;
    slots(m, {-10.4f, 0, -0.9f}, {0, 0, 0}, 1, {0.55f, 0.54f, 0.12f}, 0.3f);
    m.box({-8.6f, 0, -0.35f}, {0.4f, 0.14f, 0.1f}, 0.04f);  // adjustment latch
    m.mat = kRubber;
    m.extrude({{-12.2f, 2.2f}, {-12.55f, 2.2f}, {-12.6f, 1.9f}, {-12.6f, -1.55f}, {-12.3f, -2.3f}, {-12.1f, -2.3f}}, 0.72f, 0.12f);
    slots(m, {-12.61f, 0, 1.4f}, {0, 0, -0.45f}, 7, {0.02f, 0.6f, 0.08f}, 0.55f);

    // --- Handguard: quad rail (RIS) clamped to the barrel nut, with ribbed panels on the sides.
    m.mat = kAnodized;
    sectX(m, {{4.3f, bore, 0.8f, 0.8f, 0.3f}, {4.45f, bore, 0.84f, 0.84f, 0.32f}, {11.2f, bore, 0.84f, 0.84f, 0.32f}, {11.35f, bore, 0.78f, 0.78f, 0.3f}}, true, true, 5);
    picatinny(m, 4.4f, 11.25f, {0, 0, bore + 0.82f}, Z, 0.42f);
    picatinny(m, 4.4f, 11.25f, {0, 0.82f, bore}, Y, 0.42f);
    picatinny(m, 4.4f, 11.25f, {0, -0.82f, bore}, -Y, 0.42f);
    // Bottom rail covered by a ribbed polymer ladder panel where the support hand sits.
    m.mat = kPolymer;
    picatinny(m, 4.4f, 11.25f, {0, 0, bore - 0.82f}, -Z, 0.42f);
    m.mat = kPolySmooth;
    m.box({7.4f, 0, bore - 1.22f}, {2.6f, 0.46f, 0.1f}, 0.06f);
    for (int i = 0; i < 9; i++) m.box({5.2f + i * 0.55f, 0, bore - 1.33f}, {0.12f, 0.44f, 0.04f}, 0.03f);
    // Corner vents between rails.
    m.mat = kAnodized;
    for (float sy : {-1.0f, 1.0f})
        for (float sz : {-1.0f, 1.0f}) slots(m, {5.0f, sy * 0.6f, bore + sz * 0.6f}, {0.9f, 0, 0}, 7, {0.28f, 0.1f, 0.1f}, 0.25f);
    // Folding rear sight (BUIS) at the back of the rail.
    m.mat = kAnodized;
    m.box({-3.3f, 0, 2.17f}, {0.42f, 0.44f, 0.12f}, 0.04f);
    m.extrude({{-3.6f, 2.25f}, {-3.0f, 2.25f}, {-3.15f, 2.95f}, {-3.45f, 2.95f}}, 0.32f, 0.06f);
    m.mat = kDarkSteel;
    m.box({-3.3f, 0, 2.95f}, {0.1f, 0.24f, 0.1f}, 0.03f);
    // --- Front sight base (A-frame) on the gas block, with bayonet lug and sling swivel.
    m.mat = kGunmetal;
    m.cylinder({11.55f, 0, bore}, {12.55f, 0, bore}, 0.5f, 0.5f, 16, true, 0.06f);
    m.extrude({{11.6f, bore + 0.25f}, {12.5f, bore + 0.25f}, {12.25f, bore + 1.95f}, {11.85f, bore + 1.95f}}, 0.28f, 0.07f);
    m.extrude({{11.62f, bore + 1.7f}, {12.28f, bore + 1.7f}, {12.28f, bore + 2.28f}, {11.62f, bore + 2.28f}}, 0.36f, 0.06f);
    m.mat = kDarkSteel;
    m.cylinder({11.95f, 0, bore + 1.9f}, {11.95f, 0, bore + 2.52f}, 0.06f, 0.05f, 8);
    m.mat = kGunmetal;
    m.box({12.35f, 0, bore - 0.6f}, {0.28f, 0.15f, 0.22f}, 0.04f);
    torus(m, {11.95f, 0, bore - 0.95f}, Y, 0.22f, 0.04f, 12, 6);
    // Barrel: stepped M4 profile, gas tube, A2 birdcage flash hider.
    m.mat = kDarkSteel;
    m.cylinder({11.2f, 0, bore}, {11.6f, 0, bore}, 0.36f, 0.36f, 16);
    m.cylinder({12.5f, 0, bore}, {14.0f, 0, bore}, 0.36f, 0.33f, 16);
    m.cylinder({14.0f, 0, bore}, {18.7f, 0, bore}, 0.3f, 0.3f, 16);
    m.lathe({18.6f, 0, bore}, {1, 0, 0}, {{0, 0}, {0, 0.32f}, {0.35f, 0.4f}, {2.05f, 0.4f}, {2.2f, 0.34f}, {2.2f, 0.22f}, {2.2f, 0}}, 18);
    for (int i = 0; i < 4; i++) {  // birdcage slots (the bottom stays closed)
        float a = (i * 72.0f + 54.0f) * kDeg;
        vec3 d(0, std::cos(a), std::sin(a));
        m.mat = kDarkSteel;
        m.mat.color = kDarkSteel.color * 0.25f;
        m.box(vec3(19.75f, 0, bore) + d * 0.37f, vec3(0.62f, 0.07f, 0.07f), 0.03f);
    }
    // --- Magazine: aluminium STANAG with ribs, witness band and polymer follower visible at the top.
    m.bone = WB_MAG;
    m.mat = kAnodized;
    m.mat.color = {0.24f, 0.24f, 0.23f};
    m.extrude(magOutline({2.1f, -1.0f}, 40.0f, 6.8f, 2.3f, 2.45f, 0.6f), 0.45f, 0.1f);
    for (float f : {-0.3f, 0.3f}) m.extrude(magBand({2.1f, -1.0f}, 40.0f, 6.8f, 2.3f, 2.45f, f - 0.06f, f + 0.06f, 0.18f, 0.88f), 0.475f, 0.03f);
    m.extrude(magBand({2.1f, -1.0f}, 40.0f, 6.8f, 2.3f, 2.45f, -0.5f, 0.5f, 0.3f, 0.34f), 0.46f, 0.02f);
    m.mat = kPolymer;
    m.extrude({{0.95f, -7.65f}, {3.9f, -7.65f}, {4.05f, -7.85f}, {3.9f, -8.1f}, {0.95f, -8.1f}, {0.8f, -7.85f}}, 0.52f, 0.1f);
    m.box({2.4f, 0, -8.15f}, {1.1f, 0.3f, 0.04f}, 0.02f);
    // --- Charging handle (T-shape) at the rear of the upper.
    m.bone = WB_BOLT;
    m.mat = kAnodized;
    m.box({-4.35f, 0, 1.58f}, {0.18f, 0.2f, 0.13f}, 0.04f);
    m.extrude({{-4.2f, 1.45f}, {-4.55f, 1.45f}, {-4.7f, 1.58f}, {-4.55f, 1.72f}, {-4.2f, 1.72f}}, 0.62f, 0.07f);
    m.mat = kDarkSteel;
    m.box({-4.52f, 0.5f, 1.66f}, {0.12f, 0.12f, 0.05f}, 0.02f);  // latch

    w.muzzle = {20.9f, 0, bore};
    w.eject = {0.6f, -0.55f, 1.05f};
    w.ejectDir = normalize(vec3(0.1f, -1.0f, 0.5f));
    w.magPivot = {2.1f, 0, -1.0f};
    w.magDrop = {0.05f, 0, -1.0f};
    w.boltDir = {-1, 0, 0};
    w.boltTravel = 2.5f;
    vec3 up = normalize(vec3(1.2f, 0, 3.85f));
    w.rightGrip = gripFrame(vec3(-0.6f, 0, -0.35f) - up * 1.7f, normalize(vec3(0.95f, 0.08f, -0.3f)), {0, -1, 0.15f}, {2.55f, 1.0f, -1.25f});
    w.leftGrip = supportUnderHandguard({6.4f, 0, bore}, 1.3f);
    w.leftMagGrip = gripFrame({2.3f, 0.0f, -4.0f}, normalize(vec3(0.25f, -1.0f, -0.3f)), {-0.2f, 0.4f, -0.9f}, {2.3f, 0.2f, -1.15f});
    w.rightPose = poseTriggerGrip();
    w.leftPose = poseUnderHandguard();
    w.leftMagPose = poseMag();
    w.viewHold = {{15.9f, -8.6f, -5.25f}, quatFromEuler(0.6f, 1.8f, -1.5f)};
    w.shoulderL = {8.0f, 0.0f, -17.0f};
    w.poleL = {0.3f, 0.3f, -1.0f};
}

void buildAWP(MeshBuilder& m, WeaponModel& w) {
    const float bore = 1.3f;
    const vec3 Y(0, 1, 0), Z(0, 0, 1);
    m.bone = WB_BODY;
    // --- Thumbhole stock, olive green polymer panels over an aluminium chassis.
    m.mat = kAwpGreen;
    // Forend: deep, flat-sided, with a barrel channel and a flat bottom for the bipod stud.
    m.extrude({{-0.6f, 1.0f}, {12.2f, 0.95f}, {12.75f, 0.75f}, {12.9f, 0.2f}, {12.55f, -0.38f}, {3.4f, -0.45f}, {1.2f, -0.55f}, {-0.6f, -0.55f}}, 0.8f, 0.3f, 32);
    for (float s : {-1.0f, 1.0f}) {  // lightening grooves on the forend flanks
        m.mat.color = kAwpGreen.color * 0.72f;
        m.box({7.8f, s * 0.8f, 0.3f}, {3.6f, 0.03f, 0.1f}, 0.03f);
        m.mat = kAwpGreen;
    }
    // Pistol grip (vertical, thumbhole) with finger grooves.
    m.extrude({{-3.75f, -0.35f}, {-1.3f, -0.45f}, {-1.05f, -1.35f}, {-1.2f, -1.8f}, {-1.05f, -2.3f}, {-1.2f, -2.8f}, {-1.05f, -3.3f},
               {-1.2f, -3.8f}, {-1.05f, -4.3f}, {-1.3f, -4.8f}, {-2.1f, -5.05f}, {-3.0f, -4.95f}, {-3.3f, -4.5f}, {-3.1f, -2.8f}, {-3.55f, -1.4f}}, 0.62f, 0.28f, 35);
    // Upper comb and the lower bar joining the grip foot to the butt: the gap between them is the thumbhole.
    m.extrude({{-0.2f, 1.0f}, {-0.2f, -0.5f}, {-3.4f, -0.5f}, {-4.6f, -1.25f}, {-15.9f, -1.35f}, {-16.0f, 1.3f}, {-9.0f, 1.3f}}, 0.72f, 0.3f, 32);
    m.extrude({{-2.9f, -3.9f}, {-3.3f, -4.98f}, {-16.1f, -4.6f}, {-16.1f, -3.2f}, {-11.0f, -3.25f}, {-4.4f, -3.45f}}, 0.68f, 0.28f, 32);
    // Butt block with a spacer stack and a ventilated recoil pad.
    m.extrude({{-15.8f, 1.7f}, {-17.9f, 1.8f}, {-18.1f, 1.2f}, {-18.1f, -4.3f}, {-17.8f, -4.62f}, {-15.8f, -4.62f}}, 0.76f, 0.3f, 32);
    // Adjustable cheek piece on two posts, with a locking knob.
    m.extrude({{-7.6f, 1.52f}, {-15.3f, 1.52f}, {-15.4f, 2.12f}, {-8.4f, 2.12f}, {-7.4f, 1.85f}}, 0.66f, 0.26f, 32);
    m.mat = kSatin;
    m.mat.color = {0.34f, 0.35f, 0.36f};
    m.mat.metal = 0.9f;
    for (float x : {-9.5f, -13.5f}) m.cylinder({x, 0, 1.2f}, {x, 0, 1.6f}, 0.14f, 0.14f, 10);
    m.mat = kDarkSteel;
    m.cylinder({-11.5f, -0.62f, 0.4f}, {-11.5f, -0.95f, 0.4f}, 0.24f, 0.24f, 14, true, 0.04f);
    for (int i = 0; i < 10; i++) {
        float a = i * kTwoPi / 10;
        m.box({-11.5f + std::cos(a) * 0.24f, -0.8f, 0.4f + std::sin(a) * 0.24f}, {0.04f, 0.15f, 0.04f}, 0.01f);
    }
    m.mat = kRubber;
    m.box({-18.35f, 0, -1.4f}, {0.26f, 0.74f, 3.05f}, 0.14f);
    slots(m, {-18.6f, 0, 0.9f}, {0, 0, -0.55f}, 9, {0.02f, 0.6f, 0.07f}, 0.6f);
    m.mat = kSatin;
    m.mat.color = {0.3f, 0.3f, 0.31f};
    m.box({-18.02f, 0, -1.4f}, {0.06f, 0.72f, 3.0f}, 0.03f);  // spacer plate
    // Monopod spike under the butt, sling swivel studs.
    m.mat = kDarkSteel;
    m.cylinder({-17.0f, 0, -4.6f}, {-17.0f, 0, -5.45f}, 0.2f, 0.2f, 12, true, 0.04f);
    m.cylinder({-17.0f, 0, -5.45f}, {-17.0f, 0, -5.8f}, 0.3f, 0.05f, 12, true);
    torus(m, {-14.8f, 0, -4.85f}, Y, 0.28f, 0.05f, 14, 6);
    torus(m, {11.2f, 0, -0.75f}, Y, 0.28f, 0.05f, 14, 6);
    m.box({11.2f, 0, -0.48f}, {0.25f, 0.14f, 0.1f}, 0.04f);
    // --- Receiver: round steel action with flat sides, integral scope rail, ejection port.
    m.mat = kDarkSteel;
    sectX(m, {{-5.2f, bore + 0.05f, 0.62f, 0.72f, 0.5f}, {-4.9f, bore + 0.05f, 0.72f, 0.8f, 0.6f}, {6.1f, bore + 0.05f, 0.72f, 0.8f, 0.6f},
              {6.35f, bore + 0.05f, 0.62f, 0.7f, 0.5f}}, true, true, 5);
    picatinny(m, -4.8f, 6.0f, {0, 0, bore + 0.8f}, Z, 0.45f);
    m.mat.color = kDarkSteel.color * 0.35f;
    m.box({-0.8f, -0.69f, bore + 0.25f}, {1.7f, 0.04f, 0.32f}, 0.05f);
    m.mat = kSatin;  // bolt body visible through the port
    m.cylinder({-2.5f, -0.35f, bore + 0.25f}, {0.8f, -0.35f, bore + 0.25f}, 0.34f, 0.34f, 14);
    // Bolt shroud at the rear.
    m.mat = kDarkSteel;
    m.lathe({-5.2f, 0, bore}, {-1, 0, 0}, {{0, 0}, {0, 0.52f}, {0.6f, 0.55f}, {0.95f, 0.42f}, {1.1f, 0.2f}, {1.1f, 0}}, 18);
    // Action screws and the chassis bedding line.
    screwHead(m, {3.2f, -0.72f, 0.2f}, -1.0f, 0.13f);
    screwHead(m, {3.2f, 0.72f, 0.2f}, 1.0f, 0.13f);
    // Trigger guard (aluminium loop) and trigger blade.
    m.mat = kAnodized;
    m.extrude(bandOutline({{-1.35f, -0.5f}, {-1.2f, -1.8f}, {-0.6f, -2.35f}, {0.6f, -2.35f}, {1.2f, -1.9f}, {1.35f, -0.55f}}, 0.18f), 0.22f, 0.06f, 40);
    m.mat = kDarkSteel;
    m.extrude(bandOutline(arcPts({-0.15f, -0.6f}, 0.9f, 1.0f, -65.0f, -110.0f, 8), 0.12f), 0.1f, 0.03f, 40);
    // Magazine release catch in front of the guard.
    m.mat = kAnodized;
    m.box({2.2f + 1.3f, 0, -0.62f}, {0.2f, 0.3f, 0.12f}, 0.04f);
    // --- Barrel: heavy contour, recoil lug ring, muzzle brake with side ports.
    m.mat = kDarkSteel;
    m.cylinder({6.2f, 0, bore}, {8.0f, 0, bore}, 0.58f, 0.56f, 18);
    m.cylinder({8.0f, 0, bore}, {29.8f, 0, bore}, 0.52f, 0.42f, 18);
    for (int i = 0; i < 6; i++) {  // flutes
        float a = (i * 60.0f + 30.0f) * kDeg;
        m.mat.color = kDarkSteel.color * 0.55f;
        vec3 d(0, std::cos(a), std::sin(a));
        m.box(vec3(18.5f, 0, bore) + d * 0.44f, vec3(8.0f, 0.06f, 0.06f), 0.03f);
    }
    m.mat = kDarkSteel;
    m.lathe({29.7f, 0, bore}, {1, 0, 0}, {{0, 0}, {0, 0.45f}, {0.25f, 0.62f}, {3.0f, 0.62f}, {3.15f, 0.52f}, {3.15f, 0}}, 20);
    for (float x : {30.55f, 31.35f, 32.15f})
        for (float s : {-1.0f, 1.0f}) {
            m.mat.color = kDarkSteel.color * 0.2f;
            m.box({x, s * 0.6f, bore}, {0.2f, 0.06f, 0.36f}, 0.04f);
        }
    m.mat = kDarkSteel;
    // --- Scope: 30 mm tube, rings, windage/elevation turrets with caps, parallax knob, objective bell with sunshade.
    m.mat = kAnodized;
    for (float x : {-2.0f, 4.0f}) {
        m.box({x, 0, bore + 1.18f}, {0.38f, 0.5f, 0.3f}, 0.08f);
        m.cylinder({x - 0.38f, 0, bore + 2.1f}, {x + 0.38f, 0, bore + 2.1f}, 0.72f, 0.72f, 22, true, 0.06f);
        screwHead(m, {x, -0.52f, bore + 1.25f}, -1.0f, 0.1f);
    }
    m.cylinder({-4.0f, 0, bore + 2.1f}, {7.0f, 0, bore + 2.1f}, 0.58f, 0.58f, 24);
    m.cylinder({0.4f, 0, bore + 2.1f}, {2.6f, 0, bore + 2.1f}, 0.72f, 0.72f, 24, true, 0.1f);  // turret saddle
    // Elevation turret (top) and windage (right), knurled caps.
    for (int t = 0; t < 2; t++) {
        vec3 base = t == 0 ? vec3(1.5f, 0, bore + 2.7f) : vec3(1.5f, -0.65f, bore + 2.1f);
        vec3 dir = t == 0 ? Z : -Y;
        m.mat = kAnodized;
        m.cylinder(base, base + dir * 0.3f, 0.48f, 0.48f, 20, true, 0.04f);
        m.cylinder(base + dir * 0.3f, base + dir * 0.75f, 0.56f, 0.56f, 24, true, 0.06f);
        for (int i = 0; i < 20; i++) {
            float a = i * kTwoPi / 20;
            vec3 u = t == 0 ? vec3(std::cos(a), std::sin(a), 0) : vec3(std::cos(a), 0, std::sin(a));
            m.box(base + dir * 0.53f + u * 0.56f, t == 0 ? vec3(0.03f, 0.03f, 0.2f) : vec3(0.03f, 0.2f, 0.03f), 0.01f);
        }
        m.mat = kSatin;
        m.mat.color = {0.7f, 0.7f, 0.68f};
        m.box(base + dir * 0.52f + (t == 0 ? vec3(0, -0.57f, 0) : vec3(0, 0, 0.57f)), t == 0 ? vec3(0.02f, 0.01f, 0.12f) : vec3(0.02f, 0.12f, 0.01f), 0.0f);
    }
    m.mat = kAnodized;
    m.cylinder({1.5f, 0.6f, bore + 2.1f}, {1.5f, 1.05f, bore + 2.1f}, 0.45f, 0.45f, 20, true, 0.05f);  // parallax
    m.lathe({7.0f, 0, bore + 2.1f}, {1, 0, 0}, {{0, 0.58f}, {1.7f, 1.0f}, {2.4f, 1.02f}, {4.6f, 1.02f}, {4.7f, 0.95f}, {4.7f, 0}}, 24);
    m.lathe({-4.0f, 0, bore + 2.1f}, {-1, 0, 0}, {{0, 0.58f}, {0.9f, 0.62f}, {1.4f, 0.8f}, {2.6f, 0.82f}, {2.7f, 0.9f}, {3.3f, 0.9f}, {3.4f, 0.8f}, {3.4f, 0}}, 24);
    m.mat = kRubber;  // eyepiece rubber ring
    m.cylinder({-6.7f, 0, bore + 2.1f}, {-7.5f, 0, bore + 2.1f}, 0.92f, 0.95f, 24, true, 0.1f);
    m.mat = kLens;
    m.cylinder({11.66f, 0, bore + 2.1f}, {11.72f, 0, bore + 2.1f}, 0.9f, 0.9f, 24);
    m.cylinder({-7.52f, 0, bore + 2.1f}, {-7.56f, 0, bore + 2.1f}, 0.66f, 0.66f, 24);
    // --- Detachable box magazine.
    m.bone = WB_MAG;
    m.mat = kDarkSteel;
    m.box({1.9f, 0, -0.95f}, {1.35f, 0.45f, 0.95f}, 0.08f);
    for (float s : {-1.0f, 1.0f}) m.box({1.9f, s * 0.46f, -1.0f}, {1.0f, 0.02f, 0.6f}, 0.02f);
    m.mat = kAnodized;
    m.box({1.9f, 0, -1.95f}, {1.45f, 0.5f, 0.12f}, 0.05f);
    // --- Bolt handle with a large round knob (right side).
    m.bone = WB_BOLT;
    m.mat = kDarkSteel;
    m.cylinder({-3.0f, -0.4f, bore + 0.1f}, {-3.0f, -0.75f, bore + 0.1f}, 0.3f, 0.3f, 14, true, 0.05f);
    m.cylinder({-3.0f, -0.6f, bore}, {-3.0f, -1.9f, bore - 0.3f}, 0.15f, 0.13f, 12);
    m.sphere({-3.0f, -2.02f, bore - 0.33f}, {0.36f, 0.36f, 0.36f}, 16, 10);
    for (int i = 0; i < 6; i++) {  // knurled band around the knob
        float a = i * kTwoPi / 6;
        m.mat.color = kDarkSteel.color * 0.6f;
        m.box({-3.0f + std::cos(a) * 0.35f, -2.02f, bore - 0.33f + std::sin(a) * 0.35f}, {0.04f, 0.1f, 0.04f}, 0.01f);
    }

    w.muzzle = {32.8f, 0, bore};
    w.eject = {-1.5f, -0.7f, bore + 0.2f};
    w.ejectDir = normalize(vec3(0.0f, -1.0f, 0.6f));
    w.magPivot = {1.9f, 0, -0.2f};
    w.magDrop = {0, 0, -1};
    w.boltTravel = 3.2f;
    vec3 up = normalize(vec3(0.85f, 0, 3.9f));
    w.rightGrip = gripFrame(vec3(-1.1f, 0, -1.0f) - up * 1.55f, normalize(vec3(0.97f, 0.08f, -0.21f)), {0, -1, 0.15f}, {2.6f, 0.7f, -1.32f});
    w.leftGrip = supportUnderHandguard({6.5f, 0, 0.35f}, 1.5f);
    w.leftMagGrip = gripFrame({1.9f, 0, -2.2f}, normalize(vec3(0.2f, -1.0f, -0.3f)), {-0.1f, 0.4f, -0.9f}, {2.3f, 0.2f, -1.15f});
    w.rightBoltGrip = gripFrame({-3.0f, -2.02f, bore - 0.33f}, normalize(vec3(0.3f, 0.2f, 1.0f)), {0.1f, -1.0f, 0.1f}, {2.4f, 0.3f, -1.0f});
    w.rightPose = poseTriggerGrip();
    w.leftPose = poseUnderHandguard();
    w.leftMagPose = poseMag();
    w.viewHold = {{14.6f, -9.0f, -6.05f}, quatFromEuler(0.6f, 1.6f, -1.5f)};
    w.shoulderL = {8.0f, 0.0f, -17.0f};
    w.poleL = {0.3f, 0.3f, -1.0f};
}

struct PistolSpec {
    float slideLen, slideFront, slideTop, slideHW, slideBevel;
    Mat slideMat, frameMat;
    bool deagle, suppressor;
};

// Common frame: dust cover with accessory rail, trigger guard, trigger, grip. Style: 0 Glock, 1 USP, 2 Deagle.
void pistolFrame(MeshBuilder& m, const PistolSpec& s, int style) {
    const float fy = s.slideHW - 0.02f;
    m.mat = s.frameMat;
    float fz = s.slideTop - 1.0f;  // slide bottom
    float dcEnd = s.slideFront - (style == 2 ? 2.4f : 0.15f);
    // Frame body under the slide (rails) and the dust cover.
    m.extrude({{-3.35f, fz + 0.12f}, {dcEnd, fz + 0.12f}, {dcEnd, fz - 0.42f}, {dcEnd - 0.3f, fz - 0.6f}, {1.9f, fz - 0.6f}, {1.75f, fz - 0.35f},
               {-0.55f, fz - 0.35f}, {-3.35f, fz - 0.25f}}, fy, 0.08f);
    if (style != 2) {
        // Accessory rail grooves under the dust cover.
        for (int i = 0; i < 3; i++) slots(m, {dcEnd - 0.55f - i * 0.42f, 0, fz - 0.6f}, {0, 0, 0}, 1, {0.1f, fy + 0.005f, 0.05f}, 0.4f);
        for (float sd : {-1.0f, 1.0f}) slots(m, {(dcEnd + 1.9f) * 0.5f, sd * (fy + 0.005f), fz - 0.44f}, {0, 0, 0}, 1, {(dcEnd - 1.9f) * 0.5f - 0.1f, 0.01f, 0.03f}, 0.5f);
    }
    // Trigger guard: Glock square front with a finger hook, USP/Deagle rounded.
    std::vector<vec2> tg;
    if (style == 0) tg = {{1.85f, fz - 0.45f}, {1.9f, fz - 1.25f}, {1.72f, fz - 1.42f}, {0.2f, fz - 1.45f}, {-0.35f, fz - 1.35f}, {-0.55f, fz - 1.0f}, {-0.6f, fz - 0.4f}};
    else tg = cat(cat({{1.85f, fz - 0.45f}}, arcPts({1.25f, fz - 0.8f}, 0.62f, 0.65f, 0.0f, -90.0f, 6)), {{0.0f, fz - 1.45f}, {-0.4f, fz - 1.3f}, {-0.6f, fz - 0.9f}, {-0.62f, fz - 0.4f}});
    m.extrude(bandOutline(tg, style == 2 ? 0.2f : 0.16f), fy * 0.55f, 0.06f, 40);
    if (style == 0) m.extrude({{1.72f, fz - 1.33f}, {1.93f, fz - 1.36f}, {1.95f, fz - 1.55f}, {1.6f, fz - 1.5f}}, fy * 0.55f, 0.05f);
    // Trigger (Glock: with the safety blade in the middle).
    m.mat = style == 0 ? s.frameMat : kDarkSteel;
    m.extrude(bandOutline(arcPts({-0.05f, fz + 0.1f}, 0.78f, 1.25f, -62.0f, -95.0f, 7), 0.15f), 0.1f, 0.04f, 40);
    if (style == 0) {
        m.mat = kDarkSteel;
        m.extrude(bandOutline(arcPts({-0.05f, fz + 0.1f}, 0.8f, 1.25f, -66.0f, -92.0f, 6), 0.06f), 0.03f, 0.01f, 40);
    }
    // Grip.
    m.mat = s.frameMat;
    float gw = style == 2 ? 0.6f : 0.56f;
    std::vector<vec2> grip;
    if (style == 0)  // Glock: finger grooves on the front strap, flared magwell
        grip = {{-3.0f, fz - 0.2f}, {-0.62f, fz - 0.3f}, {-0.8f, fz - 1.1f}, {-0.97f, fz - 1.4f}, {-0.93f, fz - 1.7f}, {-1.14f, fz - 2.0f},
                {-1.1f, fz - 2.35f}, {-1.32f, fz - 2.65f}, {-1.3f, fz - 3.0f}, {-1.5f, fz - 3.5f}, {-1.62f, fz - 3.95f}, {-3.0f, fz - 4.1f},
                {-3.3f, fz - 3.85f}, {-3.15f, fz - 2.4f}, {-2.95f, fz - 1.0f}, {-3.2f, fz - 0.35f}};
    else if (style == 1)  // USP: smooth front strap, rounded backstrap
        grip = {{-3.0f, fz - 0.2f}, {-0.62f, fz - 0.3f}, {-0.85f, fz - 1.2f}, {-1.2f, fz - 2.4f}, {-1.45f, fz - 3.4f}, {-1.62f, fz - 4.0f},
                {-3.0f, fz - 4.1f}, {-3.28f, fz - 3.8f}, {-3.2f, fz - 2.4f}, {-3.02f, fz - 1.1f}, {-3.2f, fz - 0.4f}};
    else  // Desert Eagle: long, straight, rubber wrap
        grip = {{-3.6f, fz - 0.2f}, {-0.62f, fz - 0.3f}, {-0.85f, fz - 1.2f}, {-1.2f, fz - 2.4f}, {-1.5f, fz - 3.5f}, {-1.7f, fz - 4.15f},
                {-3.4f, fz - 4.3f}, {-3.75f, fz - 4.0f}, {-3.62f, fz - 2.4f}, {-3.5f, fz - 1.1f}, {-3.7f, fz - 0.4f}};
    m.extrude(grip, gw, style == 1 ? 0.24f : 0.13f, 35);
    if (style == 2) {
        // Wrap-around rubber grip with finger grooves on the front strap.
        m.mat = kRubber;
        m.extrude({{-3.45f, fz - 0.7f}, {-0.9f, fz - 0.8f}, {-1.05f, fz - 1.3f}, {-1.02f, fz - 1.65f}, {-1.2f, fz - 2.0f}, {-1.18f, fz - 2.4f},
                   {-1.38f, fz - 2.8f}, {-1.36f, fz - 3.2f}, {-1.62f, fz - 3.95f}, {-3.45f, fz - 4.05f}, {-3.7f, fz - 3.2f}, {-3.52f, fz - 1.4f}}, gw + 0.04f, 0.12f, 35);
    } else {
        // Stippled texture panel, flush with the grip (a thin shell with a different finish).
        m.mat = s.frameMat;
        m.mat.pattern = 4;
        m.mat.rough = 0.85f;
        m.extrude({{-2.8f, fz - 1.0f}, {-1.05f, fz - 1.05f}, {-1.4f, fz - 3.3f}, {-2.95f, fz - 3.35f}, {-2.85f, fz - 1.6f}}, gw + 0.004f, 0.02f, 35);
        m.mat = s.frameMat;
        m.extrude({{-3.1f, fz - 0.1f}, {-3.9f, fz - 0.28f}, {-3.85f, fz - 0.5f}, {-3.3f, fz - 0.55f}}, 0.4f, 0.12f);
    }
    // Slide stop (left) and takedown lever / pins.
    m.mat = kDarkSteel;
    m.extrude({{-0.9f, fz - 0.05f}, {0.9f, fz - 0.02f}, {0.95f, fz + 0.13f}, {-0.9f, fz + 0.13f}, {-1.15f, fz + 0.03f}}, 0.035f, 0.015f, 30, fy + 0.03f);
    for (float sd : {-1.0f, 1.0f}) pinEnd(m, {0.55f, sd * fy, fz - 0.2f}, sd, 0.08f);
    pinEnd(m, {-2.0f, fy, fz - 0.1f}, 1.0f, 0.06f);
    pinEnd(m, {-2.0f, -fy, fz - 0.1f}, -1.0f, 0.06f);
    // Magazine release button (left, behind the trigger guard).
    m.box({-0.72f, fy + 0.02f, fz - 0.75f}, {0.14f, 0.05f, 0.18f}, 0.04f);
}

void buildPistol(MeshBuilder& m, WeaponModel& w, const PistolSpec& s) {
    const int style = s.deagle ? 2 : s.suppressor ? 1 : 0;
    const vec3 Y(0, 1, 0);
    const float x0 = s.slideFront - s.slideLen, T = s.slideTop, hw = s.slideHW, fz = T - 1.0f;
    m.bone = WB_BODY;
    pistolFrame(m, s, style);
    if (style == 1) {
        // Exposed round-spur hammer and the decocker lever (left).
        m.mat = kDarkSteel;
        m.extrude({{x0 - 0.05f, fz + 0.1f}, {x0 + 0.15f, fz + 0.1f}, {x0 + 0.05f, fz + 0.75f}, {x0 - 0.25f, fz + 0.85f}, {x0 - 0.4f, fz + 0.65f}}, 0.17f, 0.06f, 35);
        m.extrude({{x0 + 0.2f, fz - 0.05f}, {x0 + 0.9f, fz - 0.02f}, {x0 + 0.95f, fz + 0.2f}, {x0 + 0.3f, fz + 0.25f}}, 0.05f, 0.02f, 30, hw + 0.02f);
    }
    if (style == 2) {
        // Hammer with a skeletonised spur.
        m.mat = kSatin;
        m.extrude({{x0 - 0.05f, fz + 0.05f}, {x0 + 0.2f, fz + 0.05f}, {x0 + 0.05f, fz + 0.7f}, {x0 - 0.35f, fz + 0.85f}, {x0 - 0.45f, fz + 0.55f}}, 0.2f, 0.06f, 35);
        // Fixed polygonal barrel with the triangular profile and a top rib, ahead of the slide.
        float bx0 = s.slideFront - 3.4f, bx1 = s.slideFront + 1.75f;
        m.mat = s.slideMat;
        std::vector<Ring> rings;
        for (float x : {bx0, bx1 - 0.08f, bx1}) {
            float k = x == bx1 ? 0.92f : 1.0f;
            Ring r;
            // Trapezoid: wide top, narrow bottom (the classic Desert Eagle barrel section).
            const vec2 pts[8] = {{0.46f, 0.1f}, {0.5f, 0.0f}, {0.4f, -0.72f}, {0.28f, -0.92f}, {-0.28f, -0.92f}, {-0.4f, -0.72f}, {-0.5f, 0.0f}, {-0.46f, 0.1f}};
            for (int i = 0; i < 8; i++) r.push_back({x, pts[i].x * k * (hw / 0.5f), T + pts[i].y * k - 0.02f});
            rings.push_back(r);
        }
        m.loft(rings);
        // Top rib with grooves, front sight, and the muzzle.
        m.box({(bx0 + bx1) * 0.5f, 0, T + 0.12f}, {(bx1 - bx0) * 0.5f - 0.05f, 0.2f, 0.06f}, 0.02f);
        for (float x = bx0 + 0.3f; x < bx1 - 0.3f; x += 0.3f) slots(m, {x, 0, T + 0.18f}, {0, 0, 0}, 1, {0.03f, 0.19f, 0.01f}, 0.5f);
        m.box({bx1 - 0.35f, 0, T + 0.28f}, {0.16f, 0.07f, 0.12f}, 0.02f);
        m.mat = kDarkSteel;
        m.mat.color = {0.03f, 0.03f, 0.03f};
        m.cylinder({bx1 - 0.02f, 0, T - 0.42f}, {bx1 + 0.02f, 0, T - 0.42f}, 0.24f, 0.24f, 14);
    }

    // --- Magazine (mostly hidden in the grip; visible base plate).
    m.bone = WB_MAG;
    m.mat = kDarkSteel;
    m.box({-2.05f, 0, fz - 2.2f}, {0.6f, 0.36f, 1.95f}, 0.05f);
    m.mat = style == 2 ? kDarkSteel : kPolymer;
    float mb = style == 2 ? fz - 4.3f : fz - 4.1f;
    m.extrude({{-3.35f, mb + 0.02f}, {-1.5f, mb + 0.05f}, {-1.45f, mb - 0.12f}, {-1.62f, mb - 0.22f}, {-3.3f, mb - 0.24f}, {-3.55f, mb - 0.1f}}, style == 2 ? 0.52f : 0.5f, 0.07f);

    // --- Slide.
    m.bone = WB_BOLT;
    m.mat = s.slideMat;
    float sx1 = style == 2 ? s.slideFront - 3.4f : s.slideFront;
    if (style == 0) {
        // Glock: flat-topped block with chamfered top edges and the angled "nose" at the front.
        m.extrude({{x0, T - 1.0f}, {sx1 - 0.35f, T - 1.0f}, {sx1, T - 0.72f}, {sx1, T - 0.08f}, {sx1 - 0.08f, T}, {x0 + 0.08f, T}, {x0, T - 0.1f}}, hw, 0.13f, 25);
    } else if (style == 1) {
        // USP: rounded top, the front narrows toward the muzzle.
        sectX(m, {{x0, T - 0.5f, hw - 0.02f, 0.49f, 0.2f}, {x0 + 0.12f, T - 0.5f, hw, 0.5f, 0.22f}, {sx1 - 1.3f, T - 0.5f, hw, 0.5f, 0.22f},
                  {sx1 - 0.1f, T - 0.52f, hw - 0.06f, 0.46f, 0.26f}, {sx1, T - 0.53f, hw - 0.1f, 0.42f, 0.24f}}, true, true, 5);
    } else {
        // Desert Eagle slide: tall, with a scalloped front and a flat top matching the barrel rib line.
        m.extrude({{x0, T - 1.0f}, {sx1, T - 1.0f}, {sx1, T - 0.05f}, {sx1 - 0.2f, T + 0.06f}, {x0 + 0.15f, T + 0.06f}, {x0, T - 0.08f}}, hw, 0.12f, 25);
        for (float sd : {-1.0f, 1.0f}) {  // ambidextrous safety levers
            m.mat = kSatin;
            m.extrude({{x0 + 0.1f, T - 0.55f}, {x0 + 0.85f, T - 0.52f}, {x0 + 0.9f, T - 0.32f}, {x0 + 0.05f, T - 0.28f}}, 0.04f, 0.015f, 30, sd * (hw + 0.03f));
            m.mat = s.slideMat;
        }
    }
    // Rear cocking serrations (and front serrations on the USP).
    int ns = style == 2 ? 9 : 7;
    for (float sd : {-1.0f, 1.0f}) {
        float sy = sd * (hw - (style == 1 ? 0.04f : 0.0f));
        slots(m, {x0 + 0.35f, sy, T - 0.52f}, {0.15f, 0, 0}, ns, {0.03f, 0.012f, 0.3f}, 0.6f);
        if (style == 1) slots(m, {sx1 - 1.45f, sy, T - 0.52f}, {0.15f, 0, 0}, 5, {0.03f, 0.012f, 0.26f}, 0.6f);
    }
    // Ejection port (right side / top) with the barrel hood visible inside.
    m.mat = kDarkSteel;
    m.mat.color = {0.06f, 0.06f, 0.065f};
    float epx = style == 2 ? x0 + 3.1f : x0 + 3.0f;
    m.box({epx, -hw * 0.3f, T - 0.022f}, {0.75f, hw * 0.68f, 0.03f}, 0.01f);
    m.box({epx, -hw + 0.004f, T - 0.2f}, {0.75f, 0.01f, 0.17f}, 0.01f);
    m.mat = kSatin;
    m.mat.color = style == 2 ? vec3(0.55f, 0.55f, 0.56f) : vec3(0.36f, 0.36f, 0.37f);
    m.box({epx + 0.1f, -0.05f, T - 0.012f}, {0.55f, 0.26f, 0.025f}, 0.01f);
    // Extractor (right).
    m.mat = s.slideMat;
    m.box({epx - 0.95f, -hw - 0.006f, T - 0.28f}, {0.18f, 0.012f, 0.05f}, 0.01f);
    // Sights: dovetailed rear with a U-notch, front post; white dots.
    m.mat = kDarkSteel;
    m.box({x0 + 0.35f, 0.21f, T + 0.1f}, {0.15f, 0.1f, 0.12f}, 0.02f);
    m.box({x0 + 0.35f, -0.21f, T + 0.1f}, {0.15f, 0.1f, 0.12f}, 0.02f);
    m.box({x0 + 0.35f, 0, T + 0.02f}, {0.16f, 0.32f, 0.05f}, 0.02f);
    float fsx = style == 2 ? s.slideFront + 1.4f : sx1 - 0.3f;
    float fsz = style == 2 ? T + 0.18f : T;
    if (style != 2) m.box({fsx, 0, fsz + 0.1f}, {0.1f, 0.06f, 0.11f}, 0.02f);
    Mat dot{{0.92f, 0.92f, 0.88f}, 0.4f, 0.0f, 0};
    m.mat = dot;
    for (float sd : {-1.0f, 1.0f}) m.sphere({x0 + 0.2f, sd * 0.21f, T + 0.12f}, {0.01f, 0.035f, 0.035f}, 8, 4);
    m.sphere({fsx - 0.1f, 0, fsz + 0.13f}, {0.01f, 0.03f, 0.03f}, 8, 4);
    if (style == 0) {
        // Glock 18 fire selector switch on the rear left of the slide.
        m.mat = kPolymer;
        m.box({x0 + 0.5f, hw + 0.04f, T - 0.25f}, {0.18f, 0.05f, 0.08f}, 0.03f);
        m.box({x0 + 0.6f, hw + 0.08f, T - 0.15f}, {0.06f, 0.03f, 0.12f}, 0.02f);
    }
    // Barrel crown in the slide front.
    if (style == 0) {
        m.mat = kDarkSteel;
        m.mat.color = {0.03f, 0.03f, 0.03f};
        m.cylinder({sx1 - 0.02f, 0, T - 0.55f}, {sx1 + 0.02f, 0, T - 0.55f}, 0.2f, 0.2f, 12);
        m.mat = kSatin;
        m.mat.color = {0.3f, 0.3f, 0.31f};
        torus(m, {sx1 + 0.01f, 0, T - 0.55f}, {1, 0, 0}, 0.24f, 0.04f, 14, 5);
    }
    if (s.suppressor) {
        // Threaded barrel stub and the USP-S suppressor: knurled rear collar, smooth tube, stepped front cap.
        m.bone = WB_BODY;
        float cz = T - 0.55f, a = sx1 - 0.05f;
        m.mat = kSatin;
        m.mat.color = {0.3f, 0.3f, 0.31f};
        m.cylinder({a, 0, cz}, {a + 0.3f, 0, cz}, 0.26f, 0.26f, 14);
        m.mat = kGunmetal;
        m.mat.color = {0.17f, 0.17f, 0.18f};
        m.lathe({a + 0.25f, 0, cz}, {1, 0, 0}, {{0, 0}, {0, 0.5f}, {0.08f, 0.6f}, {1.2f, 0.6f}, {1.3f, 0.62f}, {6.7f, 0.62f}, {6.85f, 0.58f},
                                                 {6.95f, 0.5f}, {7.0f, 0.2f}, {7.0f, 0}}, 26);
        for (int i = 0; i < 24; i++) {  // knurling on the collar
            float ang = i * kTwoPi / 24;
            m.box({a + 0.9f, std::cos(ang) * 0.6f, cz + std::sin(ang) * 0.6f}, {0.5f, 0.03f, 0.03f}, 0.01f);
        }
        m.mat.color = {0.1f, 0.1f, 0.1f};
        for (float xx : {a + 1.45f, a + 6.6f}) torus(m, {xx, 0, cz}, {1, 0, 0}, 0.62f, 0.025f, 26, 4);
    }

    float muzzleX = s.suppressor ? s.slideFront + 7.25f : s.deagle ? s.slideFront + 1.75f : s.slideFront + 0.05f;
    w.muzzle = {muzzleX, 0, s.slideTop - (s.deagle ? 0.42f : 0.55f)};
    w.eject = {0.6f, -0.5f, s.slideTop - 0.2f};
    w.ejectDir = normalize(vec3(0.0f, -1.0f, 0.7f));
    w.magPivot = {-2.2f, 0, -0.2f};
    w.magDrop = normalize(vec3(-0.18f, 0, -1.0f));
    w.boltTravel = 1.1f;
    vec3 up = normalize(vec3(0.72f, 0, 3.8f));
    vec3 gp = vec3(-1.62f, 0, 0.0f) - up * 1.62f;
    w.rightGrip = gripFrame(gp, normalize(vec3(0.98f, 0.08f, -0.19f)), {0, -1, 0.12f}, {2.5f, 0.45f, -1.28f});
    w.leftGrip = gripFrame(gp + vec3(0.25f, 0.0f, -0.55f), normalize(vec3(0.45f, -0.85f, -0.25f)), {0.25f, 0.9f, -0.35f}, {2.25f, -0.2f, -1.65f});
    w.leftMagGrip = gripFrame({-2.3f, 0, -4.4f}, normalize(vec3(0.2f, -0.6f, -1.0f)), {-0.3f, 0.8f, -0.3f}, {2.0f, 0.2f, -1.0f});
    w.rightPose = poseTriggerGrip();
    w.leftPose = poseSupportPistol();
    w.leftMagPose = poseMag();
    // Slide rear 13 units ahead, 4.2 right, slide top 1.4 below the eye: both hands show at the bottom right.
    float slideRear = s.slideFront - s.slideLen;
    w.viewHold = {{13.6f - slideRear, -5.3f, -1.9f - s.slideTop}, quatFromEuler(0.0f, 4.0f, -1.0f)};
    // Arms extended forward: elbows sit low and outside, so forearms enter from the bottom corners.
    w.shoulderR = {-4.0f, -7.0f, -12.0f};
    w.shoulderL = {-4.0f, 5.0f, -12.0f};
    w.poleR = {0.0f, -1.0f, -0.5f};
    w.poleL = {0.0f, 1.0f, -0.5f};
}

void buildKnife(MeshBuilder& m, WeaponModel& w) {
    m.bone = WB_BODY;
    // Blade: flat-ground with a clip point. Built as strips along X.
    m.mat = kBlade;
    const int N = 14;
    auto topZ = [](float t) { return t < 0.72f ? 0.42f : lerpf(0.42f, 0.02f, (t - 0.72f) / 0.28f); };
    auto botZ = [](float t) { return lerpf(-0.55f, 0.02f, std::pow(t, 2.2f)); };
    const float x0 = 2.05f, x1 = 7.4f, spine = 0.11f;
    std::vector<vec3> top, mid, edge;
    for (int i = 0; i <= N; i++) {
        float t = (float)i / N;
        float x = lerpf(x0, x1, t);
        float zt = topZ(t), zb = botZ(t);
        float zm = lerpf(zb, zt, 0.5f);
        float th = spine * (1.0f - 0.85f * std::pow(t, 3.0f));
        top.push_back({x, th, zt});
        mid.push_back({x, th * 0.92f, zm});
        edge.push_back({x, 0.004f, zb});
    }
    for (float sd : {-1.0f, 1.0f}) {
        for (int i = 0; i < N; i++) {
            auto S = [&](vec3 p) { return vec3(p.x, p.y * sd, p.z); };
            vec3 a = S(top[i]), b = S(top[i + 1]), c = S(mid[i + 1]), d = S(mid[i]);
            vec3 n = vec3(0, sd, 0);
            m.quad(m.vtx(a, n), m.vtx(b, n), m.vtx(c, n), m.vtx(d, n));
            vec3 e = S(edge[i]), f = S(edge[i + 1]);
            vec3 gn = normalize(vec3(0, sd * (d.z - e.z), (d.y - e.y) * sd * sd * 1.0f));
            gn = normalize(vec3(0, sd, -0.12f / std::max(0.05f, d.z - e.z)));
            m.quad(m.vtx(d, gn), m.vtx(c, gn), m.vtx(f, gn), m.vtx(e, gn));
        }
    }
    for (int i = 0; i < N; i++) {
        vec3 a = top[i], b = top[i + 1];
        vec3 n(0, 0, 1);
        if (b.z < a.z - 0.01f) n = normalize(vec3(a.z - b.z, 0, b.x - a.x));
        m.quad(m.vtx({a.x, a.y, a.z}, n), m.vtx({b.x, b.y, b.z}, n), m.vtx({b.x, -b.y, b.z}, n), m.vtx({a.x, -a.y, a.z}, n));
    }
    // Fuller (blood groove) along the spine side of the flat, and a swedge on the clip.
    m.mat = kBlade;
    m.mat.color = {0.5f, 0.5f, 0.52f};
    m.mat.rough = 0.3f;
    for (float sd : {-1.0f, 1.0f}) m.box({4.1f, sd * 0.1f, 0.2f}, {1.8f, 0.012f, 0.06f}, 0.01f);
    // Guard: blackened steel with short curved quillons.
    m.mat = kDarkSteel;
    m.extrude({{1.78f, -0.55f}, {1.95f, -0.6f}, {2.12f, -0.95f}, {2.02f, -1.05f}, {2.06f, -0.55f}, {2.06f, 0.5f}, {2.1f, 0.75f}, {1.96f, 0.8f}, {1.9f, 0.55f}, {1.78f, 0.5f}}, 0.3f, 0.06f, 35);
    // Handle: moulded rubber with finger grooves and a checkered grip zone.
    m.mat = kRubber;
    m.mat.pattern = 4;
    sectX(m, {{-3.2f, 0.03f, 0.36f, 0.5f, 0.3f}, {-2.6f, 0.04f, 0.4f, 0.55f, 0.34f}, {-1.9f, 0.08f, 0.41f, 0.52f, 0.34f}, {-1.55f, 0.0f, 0.42f, 0.58f, 0.35f},
              {-1.15f, 0.1f, 0.41f, 0.5f, 0.34f}, {-0.8f, 0.0f, 0.42f, 0.58f, 0.35f}, {-0.4f, 0.1f, 0.41f, 0.5f, 0.34f}, {0.0f, 0.02f, 0.42f, 0.57f, 0.35f},
              {0.5f, 0.1f, 0.41f, 0.5f, 0.34f}, {1.0f, 0.02f, 0.4f, 0.55f, 0.33f}, {1.6f, 0.0f, 0.38f, 0.53f, 0.3f}, {1.8f, 0.0f, 0.36f, 0.5f, 0.28f}}, true, true, 5);
    // Grip rings.
    m.mat = kRubber;
    for (float x : {-2.9f, -2.75f, 1.35f, 1.5f}) sectX(m, {{x - 0.04f, 0.03f, 0.43f, 0.58f, 0.36f}, {x + 0.04f, 0.03f, 0.43f, 0.58f, 0.36f}}, false, false, 5);
    // Pommel with a lanyard hole.
    m.mat = kDarkSteel;
    sectX(m, {{-3.25f, 0.03f, 0.4f, 0.56f, 0.32f}, {-3.55f, 0.03f, 0.4f, 0.56f, 0.32f}, {-3.75f, 0.03f, 0.3f, 0.44f, 0.26f}}, true, true, 5);
    slots(m, {-3.5f, 0, 0.03f}, {0, 0, 0}, 1, {0.1f, 0.41f, 0.1f}, 0.2f);

    w.muzzle = {7.4f, 0, 0};
    w.leftOnWeapon = false;
    // Hammer grip from below: fingers wrap over the handle, thumb side toward the blade, so the forearm comes from the bottom.
    w.rightGrip = gripFrame({-1.1f, 0, 0.0f}, {0.0f, 0.0f, 1.0f}, {0.0f, 1.0f, 0.0f}, {2.5f, 0.0f, -1.2f});
    w.leftGrip = w.rightGrip;
    w.rightPose = poseFist();
    w.leftPose = poseRelaxed();
    w.viewHold = {{11.5f, -6.6f, -5.7f}, quatFromEuler(32.0f, 28.0f, -28.0f)};
    w.shoulderR = {2.0f, -10.0f, -18.0f};
    w.poleR = {0.3f, -0.7f, -1.0f};
    w.shoulderL = {-3.0f, 8.0f, -10.0f};
}

void buildGrenade(MeshBuilder& m, WeaponModel& w, int id) {
    m.bone = WB_BODY;
    if (id == W_HE) {
        m.mat = {{0.28f, 0.33f, 0.20f}, 0.6f, 0.1f, 4};
        m.lathe({0, 0, -1.2f}, {0, 0, 1}, {{0, 0}, {0.1f, 0.6f}, {0.5f, 1.0f}, {1.2f, 1.12f}, {1.9f, 1.0f}, {2.3f, 0.6f}, {2.4f, 0.36f}, {2.4f, 0}}, 18);
    } else if (id == W_SMOKE) {
        m.mat = {{0.42f, 0.44f, 0.46f}, 0.5f, 0.4f, 5};
        m.cylinder({0, 0, -1.8f}, {0, 0, 1.6f}, 0.95f, 0.95f, 18, true, 0.12f);
        m.mat = {{0.75f, 0.60f, 0.15f}, 0.5f, 0.2f, 0};
        m.cylinder({0, 0, -0.3f}, {0, 0, 0.3f}, 0.97f, 0.97f, 18, false);
    } else {
        m.mat = {{0.30f, 0.32f, 0.34f}, 0.4f, 0.7f, 5};
        m.cylinder({0, 0, -1.6f}, {0, 0, 1.5f}, 0.8f, 0.8f, 16, true, 0.1f);
        m.mat = {{0.08f, 0.08f, 0.08f}, 0.6f, 0.0f, 0};
        for (int i = 0; i < 6; i++) {
            float a = i * kTwoPi / 6;
            m.box({std::cos(a) * 0.79f, std::sin(a) * 0.79f, 0.3f}, {0.08f, 0.08f, 0.35f}, 0.02f);
        }
    }
    if (id == W_HE) {  // yellow identification band
        m.mat = {{0.78f, 0.62f, 0.12f}, 0.5f, 0.0f, 0};
        m.lathe({0, 0, 0.35f}, {0, 0, 1}, {{0, 1.1f}, {0.14f, 1.08f}}, 24);
    } else if (id == W_SMOKE) {  // emission holes top and bottom, stencil band
        for (float z : {1.35f, -1.55f})
            for (int i = 0; i < 8; i++) {
                float a = i * kTwoPi / 8;
                m.mat = {{0.05f, 0.05f, 0.05f}, 0.8f, 0.0f, 0};
                m.box({std::cos(a) * 0.95f, std::sin(a) * 0.95f, z}, {0.06f, 0.06f, 0.08f}, 0.02f);
            }
    }
    // Fuze assembly: body, striker housing, curved safety spoon, pull ring with split pin.
    m.mat = kGunmetal;
    m.lathe({0, 0, 1.1f}, {0, 0, 1}, {{0, 0}, {0, 0.42f}, {0.35f, 0.42f}, {0.4f, 0.36f}, {0.85f, 0.34f}, {0.95f, 0.26f}, {0.95f, 0}}, 16);
    m.mat = {{0.46f, 0.47f, 0.44f}, 0.45f, 0.6f, 5};
    std::vector<vec2> spoonPath = {{0.1f, 2.1f}, {-0.3f, 2.12f}, {-0.5f, 1.95f}, {-0.55f, 1.4f}};
    std::vector<vec2> body = id == W_HE ? arcPts({0, -0.1f}, 1.16f, 1.22f, 105.0f, 185.0f, 8) : std::vector<vec2>{{-1.0f, 1.2f}, {-1.0f, -1.5f}};
    for (auto& p : body) spoonPath.push_back(p + vec2(-0.08f, 0));
    m.extrude(bandOutline(spoonPath, 0.08f), 0.32f, 0.02f, 40);
    m.cylinder({0.18f, 0.38f, 1.62f}, {0.18f, -0.1f, 1.62f}, 0.045f, 0.045f, 8);
    torus(m, {0.35f, 0.48f, 1.45f}, normalize(vec3(0.1f, 1.0f, 0.2f)), 0.45f, 0.055f, 22, 7);
    w.muzzle = {0, 0, 0};
    w.leftOnWeapon = false;
    w.rightGrip = gripFrame({0, 0, 0}, normalize(vec3(0.35f, 0.25f, 0.9f)), {-0.3f, -0.9f, 0.2f}, {2.2f, 0.2f, -1.55f});
    w.leftGrip = w.rightGrip;
    w.rightPose = poseFist();
    w.leftPose = poseRelaxed();
    w.viewHold = {{13.5f, -5.8f, -5.0f}, quatFromEuler(10.0f, 10.0f, 0.0f)};
    w.shoulderR = {2.0f, -10.0f, -18.0f};
    w.poleR = {0.3f, -0.7f, -1.0f};
    w.shoulderL = {-3.0f, 8.0f, -10.0f};
}

void buildC4(MeshBuilder& m, WeaponModel& w) {
    m.bone = WB_BODY;
    m.mat = {{0.62f, 0.56f, 0.40f}, 0.8f, 0.0f, 2};
    for (int i = 0; i < 3; i++) m.box({0, -1.1f + i * 1.1f, 0}, {3.0f, 0.52f, 0.8f}, 0.18f);
    m.mat = {{0.12f, 0.12f, 0.12f}, 0.5f, 0.0f, 0};
    m.box({0.4f, 0, 0.95f}, {2.0f, 1.3f, 0.2f}, 0.06f);
    m.mat = {{0.9f, 0.1f, 0.05f}, 0.3f, 0.0f, 8};
    m.box({-0.5f, 0, 1.16f}, {0.7f, 0.45f, 0.02f});
    m.mat = {{0.5f, 0.5f, 0.5f}, 0.4f, 0.3f, 0};
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < 3; c++) m.box({1.0f + c * 0.42f, -0.42f + r * 0.42f, 1.17f}, {0.15f, 0.15f, 0.03f}, 0.02f);
    m.mat = {{0.7f, 0.1f, 0.1f}, 0.5f, 0.0f, 0};
    m.cylinder({-3.0f, -1.1f, 0.5f}, {3.0f, -1.3f, 0.9f}, 0.08f, 0.08f, 6);
    m.mat = {{0.1f, 0.2f, 0.7f}, 0.5f, 0.0f, 0};
    m.cylinder({-3.0f, 1.1f, 0.5f}, {3.0f, 1.3f, 0.9f}, 0.08f, 0.08f, 6);
    w.leftOnWeapon = true;
    w.rightGrip = gripFrame({-1.0f, -1.6f, 0}, normalize(vec3(0.2f, 1.0f, 0.0f)), {0, 0, 1}, {2.3f, 0, -1.2f});
    w.leftGrip = gripFrame({-1.0f, 1.6f, 0}, normalize(vec3(0.2f, -1.0f, 0.0f)), {0, 0, 1}, {2.3f, 0, -1.2f});
    w.rightPose = poseMag();
    w.leftPose = poseMag();
    w.viewHold = {{14.0f, -1.0f, -9.0f}, quatFromEuler(25.0f, 0.0f, 0.0f)};
}

}  // namespace

FingerPose FingerPose::lerp(const FingerPose& a, const FingerPose& b, float t) {
    FingerPose r;
    for (int f = 0; f < 5; f++) {
        for (int j = 0; j < 3; j++) r.curl[f][j] = lerpf(a.curl[f][j], b.curl[f][j], t);
        r.spread[f] = lerpf(a.spread[f], b.spread[f], t);
    }
    r.thumbTwist = lerpf(a.thumbTwist, b.thumbTwist, t);
    return r;
}

FingerPose poseRelaxed() {
    return poseFrom({0.35f, 0.45f, 0.3f,  0.4f, 0.5f, 0.35f,  0.45f, 0.55f, 0.35f,  0.5f, 0.55f, 0.35f,
                     0.15f, 0.2f, 0.15f,  0.08f, 0.0f, -0.06f, -0.12f, 0.0f, 0.0f});
}

void buildWeaponModel(int id, Renderer& r, WeaponModel& w) {
    MeshBuilder m;
    w.id = id;
    switch (id) {
        case W_AK47: buildAK(m, w); break;
        case W_M4A4: buildM4(m, w); break;
        case W_AWP: buildAWP(m, w); break;
        case W_DEAGLE: buildPistol(m, w, {8.6f, 4.8f, 1.78f, 0.5f, 0.1f, kSatin, {{0.48f, 0.48f, 0.5f}, 0.36f, 1.0f, 10}, true, false}); break;
        case W_GLOCK: buildPistol(m, w, {7.0f, 3.75f, 1.68f, 0.46f, 0.06f, {{0.17f, 0.17f, 0.18f}, 0.42f, 0.6f, 5}, kPolymer, false, false}); break;
        case W_USP: buildPistol(m, w, {6.9f, 3.6f, 1.66f, 0.47f, 0.16f, {{0.12f, 0.12f, 0.13f}, 0.5f, 0.3f, 5}, kPolymer, false, true}); break;
        case W_HE: case W_SMOKE: case W_FLASH: buildGrenade(m, w, id); break;
        case W_C4: buildC4(m, w); break;
        default: buildKnife(m, w); break;
    }
    for (auto& v : m.verts) w.bounds.add(v.pos);
    solveWeaponGrips(m, w);
    m.bakeAO(1.6f, 40, 0.5f);
    w.mesh = m.upload(r);
}
