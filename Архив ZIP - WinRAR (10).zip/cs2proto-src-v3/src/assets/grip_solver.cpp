// Grip solver: seats procedural hands on procedural weapons and wraps the fingers around the real geometry.
//
// Hand-authored finger curls never match a mesh exactly, which reads as hands "floating" next to the gun.
// Here every grip is resolved against the weapon triangles at load time:
//   1. the hand slides along its palm normal until the palm touches the surface;
//   2. each finger closes joint by joint (knuckle first, then the middle and tip) until that phalanx
//      touches the weapon, like a real hand closing around an object.
// The support hand also collides with the shooting hand (pistol cup grip).
#include <cstdio>

#include "assets/models.h"

namespace {

inline float sq_(float x) { return x * x; }
float g_radiusScale = 0.92f;  // finger capsule radius factor; lowered to let fingers slip past sharp edges

struct Tri {
    vec3 a, b, c, center;
    float radius;
};

struct Capsule {
    vec3 a, b;
    float r;
};

struct Colliders {
    std::vector<Tri> tris;
    std::vector<Capsule> caps;
};

// Closest point on triangle (Ericson, Real-Time Collision Detection 5.1.5).
vec3 closestOnTri(vec3 p, vec3 a, vec3 b, vec3 c) {
    vec3 ab = b - a, ac = c - a, ap = p - a;
    float d1 = dot(ab, ap), d2 = dot(ac, ap);
    if (d1 <= 0 && d2 <= 0) return a;
    vec3 bp = p - b;
    float d3 = dot(ab, bp), d4 = dot(ac, bp);
    if (d3 >= 0 && d4 <= d3) return b;
    float vc = d1 * d4 - d3 * d2;
    if (vc <= 0 && d1 >= 0 && d3 <= 0) return a + ab * (d1 / (d1 - d3));
    vec3 cp = p - c;
    float d5 = dot(ab, cp), d6 = dot(ac, cp);
    if (d6 >= 0 && d5 <= d6) return c;
    float vb = d5 * d2 - d1 * d6;
    if (vb <= 0 && d2 >= 0 && d6 <= 0) return a + ac * (d2 / (d2 - d6));
    float va = d3 * d6 - d5 * d4;
    if (va <= 0 && (d4 - d3) >= 0 && (d5 - d6) >= 0) return b + (c - b) * ((d4 - d3) / ((d4 - d3) + (d5 - d6)));
    float denom = 1.0f / (va + vb + vc);
    return a + ab * (vb * denom) + ac * (vc * denom);
}

vec3 closestOnSeg(vec3 p, vec3 a, vec3 b) {
    vec3 ab = b - a;
    float t = clampf(dot(p - a, ab) / std::max(dot(ab, ab), 1e-8f), 0.0f, 1.0f);
    return a + ab * t;
}

bool touches(const Colliders& c, vec3 p, float r) {
    for (const Tri& t : c.tris) {
        if (length2(p - t.center) > sq_(t.radius + r)) continue;
        if (length2(p - closestOnTri(p, t.a, t.b, t.c)) < r * r) return true;
    }
    for (const Capsule& k : c.caps)
        if (length2(p - closestOnSeg(p, k.a, k.b)) < sq_(r + k.r)) return true;
    return false;
}


float nearest(const Colliders& c, vec3 p, float cutoff) {
    float best = cutoff * cutoff;
    for (const Tri& t : c.tris) {
        if (length2(p - t.center) > sq_(t.radius + cutoff)) continue;
        best = std::min(best, length2(p - closestOnTri(p, t.a, t.b, t.c)));
    }
    return std::sqrt(best);
}

Colliders gather(const MeshBuilder& m, vec3 center, float radius, int boneMask) {
    Colliders c;
    for (size_t i = 0; i + 2 < m.idx.size(); i += 3) {
        const ModelVertex& A = m.verts[m.idx[i]];
        const ModelVertex& B = m.verts[m.idx[i + 1]];
        const ModelVertex& C = m.verts[m.idx[i + 2]];
        int bone = (int)(A.mat >> 24);
        if (!((1 << bone) & boneMask)) continue;
        Tri t{A.pos, B.pos, C.pos, (A.pos + B.pos + C.pos) / 3.0f, 0};
        t.radius = std::sqrt(std::max({length2(t.a - t.center), length2(t.b - t.center), length2(t.c - t.center)}));
        if (length(t.center - center) - t.radius > radius) continue;
        c.tris.push_back(t);
    }
    return c;
}

vec3 palmPoint(vec3 p, bool left) { return left ? vec3(p.x, -p.y, p.z) : p; }

// Slides the hand along its palm normal until the palm rests on the surface.
float seatHand(Xform& grip, bool left, const Colliders& c, float gap = 0.06f) {
    const std::vector<vec3>& palm = handPalmSamples();
    vec3 n = rotate(grip.q, vec3(0, 0, -1));  // palm normal (points into the object)
    auto contact = [&](float s) {
        Xform h = grip;
        h.p = grip.p - n * s;
        for (const vec3& p : palm)
            if (touches(c, apply(h, palmPoint(p, left)), gap)) return true;
        return false;
    };
    const float start = 2.2f, end = -1.6f, step = 0.025f;
    if (contact(start)) return 0.0f;  // the palm would hit something else first: keep the authored grip
    for (float s = start - step; s >= end; s -= step) {
        if (contact(s)) {
            float found = s + step;
            grip.p = grip.p - n * found;
            return found;
        }
    }
    return 0.0f;
}

bool fingerHits(const Xform& hand, const FingerPose& pose, bool left, int f, int fromJoint, const Colliders& c) {
    Xform bones[15];
    poseFingers(hand, pose, left, bones);
    const HandGeom& g = handGeom();
    for (int k = fromJoint; k < 3; k++) {
        const Xform& b = bones[f * 3 + k];
        vec3 dir = rotate(b.q, vec3(1, 0, 0));
        float len = g.len[f][k] + (k == 2 ? 0.12f : 0.0f);
        float r = fingerRadius(f, k + 0.5f) * g_radiusScale;
        for (int s = (k == fromJoint ? 1 : 0); s <= 4; s++)
            if (touches(c, b.p + dir * (len * s / 4.0f), r)) return true;
    }
    return false;
}

// Sweeps one joint from open to maxC and stops just before the first contact that follows a free position.
// Joints that start inside geometry (a straight finger through a magazine) sweep out of it first.
int closeJoint(const Xform& hand, FingerPose& pose, bool left, int f, int j, float lo, float maxC, const Colliders& c) {
    float& cj = pose.curl[f][j];
    const float authored = cj, step = 0.025f;
    bool freeSeen = false, stopped = false;
    float last = authored;
    for (float v = lo; v <= maxC + 1e-4f; v += step) {
        cj = v;
        bool hit = fingerHits(hand, pose, left, f, j, c);
        if (!hit) { freeSeen = true; last = v; }
        else if (freeSeen) { stopped = true; break; }
    }
    cj = freeSeen ? last : authored;
    return !freeSeen ? 0 : stopped ? 1 : 2;  // 0 = stuck inside, 1 = touching, 2 = closed on nothing
}

// Picks the thumb orientation that lets it lie along the surface (instead of curling into the air), then closes it.
void solveThumb(const Xform& hand, FingerPose& pose, bool left, const Colliders& c) {
    const HandGeom& g = handGeom();
    FingerPose best = pose;
    float bestScore = 1e9f;
    float tw0 = pose.thumbTwist, sp0 = pose.spread[4];
    for (float dt = -1.2f; dt <= 1.21f; dt += 0.2f)
        for (float ds = -0.5f; ds <= 0.51f; ds += 0.125f)
            for (float c0 : {0.15f, 0.45f, 0.75f}) {
            FingerPose p = pose;
            p.thumbTwist = tw0 + dt;
            p.spread[4] = sp0 + ds;
            // The thumb metacarpal is buried in the palm pad: it is chosen, not collided.
            p.curl[4][0] = c0; p.curl[4][1] = 0.05f; p.curl[4][2] = 0.05f;
            bool clipped = false;
            const float maxC[3] = {1.0f, 0.9f, 0.8f};
            for (int j = 1; j < 3 && !clipped; j++)
                if (closeJoint(hand, p, left, 4, j, 0.05f, maxC[j], c) == 0) clipped = true;
            if (clipped) continue;
            Xform bones[15];
            poseFingers(hand, p, left, bones);
            // Average gap between the thumb pad and the surface; curled/open thumbs are penalized mildly.
            float gap = 0;
            int n = 0;
            for (int k = 1; k < 3; k++) {
                const Xform& b = bones[12 + k];
                vec3 dir = rotate(b.q, vec3(1, 0, 0));
                for (int s = 1; s <= 3; s++) { gap += nearest(c, b.p + dir * (g.len[4][k] * s / 3.0f), 3.0f); n++; }
            }
            gap /= n;
            float score = gap + 0.25f * (p.curl[4][1] + p.curl[4][2]) + 0.15f * (std::fabs(dt) + std::fabs(ds));
            if (score < bestScore) { bestScore = score; best = p; }
            }
    if (bestScore < 1e8f) { pose = best; return; }
    if (!c.caps.empty()) {  // boxed in by the other hand: solve against the weapon alone
        Colliders w = c;
        w.caps.clear();
        solveThumb(hand, pose, left, w);
    }
}

// Closes each finger joint by joint until it touches the object; joints that start inside are opened.
float closeFingers(const Xform& hand, FingerPose& pose, bool left, const Colliders& c, bool solveThumbToo = true) {
    float score = 0;
    for (int f = 0; f < 5; f++) {
        const bool thumb = f == 4;
        const float maxC[3] = {thumb ? 1.0f : 1.62f, thumb ? 1.05f : 1.72f, thumb ? 0.95f : 1.25f};
        if (thumb) {
            if (solveThumbToo) solveThumb(hand, pose, left, c);
            continue;
        }
        const float authoredF[3] = {pose.curl[f][0], pose.curl[f][1], pose.curl[f][2]};
        float fscore = 0;
        for (float rs : {0.92f, 0.6f}) {
            g_radiusScale = rs;
            fscore = 0;
            pose.curl[f][1] = pose.curl[f][2] = 0.05f;
            bool stuck = false;
            for (int j = 0; j < 3; j++) {
                float lo = j == 0 ? 0.0f : 0.05f;
                pose.curl[f][j] = lo;
                int st = closeJoint(hand, pose, left, f, j, lo, maxC[j], c);
                if (st == 0) { pose.curl[f][j] = authoredF[j]; fscore -= 1.0f; stuck = true; }
                else if (st == 1) fscore += j == 0 ? 1.0f : 0.5f;
            }
            // A straight finger lying flat along the surface is not a grip: retry with thinner fingers
            // so they can slip around the edge.
            if (!stuck && pose.curl[f][0] >= 0.35f) break;
            if (rs < 0.9f && (stuck || pose.curl[f][0] < 0.35f)) {
                for (int j = 0; j < 3; j++) pose.curl[f][j] = authoredF[j];
                fscore -= 0.6f;
            }
        }
        g_radiusScale = 0.92f;
        score += fscore;
    }
    return score;
}

// Tries small slides of the hand across the grip and keeps the one where the fingers wrap best.
void placeHand(Xform& grip, FingerPose& pose, bool left, const Colliders& c, bool seat, float range) {
    Xform bestG = grip;
    FingerPose bestP = pose;
    float bestScore = -1e9f;
    vec3 ax = rotate(grip.q, vec3(1, 0, 0)), ay = rotate(grip.q, vec3(0, 1, 0));
    for (float dx = -range; dx <= range + 1e-3f; dx += range / 2.0f)
        for (float dy = -range; dy <= range + 1e-3f; dy += range / 2.0f) {
            Xform g = grip;
            g.p += ax * dx + ay * dy;
            if (seat) seatHand(g, left, c);
            FingerPose p = pose;
            float sc = closeFingers(g, p, left, c, false) - 0.35f * (std::fabs(dx) + std::fabs(dy));
            if (sc > bestScore) { bestScore = sc; bestG = g; bestP = p; }
        }
    grip = bestG;
    pose = bestP;
    solveThumb(grip, pose, left, c);
}

void addHandCapsules(const Xform& hand, const FingerPose& pose, bool left, Colliders& c) {
    Xform bones[15];
    poseFingers(hand, pose, left, bones);
    const HandGeom& g = handGeom();
    for (int f = 0; f < 5; f++)
        for (int k = 0; k < 3; k++) {
            const Xform& b = bones[f * 3 + k];
            c.caps.push_back({b.p, b.p + rotate(b.q, vec3(1, 0, 0)) * g.len[f][k], fingerRadius(f, k + 0.5f)});
        }
    // Palm as a few fat capsules across the hand.
    for (float y : {-0.8f, 0.0f, 0.8f}) {
        vec3 a = apply(hand, palmPoint({0.3f, y, -0.1f}, left)), b = apply(hand, palmPoint({3.2f, y, -0.05f}, left));
        c.caps.push_back({a, b, 0.5f});
    }
}

}  // namespace

void solveWeaponGrips(const MeshBuilder& m, WeaponModel& w) {
    const WeaponDef& def = weaponDef(w.id);
    const int all = (1 << WB_BODY) | (1 << WB_MAG) | (1 << WB_BOLT) | (1 << WB_EXTRA);
    const bool firearm = def.cls == WC_RIFLE || def.cls == WC_SNIPER || def.cls == WC_PISTOL;

    // Shooting hand.
    Colliders body = gather(m, w.rightGrip.p, 10.0f, all);
    Xform r0 = w.rightGrip;
    placeHand(w.rightGrip, w.rightPose, false, body, true, 0.3f);
    float sr = length(w.rightGrip.p - r0.p);

    // Support hand: collides with the weapon and with the shooting hand.
    float sl = 0;
    if (w.leftOnWeapon) {
        Colliders sup = gather(m, w.leftGrip.p, 10.0f, all);
        addHandCapsules(w.rightGrip, w.rightPose, false, sup);
        Xform l0 = w.leftGrip;
        placeHand(w.leftGrip, w.leftPose, true, sup, def.cls != WC_PISTOL, 0.3f);
        sl = length(w.leftGrip.p - l0.p);
    }
    // Magazine hand during reloads (relative to the magazine, which moves with the grip).
    if (firearm) {
        Colliders mag = gather(m, w.leftMagGrip.p, 8.0f, 1 << WB_MAG);
        if (!mag.tris.empty()) {
            placeHand(w.leftMagGrip, w.leftMagPose, true, mag, true, 0.3f);
        }
    }
    // Bolt handle (AWP).
    w.rightBoltPose = w.leftMagPose;
    if (def.cls == WC_SNIPER) {
        Colliders bolt = gather(m, w.rightBoltGrip.p, 6.0f, 1 << WB_BOLT);
        w.rightBoltPose = poseRelaxed();
        if (!bolt.tris.empty()) closeFingers(w.rightBoltGrip, w.rightBoltPose, false, bolt);
    }
    std::printf("Grip %s: seat R %.2f L %.2f\n", def.name, sr, sl);
}
