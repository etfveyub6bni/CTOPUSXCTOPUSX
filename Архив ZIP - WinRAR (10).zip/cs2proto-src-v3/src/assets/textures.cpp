#include "assets/textures.h"

#include <atomic>
#include <thread>

#include "core/noise.h"

namespace {

struct Texel {
    float h = 0.5f;
    vec3 col{0.5f, 0.5f, 0.5f};
    float rough = 0.8f;
    float metal = 0.0f;
};

using GenFn = void (*)(float u, float v, Texel& o);

// Fast tileable gradient noise: gradients come from a table instead of per-corner trig.
struct GradTable {
    float gx[256], gy[256];
    GradTable() {
        for (int i = 0; i < 256; i++) {
            float a = (i + 0.5f) * (kTwoPi / 256.0f);
            gx[i] = std::cos(a);
            gy[i] = std::sin(a);
        }
    }
};
const GradTable kGrad;

inline uint32_t h2(int x, int y, uint32_t seed) {
    return noise::hash32((uint32_t)x * 0x8da6b343u ^ noise::hash32((uint32_t)y * 0xd8163841u ^ seed));
}
inline float h2f(int x, int y, uint32_t seed) { return (h2(x, y, seed) & 0xFFFFFFu) * (1.0f / 16777215.0f); }

// Resolution of the texture currently being generated (written before the worker threads start, read-only after).
int g_genSize = 1024;

// Band limiting: a noise octave with fewer than ~3 texels per cycle cannot be represented and turns into per-texel
// "salt and pepper" speckle (the grainy dots on sand/plaster, worst at low texture quality and in the normal map).
// Octaves fade out between 6 and 3 texels per cycle instead of aliasing.
inline float bandLimit(int period) {
    float texelsPerCycle = (float)g_genSize / (float)std::max(period, 1);
    return saturate((texelsPerCycle - 3.0f) / 3.0f);
}

// Gradient noise in about [-1, 1], periodic with px x py lattice cells.
float gnoise(float x, float y, int px, int py, uint32_t seed) {
    float bl = bandLimit(std::max(px, py));
    if (bl <= 0.0f) return 0.0f;
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    float fx = x - xi, fy = y - yi;
    int x0 = noise::wrapi(xi, px), x1 = noise::wrapi(xi + 1, px), y0 = noise::wrapi(yi, py), y1 = noise::wrapi(yi + 1, py);
    auto g = [&](int ix, int iy, float dx, float dy) {
        uint32_t h = h2(ix, iy, seed) & 255u;
        return kGrad.gx[h] * dx + kGrad.gy[h] * dy;
    };
    float n00 = g(x0, y0, fx, fy), n10 = g(x1, y0, fx - 1, fy), n01 = g(x0, y1, fx, fy - 1), n11 = g(x1, y1, fx - 1, fy - 1);
    float u = noise::fade(fx), v = noise::fade(fy);
    return lerpf(lerpf(n00, n10, u), lerpf(n01, n11, u), v) * 1.414f * bl;
}

// Tileable fBm over the unit square; fx/fy are the base lattice periods.
float fbmA(float u, float v, int fx, int fy, int oct, uint32_t seed, float gain = 0.5f) {
    float s = 0, a = 1, n = 0;
    for (int i = 0; i < oct; i++) {
        s += gnoise(u * fx, v * fy, fx, fy, seed + i * 131u) * a;
        n += a;
        a *= gain;
        fx *= 2;
        fy *= 2;
    }
    return s / n;
}
float fbm(float u, float v, int f, int oct, uint32_t seed, float gain = 0.5f) { return fbmA(u, v, f, f, oct, seed, gain); }
// Ridged fBm in [0, 1]: sharp creases (cracks, scratches).
float ridged(float u, float v, int f, int oct, uint32_t seed) {
    float s = 0, a = 0.5f, n = 0;
    for (int i = 0; i < oct; i++) {
        float r = 1.0f - std::fabs(gnoise(u * f, v * f, f, f, seed + i * 71u));
        s += r * r * a;
        n += a;
        a *= 0.5f;
        f *= 2;
    }
    return s / n;
}

struct Cell {
    float f1, f2;
    uint32_t id;
};
// Tileable Worley noise over a p x p grid (3x3 neighbourhood).
Cell worley(float x, float y, int p, uint32_t seed, float jitter = 0.8f) {
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    Cell c{1e9f, 1e9f, 0};
    for (int j = -1; j <= 1; j++)
        for (int i = -1; i <= 1; i++) {
            int cx = xi + i, cy = yi + j;
            uint32_t h = h2(noise::wrapi(cx, p), noise::wrapi(cy, p), seed);
            float px = cx + 0.5f + (((h & 0xFFFF) / 65535.0f) - 0.5f) * jitter;
            float py = cy + 0.5f + (((h >> 16) / 65535.0f) - 0.5f) * jitter;
            float d = std::sqrt((px - x) * (px - x) + (py - y) * (py - y));
            if (d < c.f1) {
                c.f2 = c.f1;
                c.f1 = d;
                c.id = noise::hash32(h ^ 0x9e3779b9u);
            } else if (d < c.f2) {
                c.f2 = d;
            }
        }
    return c;
}

vec3 mix3(vec3 a, vec3 b, float t) { return lerp(a, b, saturate(t)); }
float sstep(float a, float b, float x) { return smooth01((x - a) / (b - a)); }
float idf(uint32_t id, int shift) { return ((id >> shift) & 255u) / 255.0f; }
vec3 desat(vec3 c, float k) { float l = (c.x + c.y + c.z) / 3.0f; return lerp(c, vec3(l), k); }

// Speckle layer: sparse tiny grains of a different colour (mineral grains, grit). Returns -1..1 (dark..light), 0 = none.
// Fades out worley features that are too small for the texture being generated (they would alias into per-texel dots).
float wfade(int freq) { return saturate(((float)g_genSize / (float)freq - 4.0f) / 4.0f); }
float speckle(float u, float v, int freq, float occupancy, float radius, uint32_t seed) {
    float fade = wfade(freq);
    if (fade <= 0.0f) return 0.0f;
    Cell c = worley(u * freq, v * freq, freq, seed, 0.9f);
    if (idf(c.id, 0) > occupancy) return 0.0f;
    float r = radius * (0.6f + 0.8f * idf(c.id, 8));
    float m = sstep(r, r * 0.45f, c.f1);
    return m * (idf(c.id, 16) < 0.6f ? -1.0f : 1.0f) * (0.5f + 0.5f * idf(c.id, 24)) * fade;
}

// Sand: packed desert ground with wind ripples, multi-tone sediment, grit and scattered gravel. Tile = 256 units.
void genSand(float u, float v, Texel& o) {
    float big = fbm(u, v, 3, 4, 11);
    float mid = fbm(u, v, 12, 3, 12);
    float warp = fbm(u, v, 4, 2, 13);
    float rippleT = (v * 22.0f + u * 5.0f + warp * 2.6f);
    float ripple = std::sin(rippleT * kTwoPi);
    // Asymmetric ripple profile: gentle windward slope, steeper lee side.
    float rp = rippleT - std::floor(rippleT);
    float rippleA = rp < 0.7f ? sstep(0.0f, 0.7f, rp) : 1.0f - sstep(0.7f, 1.0f, rp);
    float rippleMask = sstep(-0.1f, 0.3f, fbm(u, v, 2, 3, 14));
    float grain = gnoise(u * 256, v * 256, 256, 256, 15) * 0.6f + gnoise(u * 512, v * 512, 512, 512, 16) * 0.4f;
    float grain2 = gnoise(u * 1024, v * 1024, 1024, 1024, 19);
    float trodden = sstep(0.05f, 0.35f, fbm(u, v, 5, 3, 17));  // compacted darker patches
    float rip = (0.6f * ripple + 0.4f * (rippleA * 2 - 1)) * rippleMask * (1 - trodden);
    float h = 0.45f + 0.10f * big + 0.05f * mid + 0.04f * rip + 0.03f * grain + 0.012f * grain2;

    // Several sediment tones instead of one flat beige: pale wind-blown sand, ochre, reddish iron-rich and grey dust.
    vec3 light{0.87f, 0.74f, 0.55f}, base{0.79f, 0.65f, 0.46f}, dark{0.64f, 0.51f, 0.37f};
    vec3 ochre{0.80f, 0.60f, 0.38f}, reddish{0.74f, 0.52f, 0.36f}, greyish{0.66f, 0.61f, 0.53f};
    vec3 col = mix3(base, light, 0.5f + big * 1.4f);
    col = mix3(col, ochre, sstep(0.05f, 0.4f, fbm(u, v, 4, 4, 181)) * 0.55f);
    col = mix3(col, reddish, sstep(0.18f, 0.5f, fbm(u, v, 6, 3, 182)) * 0.45f);
    col = mix3(col, greyish, sstep(0.15f, 0.45f, fbm(u, v, 5, 4, 183)) * 0.5f);
    col = mix3(col, dark, trodden * 0.35f + std::max(0.0f, -mid) * 0.6f);
    // Ripple crests catch lighter coarse grains, troughs collect darker fine sediment.
    col = col * (1.0f + 0.07f * rip);
    col = mix3(col, desat(col, 0.6f) * 0.95f, sstep(0.2f, 0.5f, fbm(u, v, 6, 3, 18)) * 0.3f);
    col = col * (0.93f + 0.10f * grain + 0.05f * grain2);
    // Mineral grit: dark (basalt, iron) and light (quartz) specks.
    float sp = speckle(u, v, 180, 0.22f, 0.32f, 184) + speckle(u, v, 340, 0.18f, 0.35f, 185) * 0.7f;
    col = col * (1.0f + 0.35f * sp);
    col = mix3(col, col * vec3(0.93f, 0.9f, 0.86f), std::max(0.0f, -sp) * 0.3f);
    float rough = 0.93f + 0.05f * grain;

    // Three scattered pebble layers (stones, gravel, grit); only a fraction of cells hold one and shapes are distorted.
    for (int layer = 0; layer < 3; layer++) {
        int freq = layer == 0 ? 18 : layer == 1 ? 44 : 96;
        float dist = fbm(u, v, freq * 2, 2, 20 + layer) * 0.18f;
        Cell c = worley(u * freq + dist, v * freq - dist, freq, 21 + layer, 0.9f);
        float occupancy = layer == 0 ? 0.035f : layer == 1 ? 0.07f : 0.12f;
        float lf = wfade(freq);
        if (idf(c.id, 0) > occupancy || lf <= 0.0f) continue;
        float r = (layer == 0 ? 0.20f : layer == 1 ? 0.22f : 0.26f) * (0.5f + idf(c.id, 8));
        float d = c.f1 / r;
        if (d >= 1.0f) {
            col = col * (1.0f - sstep(1.3f, 1.0f, d) * 0.14f);  // contact shadow in the sand
            continue;
        }
        float dome = std::sqrt(std::max(0.0f, 1 - d * d));
        vec3 pc = mix3({0.58f, 0.54f, 0.48f}, {0.82f, 0.75f, 0.64f}, idf(c.id, 16));
        float kind = idf(c.id, 24);
        if (kind < 0.25f) pc = mix3(pc, {0.60f, 0.45f, 0.33f}, 0.6f);        // iron-stained
        else if (kind < 0.4f) pc = mix3(pc, {0.40f, 0.38f, 0.36f}, 0.6f);    // dark basalt
        else if (kind > 0.88f) pc = mix3(pc, {0.90f, 0.88f, 0.84f}, 0.5f);   // quartz
        pc = pc * (0.86f + 0.22f * gnoise(u * 400, v * 400, 400, 400, 22 + layer)) * (0.88f + 0.16f * dome);
        // Dust settled on the upper part of the stone.
        pc = mix3(pc, col, sstep(0.6f, 0.2f, d) * 0.25f);
        float edge = sstep(1.0f, 0.86f, d) * lf;
        col = mix3(col, pc, edge);
        h += dome * lf * (layer == 0 ? 0.30f : layer == 1 ? 0.16f : 0.08f);
        rough = lerpf(rough, 0.62f + 0.12f * idf(c.id, 4), edge);
    }
    o.col = col * 1.05f;
    o.h = h;
    o.rough = rough;
}

// Sandstone blocks with recessed gritty mortar, pillowed eroded faces, strata, iron stains and chipped arrises.
// Tile = 128 units.
void genSandstone(float u, float v, Texel& o) {
    const int rows = 4;
    float nEdge = fbm(u, v, 16, 3, 23);
    float fr = v * rows;
    int row = (int)std::floor(fr);
    float rv = fr - row;
    int rowW = noise::wrapi(row, rows);
    int nb = 2 + (int)(h2(rowW, 0, 21) % 2u);
    float off = h2f(rowW, 1, 22);
    float fb = u * nb + off;
    int bi = (int)std::floor(fb);
    float bu = fb - bi;
    int bidx = noise::wrapi(bi, nb);
    uint32_t bh = h2(bidx * 7 + rowW, 3, 24);
    float ex = std::min(bu, 1 - bu) / nb, ey = std::min(rv, 1 - rv) / rows;
    float e = std::min(ex, ey) + nEdge * 0.007f;
    float chipN = fbm(u, v, 24, 3, 25);
    // Corners and arrises lose material: erosion grows near two edges at once.
    float corner = sstep(0.05f, 0.0f, std::max(ex, ey)) * 0.012f;
    float mortarW = 0.006f + 0.005f * std::max(0.0f, chipN) + corner + 0.004f * std::max(0.0f, fbm(u, v, 48, 2, 131));
    float face = sstep(mortarW, mortarW + 0.012f, e);
    float pillow = sstep(0.0f, 0.06f, e);

    float strata = std::sin((v * rows * 3.0f + fbm(u, v, 4, 3, 26) * 0.5f + idf(bh, 0) * 6.0f) * kTwoPi);
    float strataFine = std::sin((v * rows * 11.0f + fbm(u, v, 8, 2, 132) * 0.8f) * kTwoPi);
    float erosion = fbm(u, v, 10, 4, 27);
    Cell pits = worley(u * 36, v * 36, 36, 28, 0.9f);
    float pit = (idf(pits.id, 0) < 0.10f) ? sstep(0.22f, 0.05f, pits.f1) * 0.6f : 0.0f;
    Cell pits2 = worley(u * 90, v * 90, 90, 133, 0.9f);
    float pit2 = (idf(pits2.id, 0) < 0.12f) ? sstep(0.25f, 0.08f, pits2.f1) * 0.5f * wfade(90) : 0.0f;
    float fine = gnoise(u * 256, v * 256, 256, 256, 29);
    float fine2 = gnoise(u * 512, v * 512, 512, 512, 134);

    // Wider palette: warm honey, pale buff, pinkish and greyish blocks.
    const vec3 tones[6] = {{0.84f, 0.70f, 0.51f}, {0.80f, 0.64f, 0.46f}, {0.86f, 0.74f, 0.56f},
                           {0.80f, 0.66f, 0.53f}, {0.76f, 0.68f, 0.56f}, {0.83f, 0.66f, 0.50f}};
    vec3 stone = mix3(tones[bh % 6u], tones[(bh >> 3) % 6u], idf(bh, 8));
    stone = stone * (0.93f + 0.10f * idf(bh, 16));
    float weather = fbm(u, v, 3, 4, 31);
    stone = stone * (0.97f + 0.03f * strata + 0.015f * strataFine) * (0.92f + 0.14f * erosion) * (0.96f + 0.05f * fine + 0.03f * fine2) *
            (0.93f + 0.14f * weather);
    stone = mix3(stone, stone * vec3(0.92f, 0.86f, 0.80f), sstep(0.1f, 0.5f, fbm(u, v, 5, 3, 30)) * 0.5f);
    // Iron-oxide bands and blotches.
    float iron = sstep(0.25f, 0.6f, fbm(u, v, 6, 4, 135)) * (0.5f + 0.5f * strata);
    stone = mix3(stone, stone * vec3(1.02f, 0.84f, 0.68f), iron * 0.45f);
    // Dark weathering crust / lichen specks on exposed faces.
    float lichen = sstep(0.3f, 0.55f, fbm(u, v, 12, 3, 136)) * sstep(0.2f, 0.6f, fbm(u, v, 3, 2, 137));
    stone = mix3(stone, stone * vec3(0.62f, 0.60f, 0.56f), lichen * 0.35f);
    float sp = speckle(u, v, 200, 0.2f, 0.3f, 138);
    stone = stone * (1.0f - pit * 0.22f - pit2 * 0.15f) * (1.0f + 0.2f * sp);
    vec3 mortar = vec3(0.70f, 0.61f, 0.49f) * (0.88f + 0.15f * fine) * (1.0f + 0.25f * speckle(u, v, 300, 0.3f, 0.35f, 139));

    o.col = mix3(mortar, stone, face) * 1.05f;
    o.h = 0.2f + face * (0.45f + 0.18f * pillow + 0.07f * erosion + 0.012f * strata + 0.006f * strataFine - pit * 0.08f - pit2 * 0.04f) +
          fine * 0.015f + fine2 * 0.006f;
    o.rough = lerpf(0.95f, 0.84f + 0.06f * erosion + 0.04f * lichen, face);
}

// Lime plaster: trowel undulation, knock-down spatter, multi-tone lime-wash, patch repairs, stains,
// hairline cracks and spalled chips. Exposed brick patches are placed in world space by the shader. Tile = 256 units.
void genPlaster(float u, float v, Texel& o) {
    float big = fbm(u, v, 2, 4, 31);
    float trowel = fbm(u, v, 7, 3, 32);
    // Directional trowel strokes (short arcs).
    float strokes = fbmA(u + fbm(u, v, 3, 2, 141) * 0.08f, v, 6, 22, 3, 142);
    float fine = gnoise(u * 256, v * 256, 256, 256, 33) * 0.6f + gnoise(u * 512, v * 512, 512, 512, 34) * 0.4f;
    float fine2 = gnoise(u * 1024, v * 1024, 1024, 1024, 143);
    float blot = sstep(0.05f, 0.45f, fbm(u, v, 4, 4, 35));
    float streak = sstep(0.0f, 0.6f, fbmA(u, v, 24, 2, 3, 36)) * sstep(0.2f, 0.9f, fbm(u, v, 3, 2, 37) + 0.3f);
    float crackMask = sstep(0.2f, 0.4f, fbm(u, v, 3, 3, 38));
    float cr = ridged(u + fbm(u, v, 5, 2, 39) * 0.03f, v, 6, 3, 40);
    float crack = sstep(0.92f, 0.985f, cr) * crackMask;
    float crackHalo = sstep(0.85f, 0.95f, cr) * crackMask * (1 - crack);
    Cell pits = worley(u * 64, v * 64, 64, 41, 0.9f);
    float pit = idf(pits.id, 0) < 0.04f ? sstep(0.18f, 0.06f, pits.f1) * 0.6f : 0.0f;
    // Knock-down spatter: flattened blobs of the finishing coat.
    Cell sp = worley(u * 120 + fbm(u, v, 30, 2, 144) * 0.3f, v * 120, 120, 145, 0.9f);
    float spatter = idf(sp.id, 0) < 0.45f ? sstep(0.45f, 0.25f, sp.f1) * wfade(120) : 0.0f;
    float wash = sstep(0.28f, 0.34f, fbm(u, v, 5, 4, 42));  // worn lime-wash layer
    // Patch repairs: rectangular-ish areas re-plastered in a slightly different tone.
    Cell pr = worley(u * 5 + fbm(u, v, 10, 2, 146) * 0.15f, v * 5, 5, 147, 0.7f);
    float patch = idf(pr.id, 0) < 0.22f ? sstep(0.36f, 0.32f, pr.f1) : 0.0f;
    float patchEdge = idf(pr.id, 0) < 0.22f ? sstep(0.30f, 0.34f, pr.f1) * sstep(0.38f, 0.34f, pr.f1) : 0.0f;
    // Spalled chips: finishing coat gone, rough base coat visible.
    float spall = sstep(0.40f, 0.44f, fbm(u, v, 9, 4, 148)) * sstep(0.15f, 0.45f, fbm(u, v, 3, 2, 149)) * 0.8f;

    vec3 c = mix3({0.84f, 0.75f, 0.61f}, {0.90f, 0.83f, 0.70f}, 0.5f + big * 1.3f);
    c = mix3(c, vec3(0.88f, 0.80f, 0.66f), sstep(0.0f, 0.4f, fbm(u, v, 3, 3, 150)) * 0.5f);       // warm cream wash
    c = mix3(c, vec3(0.80f, 0.76f, 0.68f), sstep(0.15f, 0.45f, fbm(u, v, 4, 3, 151)) * 0.45f);    // greyish wash
    c = mix3(c, c * vec3(0.95f, 0.92f, 0.88f), wash * 0.6f);
    c = mix3(c, desat(c, 0.35f) * vec3(0.86f, 0.82f, 0.78f), blot * 0.3f);
    c = mix3(c, c * vec3(0.80f, 0.74f, 0.68f), streak * 0.38f);
    c = mix3(c, c * (0.93f + 0.1f * idf(pr.id, 8)) * vec3(1.0f, 0.98f, 0.95f), patch);
    c = c * (0.965f + 0.05f * trowel + 0.03f * strokes) * (0.97f + 0.045f * fine + 0.02f * fine2) * (1.0f + 0.03f * spatter);
    vec3 baseCoat = c * vec3(0.90f, 0.86f, 0.80f) * (0.9f + 0.15f * fine);
    c = mix3(c, baseCoat, spall);
    c = c * (1.0f - crack * 0.4f - crackHalo * 0.06f - pit * 0.3f - patchEdge * 0.03f);
    o.col = c;
    o.h = 0.6f + trowel * 0.05f + strokes * 0.02f + big * 0.03f + fine * 0.012f + fine2 * 0.004f + wash * 0.015f + spatter * 0.012f +
          patch * 0.01f - crack * 0.08f - pit * 0.08f - spall * 0.06f;
    o.rough = 0.9f + 0.05f * fine - wash * 0.04f - patch * 0.03f + spall * 0.04f;
}

// Stone floor tiles, staggered, with wear, chipped corners, per-tile colour and dirty grout. Tile = 128 units.
void genTiles(float u, float v, Texel& o) {
    const int n = 4;
    float fu = u * n, fv = v * n;
    int iv = (int)std::floor(fv);
    if (iv & 1) fu += 0.5f;
    int iu = (int)std::floor(fu);
    float bu = fu - iu, bv = fv - iv;
    float nn = fbm(u, v, 12, 3, 43);
    float ex = std::min(bu, 1 - bu) / n, ey = std::min(bv, 1 - bv) / n;
    float corner = sstep(0.03f, 0.0f, std::max(ex, ey)) * 0.01f * (0.5f + std::max(0.0f, fbm(u, v, 20, 2, 161)) * 2.0f);
    float e = std::min(ex, ey) + nn * 0.004f - corner;
    float chip = std::max(0.0f, fbm(u, v, 40, 2, 162)) * 0.004f;
    float face = sstep(0.006f + chip, 0.014f + chip, e);
    uint32_t id = h2(noise::wrapi(iu, n), noise::wrapi(iv, n), 44);
    float fine = gnoise(u * 256, v * 256, 256, 256, 45);
    float fine2 = gnoise(u * 512, v * 512, 512, 512, 163);
    float wear = sstep(-0.2f, 0.4f, fbm(u, v, 6, 3, 46));
    vec3 stone = mix3({0.70f, 0.63f, 0.53f}, {0.82f, 0.75f, 0.64f}, idf(id, 0));
    if (idf(id, 24) < 0.2f) stone = mix3(stone, {0.66f, 0.56f, 0.44f}, 0.6f);
    else if (idf(id, 24) > 0.85f) stone = mix3(stone, {0.72f, 0.70f, 0.66f}, 0.5f);
    // Veins and fossil-like pits in limestone.
    float vein = sstep(0.9f, 0.98f, ridged(u + idf(id, 4), v, 5, 3, 164)) * (idf(id, 20) < 0.5f ? 1.0f : 0.3f);
    Cell ps = worley(u * 80, v * 80, 80, 165, 0.9f);
    float pore = idf(ps.id, 0) < 0.08f ? sstep(0.25f, 0.08f, ps.f1) * wfade(80) : 0.0f;
    stone = stone * (0.92f + 0.12f * fbm(u, v, 16, 3, 47)) * (0.96f + 0.05f * fine + 0.03f * fine2);
    stone = mix3(stone, stone * 1.07f, wear * 0.5f);
    stone = mix3(stone, stone * vec3(1.08f, 1.06f, 1.02f), vein * 0.5f);
    stone = stone * (1.0f - pore * 0.25f) * (1.0f + 0.15f * speckle(u, v, 220, 0.15f, 0.3f, 166));
    // Dirt collects along the tile borders.
    stone = mix3(stone, stone * vec3(0.8f, 0.75f, 0.68f), sstep(0.03f, 0.012f, e) * 0.4f);
    float cr = ridged(u, v, 8, 3, 48);
    float crack = idf(id, 16) < 0.25f ? sstep(0.95f, 0.99f, cr) : 0.0f;
    float tu = (idf(id, 8) - 0.5f) * 0.12f, tv = (idf(id, 12) - 0.5f) * 0.12f;
    vec3 grout = vec3(0.56f, 0.49f, 0.39f) * (0.88f + 0.14f * fine) * (1.0f + 0.3f * speckle(u, v, 300, 0.3f, 0.35f, 167));
    o.col = mix3(grout, stone * (1 - crack * 0.3f), face) * 1.06f;
    o.h = 0.3f + face * (0.5f + tu * (bu - 0.5f) + tv * (bv - 0.5f) + nn * 0.04f - crack * 0.06f - pore * 0.04f - wear * 0.02f) +
          fine * 0.01f + fine2 * 0.004f;
    o.rough = lerpf(0.96f, 0.80f - wear * 0.14f, face);
}

// Wood grain along `along`: returns 0..1 with growth rings and fibres; `knot` gets a knot mask.
float woodGrain(float along, float across, uint32_t seed, float& knot) {
    float warp = fbmA(along, across, 2, 4, 3, seed) * 0.8f;
    float ring = std::sin((across * 26.0f + warp * 3.0f) * kTwoPi) * 0.5f + 0.5f;
    ring = ring * ring * ring;
    float fibre = gnoise(along * 8, across * 180, 8, 180, seed + 3) * 0.5f + 0.5f;
    Cell k = worley(along * 3, across * 6, 3, seed + 7, 0.8f);
    knot = idf(k.id, 0) < 0.25f ? sstep(0.35f, 0.05f, k.f1) : 0.0f;
    return saturate(0.55f + 0.25f * ring + 0.25f * (fibre - 0.5f) + 0.2f * warp);
}

void genCrate(float u, float v, Texel& o) {
    const float b = 0.13f;
    bool frame = u < b || u > 1 - b || v < b || v > 1 - b;
    float dd = std::fabs(u - v) * 0.70710678f;
    bool brace = !frame && dd < 0.07f;
    vec3 light{0.70f, 0.53f, 0.33f}, dark{0.42f, 0.29f, 0.17f};
    vec3 wood;
    float h, knot = 0;
    float dirt = sstep(-0.1f, 0.5f, fbm(u, v, 4, 3, 50));
    if (frame) {
        bool vertical = u < b || u > 1 - b;
        float along = vertical ? v : u, across = vertical ? u : v;
        float g = woodGrain(along, across, vertical ? 51 : 52, knot);
        float a = vertical ? u : v;
        float edge = a < b ? std::min(a, b - a) : std::min(1 - a, a - (1 - b));
        h = 0.8f + 0.2f * sstep(0.0f, 0.015f, edge);
        wood = mix3(dark, light, g) * (1.0f + 0.12f * sstep(0.012f, 0.0f, edge));  // worn bright edges
    } else if (brace) {
        float g = woodGrain((u + v) * 0.7071f, (u - v) * 0.7071f, 53, knot);
        h = 0.7f + 0.2f * sstep(0.0f, 0.012f, 0.07f - dd);
        wood = mix3(dark, light, g) * 0.97f;
    } else {
        const int planks = 5;
        float pu = (u - b) / (1 - 2 * b) * planks;
        int pi = std::min((int)pu, planks - 1);
        float pf = pu - pi;
        float gap = std::min(pf, 1 - pf);
        float g = woodGrain(v + pi * 0.37f, u * 3.0f + pi, 54 + pi, knot);
        h = 0.35f + 0.25f * sstep(0.02f, 0.05f, gap);
        wood = mix3(dark, light, g) * (0.84f + 0.16f * h2f(pi, 0, 55));
        if (gap < 0.02f) wood = wood * 0.35f;
    }
    wood = mix3(wood, wood * vec3(0.55f, 0.45f, 0.36f), knot * 0.8f);
    wood = mix3(wood, desat(wood, 0.4f) * 0.75f, dirt * 0.25f);
    const float nb = b * 0.5f;
    const float nails[8][2] = {{nb, nb}, {1 - nb, nb}, {nb, 1 - nb}, {1 - nb, 1 - nb}, {0.5f, nb}, {0.5f, 1 - nb}, {nb, 0.5f}, {1 - nb, 0.5f}};
    float nail = 0, rust = 0;
    for (auto& nl : nails) {
        float d = std::hypot(u - nl[0], v - nl[1]);
        nail = std::max(nail, sstep(0.013f, 0.009f, d));
        rust = std::max(rust, sstep(0.035f, 0.012f, d) * (v < nl[1] ? 1.0f : 0.4f));
    }
    wood = mix3(wood, wood * vec3(0.7f, 0.5f, 0.35f), rust * 0.35f);
    o.col = mix3(wood, vec3(0.30f, 0.27f, 0.24f), nail);
    o.h = h + nail * 0.05f - knot * 0.03f;
    o.metal = nail * 0.8f;
    o.rough = lerpf(0.78f + 0.1f * dirt, 0.45f, nail);
}

void genDoor(float u, float v, Texel& o) {
    const int planks = 6;
    float pu = u * planks;
    int pi = (int)std::floor(pu);
    float pf = pu - pi;
    float gap = std::min(pf, 1 - pf);
    float knot;
    float g = woodGrain(v, u * planks + pi * 0.3f, 61 + noise::wrapi(pi, planks), knot);
    vec3 woodCol = mix3({0.36f, 0.26f, 0.16f}, {0.56f, 0.42f, 0.27f}, g);
    float peelN = fbm(u, v, 6, 5, 62);
    float peeled = sstep(0.16f, 0.2f, peelN);
    float peelEdge = sstep(0.12f, 0.16f, peelN) * (1 - peeled);
    vec3 paint = mix3({0.17f, 0.35f, 0.44f}, {0.26f, 0.46f, 0.55f}, 0.5f + fbm(u, v, 3, 3, 63)) * (0.95f + 0.08f * g);
    paint = mix3(paint, desat(paint, 0.4f) * 1.1f, sstep(0.0f, 0.5f, fbm(u, v, 4, 3, 65)) * 0.4f);  // sun-faded
    float h = 0.4f + 0.3f * sstep(0.015f, 0.035f, gap) + (1 - peeled) * 0.05f + peelEdge * 0.02f;
    vec3 col = mix3(paint * (1 - peelEdge * 0.25f), woodCol, peeled);
    float rough = lerpf(0.55f, 0.85f, peeled), metal = 0;
    if (gap < 0.012f) col = col * 0.35f;
    bool band = (v > 0.12f && v < 0.20f) || (v > 0.80f && v < 0.88f);
    if (band) {
        float rustN = sstep(-0.1f, 0.4f, fbm(u, v, 16, 3, 64));
        col = mix3(vec3(0.20f, 0.18f, 0.16f), vec3(0.42f, 0.24f, 0.12f), rustN * 0.8f);
        metal = lerpf(0.8f, 0.1f, rustN);
        rough = lerpf(0.5f, 0.9f, rustN);
        h = 0.85f;
        float ru = u * 12 - std::floor(u * 12);
        float bc = v < 0.5f ? 0.16f : 0.84f;
        float d = std::hypot((ru - 0.5f) / 12.0f, v - bc);
        if (d < 0.012f) {
            h = 0.85f + 0.1f * std::sqrt(1 - (d / 0.012f) * (d / 0.012f));
            col = {0.30f, 0.27f, 0.24f};
        }
    }
    o.col = col;
    o.h = h;
    o.rough = rough;
    o.metal = metal;
}

// Painted steel panels with seams, rivets, scratches to bare metal and rust streaks.
void genMetal(float u, float v, Texel& o) {
    float pu = u * 2, pv = v * 2;
    float fu = pu - std::floor(pu), fv = pv - std::floor(pv);
    float e = std::min(std::min(fu, 1 - fu), std::min(fv, 1 - fv)) * 0.5f;
    float seam = sstep(0.003f, 0.008f, e);
    float n = fbm(u, v, 4, 5, 71);
    float rv;
    {
        float ru = fu * 8 - std::floor(fu * 8), rvv = fv * 8 - std::floor(fv * 8);
        float dEdgeU = std::min(fu, 1 - fu), dEdgeV = std::min(fv, 1 - fv);
        float d1 = dEdgeU < 0.04f ? std::hypot(dEdgeU - 0.022f, (rvv - 0.5f) / 8.0f) : 1.0f;
        float d2 = dEdgeV < 0.04f ? std::hypot(dEdgeV - 0.022f, (ru - 0.5f) / 8.0f) : 1.0f;
        float d = std::min(d1, d2);
        rv = d < 0.01f ? std::sqrt(1 - (d / 0.01f) * (d / 0.01f)) : 0.0f;
    }
    float scratch = sstep(0.55f, 0.75f, ridged(u, v * 0.25f, 12, 2, 72)) * sstep(0.0f, 0.4f, fbm(u, v, 3, 2, 73));
    float drip = sstep(0.1f, 0.7f, fbmA(u, v, 20, 2, 3, 74)) * sstep(0.35f, 0.0f, fv);  // streaks under seams
    float rust = saturate(sstep(0.2f, 0.34f, fbm(u, v, 8, 4, 75)) + drip * 0.6f + (1 - seam) * 0.5f);
    vec3 paint = mix3({0.36f, 0.42f, 0.38f}, {0.46f, 0.52f, 0.46f}, 0.5f + n) * (0.96f + 0.06f * gnoise(u * 128, v * 128, 128, 128, 76));
    vec3 rustCol = mix3({0.36f, 0.19f, 0.09f}, {0.56f, 0.32f, 0.15f}, 0.5f + fbm(u, v, 32, 2, 77));
    vec3 c = mix3(paint, vec3(0.56f, 0.56f, 0.55f), scratch);
    c = mix3(c, rustCol, rust * 0.75f);
    c = c * lerpf(0.55f, 1.0f, seam);
    o.col = c;
    o.h = 0.5f + seam * 0.2f + rv * 0.12f + rust * 0.03f * fbm(u, v, 48, 2, 78) + n * 0.02f - scratch * 0.01f;
    o.rough = lerpf(lerpf(0.45f, 0.3f, scratch), 0.92f, rust);
    o.metal = lerpf(lerpf(0.05f, 1.0f, scratch), 0.0f, rust);
}

// Cast concrete: formwork seams, tie holes, pores, exposed aggregate, efflorescence and water stains. Tile = 256 units.
void genConcrete(float u, float v, Texel& o) {
    float n = fbm(u, v, 3, 5, 81);
    float fine = gnoise(u * 256, v * 256, 256, 256, 82) * 0.6f + gnoise(u * 512, v * 512, 512, 512, 83) * 0.4f;
    float fine2 = gnoise(u * 1024, v * 1024, 1024, 1024, 171);
    Cell c = worley(u * 90, v * 90, 90, 84, 0.9f);
    float pore = idf(c.id, 0) < 0.12f ? sstep(0.25f, 0.1f, c.f1) : 0.0f;
    Cell c2 = worley(u * 200, v * 200, 200, 172, 0.9f);
    float pore2 = idf(c2.id, 0) < 0.15f ? sstep(0.3f, 0.12f, c2.f1) * wfade(200) : 0.0f;
    Cell ag = worley(u * 140, v * 140, 140, 85, 0.9f);
    float aggregate = idf(ag.id, 0) < 0.3f ? sstep(0.35f, 0.25f, ag.f1) * (idf(ag.id, 8) - 0.5f) : 0.0f;
    float seamV = std::min(std::fabs(v - 0.5f), std::min(v, 1 - v));
    float seamU = std::min(u, 1 - u);
    float line = 1 - sstep(0.001f, 0.004f, std::min(seamV, seamU));
    // Cement paste bled out along the formwork joints.
    float fin = sstep(0.012f, 0.004f, std::min(seamV, seamU)) * (1 - line) * sstep(-0.1f, 0.3f, fbm(u, v, 30, 2, 173));
    float tie = 0;
    for (float tu : {0.25f, 0.75f})
        for (float tv : {0.25f, 0.75f}) tie = std::max(tie, sstep(0.012f, 0.008f, std::hypot(u - tu, v - tv)));
    float stain = sstep(0.0f, 0.5f, fbmA(u, v, 16, 2, 3, 86)) * sstep(-0.2f, 0.4f, fbm(u, v, 2, 2, 87));
    float efflo = sstep(0.25f, 0.5f, fbm(u, v, 7, 4, 174)) * sstep(0.0f, 0.4f, fbmA(u, v, 10, 3, 2, 175));
    // Formwork board imprint: faint horizontal wood grain bands.
    float boards = std::sin((v * 16.0f + fbm(u, v, 4, 2, 176) * 0.4f) * kTwoPi) * 0.5f + fbmA(u, v, 3, 60, 2, 177) * 0.5f;
    vec3 col = mix3({0.56f, 0.55f, 0.52f}, {0.69f, 0.67f, 0.63f}, 0.5f + n * 1.2f) * (0.95f + 0.07f * fine + 0.03f * fine2);
    col = mix3(col, col * vec3(1.03f, 1.0f, 0.95f), sstep(0.1f, 0.5f, fbm(u, v, 5, 3, 178)) * 0.4f);  // warmer pours
    col = col * (1.0f + aggregate * 0.3f) * (1.0f + 0.02f * boards);
    col = mix3(col, col * vec3(0.82f, 0.80f, 0.77f), stain * 0.45f);
    col = mix3(col, vec3(0.80f, 0.79f, 0.76f), efflo * 0.3f);
    o.col = col * (1 - pore * 0.5f - pore2 * 0.3f) * (1 - line * 0.18f) * (1 - tie * 0.6f) * (1 + fin * 0.05f);
    o.h = 0.6f + fine * 0.03f + fine2 * 0.008f + n * 0.03f - pore * 0.12f - pore2 * 0.05f - line * 0.06f - tie * 0.15f + aggregate * 0.025f +
          fin * 0.02f + boards * 0.006f;
    o.rough = 0.88f + 0.06f * fine - efflo * 0.02f;
}

// Limestone trim, curbs and ceilings: chisel texture, chipped edges, fossil pits, dirt and water stains.
void genTrim(float u, float v, Texel& o) {
    float n = fbm(u, v, 4, 4, 91);
    float fine = gnoise(u * 256, v * 256, 256, 256, 92) * 0.6f + gnoise(u * 512, v * 512, 512, 512, 95) * 0.4f;
    float fine2 = gnoise(u * 1024, v * 1024, 1024, 1024, 191);
    float band = 0.5f + 0.5f * std::sin(v * kTwoPi * 8);
    float chisel = gnoise(u * 24, v * 96, 24, 96, 93);
    float chisel2 = gnoise(u * 48, v * 192, 48, 192, 192);
    float stain = sstep(-0.1f, 0.45f, fbm(u, v, 5, 3, 94));
    float streak = sstep(0.0f, 0.6f, fbmA(u, v, 20, 2, 3, 96));
    Cell pits = worley(u * 48, v * 48, 48, 97, 0.9f);
    float pit = idf(pits.id, 0) < 0.14f ? sstep(0.25f, 0.08f, pits.f1) : 0.0f;
    Cell pits2 = worley(u * 120, v * 120, 120, 193, 0.9f);
    float pit2 = idf(pits2.id, 0) < 0.12f ? sstep(0.28f, 0.1f, pits2.f1) * wfade(120) : 0.0f;
    float chip = sstep(0.3f, 0.45f, fbm(u, v, 10, 4, 194));  // broken-off flakes
    vec3 c = mix3({0.54f, 0.46f, 0.36f}, {0.66f, 0.57f, 0.45f}, 0.5f + n * 1.3f) * (0.93f + 0.1f * fine + 0.03f * fine2);
    c = mix3(c, c * vec3(1.04f, 0.93f, 0.82f), sstep(0.2f, 0.5f, fbm(u, v, 6, 3, 195)) * 0.4f);  // iron staining
    c = mix3(c, c * vec3(0.78f, 0.72f, 0.66f), stain * 0.45f + streak * 0.2f);
    c = mix3(c, c * 1.1f, chip * 0.6f);  // fresh broken stone is lighter
    c = c * (1.0f - pit * 0.3f - pit2 * 0.18f) * (1.0f + 0.18f * speckle(u, v, 200, 0.18f, 0.3f, 196));
    o.col = c;
    o.h = 0.5f + fine * 0.03f + fine2 * 0.008f + band * 0.02f + chisel * 0.025f + chisel2 * 0.01f + n * 0.03f - pit * 0.08f - pit2 * 0.04f -
          chip * 0.05f;
    o.rough = 0.86f + 0.06f * stain;
}

// Clay bricks with per-brick colour, fire flashing, chipped edges, efflorescence and recessed mortar.
void genBrick(float u, float v, Texel& o) {
    const int rows = 8, cols = 4;
    float fr = v * rows;
    int row = (int)std::floor(fr);
    float rv = fr - row;
    float fc = u * cols + (row & 1) * 0.5f;
    int col = (int)std::floor(fc);
    float cu = fc - col;
    float n = fbm(u, v, 16, 3, 101);
    float ex = std::min(cu, 1 - cu) / cols, ey = std::min(rv, 1 - rv) / rows;
    float e = std::min(ex, ey);
    float chip = std::max(0.0f, fbm(u, v, 32, 2, 104));
    float cornerChip = sstep(0.02f, 0.0f, std::max(ex, ey)) * 0.006f * (0.3f + std::max(0.0f, fbm(u, v, 24, 2, 107)) * 3.0f);
    float face = sstep(0.005f + chip * 0.007f + cornerChip, 0.010f + chip * 0.007f + cornerChip, e + n * 0.0015f);
    float faceRound = sstep(0.0f, 0.02f, e);
    uint32_t id = h2(noise::wrapi(col, cols), noise::wrapi(row, rows), 102);
    vec3 b = mix3({0.50f, 0.23f, 0.15f}, {0.68f, 0.35f, 0.23f}, idf(id, 0));
    if (idf(id, 8) < 0.15f) b = b * 0.6f;                                  // over-fired dark brick
    else if (idf(id, 8) > 0.9f) b = mix3(b, {0.76f, 0.55f, 0.40f}, 0.5f);  // pale brick
    float fine = gnoise(u * 256, v * 256, 256, 256, 103);
    float fine2 = gnoise(u * 512, v * 512, 512, 512, 108);
    // Fire flashing: darker gradient toward one end of the brick.
    float flash = idf(id, 16) < 0.35f ? sstep(0.4f, 1.0f, idf(id, 20) < 0.5f ? cu : 1 - cu) : 0.0f;
    b = mix3(b, b * vec3(0.55f, 0.5f, 0.52f), flash * 0.5f);
    b = b * (0.9f + 0.12f * fbm(u, v, 24, 2, 105)) * (0.95f + 0.06f * fine + 0.03f * fine2);
    b = b * (1.0f + 0.22f * speckle(u, v, 180, 0.25f, 0.3f, 109));  // sand/grog inclusions
    Cell ps = worley(u * 96, v * 96, 96, 110, 0.9f);
    float pore = idf(ps.id, 0) < 0.1f ? sstep(0.25f, 0.08f, ps.f1) * wfade(96) : 0.0f;
    b = b * (1.0f - pore * 0.3f);
    b = mix3(b, b * 0.7f, sstep(0.1f, 0.6f, fbm(u, v, 3, 3, 106)) * 0.4f);  // soot
    float efflo = sstep(0.3f, 0.55f, fbm(u, v, 6, 4, 111)) * sstep(0.02f, 0.0f, e + 0.01f * fbm(u, v, 40, 2, 112));
    vec3 mortar = vec3(0.66f, 0.63f, 0.57f) * (0.86f + 0.14f * fine) * (1.0f + 0.3f * speckle(u, v, 300, 0.35f, 0.35f, 113));
    o.col = mix3(mix3(mortar, b, face), vec3(0.78f, 0.76f, 0.72f), efflo * 0.4f);
    o.h = 0.3f + face * (0.40f + 0.06f * faceRound) + n * 0.03f + fine * 0.015f + fine2 * 0.006f - pore * 0.03f;
    o.rough = lerpf(0.95f, 0.82f, face);
}

// Corrugated container steel (white base, tinted per brush): ribs, dents, scratches, rust.
void genCorrugated(float u, float v, Texel& o) {
    float w = u * 16;
    float f = w - std::floor(w);
    float prof = sstep(0.1f, 0.25f, f) * (1 - sstep(0.6f, 0.75f, f));
    float n = fbm(u, v, 4, 4, 111);
    float dent = fbm(u, v, 6, 3, 114) * 0.06f;
    float rustEdge = sstep(0.25f, 0.0f, v) + sstep(0.85f, 1.0f, v) * 0.5f;
    float rust = saturate(sstep(0.24f, 0.36f, fbm(u, v, 8, 5, 112)) + rustEdge * 0.6f * sstep(-0.3f, 0.3f, fbm(u, v, 12, 3, 115)));
    float scratch = sstep(0.62f, 0.8f, ridged(u, v * 0.2f, 10, 2, 113));
    float streak = sstep(0.1f, 0.8f, fbmA(u, v, 32, 2, 3, 116)) * 0.3f;
    vec3 paint = vec3(0.86f) * (0.93f + 0.08f * n) * (1 - streak * 0.25f);
    vec3 c = mix3(paint, {0.60f, 0.60f, 0.60f}, scratch * 0.7f);
    c = mix3(c, {0.42f, 0.25f, 0.14f}, rust * 0.65f);
    o.col = c;
    o.h = 0.3f + prof * 0.5f + dent;
    o.rough = lerpf(lerpf(0.5f, 0.35f, scratch), 0.9f, rust);
    o.metal = lerpf(lerpf(0.1f, 0.9f, scratch), 0.0f, rust);
}

// Rounded cobblestones of mixed rock bedded in sand with grit and small pebbles.
void genCobble(float u, float v, Texel& o) {
    float warp = fbm(u, v, 8, 2, 120) * 0.25f;
    Cell c = worley(u * 10 + warp, v * 10 - warp, 10, 121, 0.75f);
    float gapW = 0.05f + 0.03f * fbm(u, v, 24, 2, 123);
    float face = sstep(gapW, gapW + 0.1f, c.f2 - c.f1);
    float dome = saturate(1 - c.f1 * 1.25f);
    float fine = gnoise(u * 256, v * 256, 256, 256, 124);
    float fine2 = gnoise(u * 512, v * 512, 512, 512, 125);
    float kind = idf(c.id, 8);
    vec3 stone = mix3({0.54f, 0.50f, 0.45f}, {0.74f, 0.68f, 0.58f}, idf(c.id, 0));
    if (kind < 0.2f) stone = mix3(stone, {0.62f, 0.50f, 0.40f}, 0.5f);        // iron-rich sandstone
    else if (kind < 0.35f) stone = mix3(stone, {0.50f, 0.49f, 0.48f}, 0.55f);  // grey granite
    else if (kind > 0.9f) stone = mix3(stone, {0.78f, 0.74f, 0.68f}, 0.5f);   // pale limestone
    stone = stone * (0.92f + 0.12f * fbm(u, v, 32, 2, 122)) * (0.95f + 0.06f * fine + 0.03f * fine2);
    // Granite gets salt-and-pepper mineral grains, the rest fine speckles.
    float sp = speckle(u, v, 240, kind >= 0.2f && kind < 0.35f ? 0.55f : 0.15f, 0.33f, 126);
    stone = stone * (1.0f + 0.3f * sp);
    float polish = dome * dome;
    // Worn tops are lighter and smoother, the sides near the joints dirtier.
    stone = mix3(stone * vec3(0.82f, 0.78f, 0.72f), stone * 1.05f, sstep(0.1f, 0.6f, dome));
    float cr = ridged(u + idf(c.id, 4), v, 12, 2, 127);
    float crack = idf(c.id, 16) < 0.2f ? sstep(0.95f, 0.99f, cr) * face : 0.0f;
    vec3 sand = vec3(0.72f, 0.60f, 0.44f) * (0.88f + 0.16f * fine) * (1.0f + 0.35f * speckle(u, v, 160, 0.3f, 0.35f, 128));
    // Grit pebbles in the joints.
    Cell g = worley(u * 70, v * 70, 70, 129, 0.9f);
    float grit = idf(g.id, 0) < 0.3f ? sstep(0.3f, 0.15f, g.f1) * wfade(70) : 0.0f;
    sand = mix3(sand, vec3(0.58f, 0.54f, 0.48f) * (0.8f + 0.4f * idf(g.id, 8)), grit * 0.8f);
    o.col = mix3(sand, stone * (1.0f + polish * 0.06f) * (1.0f - crack * 0.35f), face);
    o.h = 0.25f + face * (0.3f + dome * 0.35f - crack * 0.04f) + (1 - face) * grit * 0.05f + fine * 0.015f + fine2 * 0.005f;
    o.rough = lerpf(0.96f, 0.78f - polish * 0.15f, face);
}

// ---- Close-up detail layers --------------------------------------------------------------------------------------
// Each layer is a tileable height (normal map), an albedo modulation and a roughness modulation. The shader blends
// two scales of it over the base material near the camera, so surfaces keep resolving detail when you walk up to them.
struct DTexel {
    float h = 0.0f;  // height
    float a = 0.0f;  // albedo modulation -1..1
    float r = 0.0f;  // roughness modulation -1..1
};
using DetFn = void (*)(float u, float v, DTexel& o);

// Sand grains, grit and tiny gravel.
void detSand(float u, float v, DTexel& o) {
    Cell g = worley(u * 64, v * 64, 64, 301, 0.95f);
    float grain = sstep(0.55f, 0.1f, g.f1);
    Cell g2 = worley(u * 150, v * 150, 150, 302, 0.95f);
    float grain2 = sstep(0.6f, 0.15f, g2.f1);
    Cell p = worley(u * 20, v * 20, 20, 303, 0.9f);
    float peb = idf(p.id, 0) < 0.18f ? std::sqrt(std::max(0.0f, 1 - (p.f1 / (0.3f + 0.15f * idf(p.id, 8))) * (p.f1 / (0.3f + 0.15f * idf(p.id, 8))))) : 0.0f;
    float n = gnoise(u * 32, v * 32, 32, 32, 304);
    o.h = grain * (0.4f + 0.6f * idf(g.id, 4)) * 0.5f + grain2 * 0.3f + peb * 0.8f + n * 0.15f;
    o.a = (idf(g.id, 8) - 0.5f) * 0.5f * grain + (idf(g2.id, 8) - 0.5f) * 0.4f * grain2 + (peb > 0 ? (idf(p.id, 16) - 0.5f) * 0.8f : 0.0f) +
          (idf(g.id, 12) < 0.06f ? -0.8f * grain : 0.0f);
    o.r = peb > 0 ? -0.5f : (idf(g.id, 20) < 0.04f ? -0.8f * grain : 0.1f);  // occasional glinting quartz grain
}

// Stucco: knock-down blobs, trowel ridges, pinholes and hairline crazing.
void detPlaster(float u, float v, DTexel& o) {
    Cell b = worley(u * 12 + fbm(u, v, 8, 2, 311) * 0.4f, v * 12, 12, 312, 0.9f);
    float blob = sstep(0.55f, 0.2f, b.f1) * (0.5f + 0.5f * idf(b.id, 0));
    float n1 = fbm(u, v, 16, 4, 313);
    float n2 = gnoise(u * 128, v * 128, 128, 128, 314);
    Cell ph = worley(u * 48, v * 48, 48, 315, 0.9f);
    float pin = idf(ph.id, 0) < 0.12f ? sstep(0.22f, 0.06f, ph.f1) : 0.0f;
    float craze = sstep(0.9f, 0.97f, ridged(u, v, 8, 2, 316)) * sstep(0.0f, 0.3f, fbm(u, v, 4, 2, 317));
    o.h = blob * 0.5f + n1 * 0.35f + n2 * 0.12f - pin * 0.6f - craze * 0.3f;
    o.a = blob * 0.12f + n1 * 0.2f - pin * 0.6f - craze * 0.4f;
    o.r = -blob * 0.15f + pin * 0.3f;
}

// Stone: grains, micro pits, mineral specks, tool marks.
void detStone(float u, float v, DTexel& o) {
    float n1 = fbm(u, v, 8, 4, 321);
    float n2 = gnoise(u * 96, v * 96, 96, 96, 322) * 0.6f + gnoise(u * 192, v * 192, 192, 192, 323) * 0.4f;
    Cell pt = worley(u * 40, v * 40, 40, 324, 0.9f);
    float pit = idf(pt.id, 0) < 0.15f ? sstep(0.3f, 0.08f, pt.f1) : 0.0f;
    float sp = speckle(u, v, 90, 0.35f, 0.35f, 325);
    float tool = gnoise(u * 6, v * 40, 6, 40, 326) * sstep(0.0f, 0.4f, fbm(u, v, 3, 2, 327));
    float crack = sstep(0.93f, 0.985f, ridged(u, v, 6, 2, 328));
    o.h = n1 * 0.4f + n2 * 0.25f - pit * 0.6f + tool * 0.15f - crack * 0.3f;
    o.a = n1 * 0.25f + sp * 0.5f - pit * 0.4f - crack * 0.4f;
    o.r = n2 * 0.2f + pit * 0.2f - (sp > 0.3f ? 0.3f : 0.0f);
}

// Concrete: air voids, sand grains and exposed aggregate.
void detConcrete(float u, float v, DTexel& o) {
    Cell c = worley(u * 36, v * 36, 36, 331, 0.9f);
    float pore = idf(c.id, 0) < 0.22f ? sstep(0.32f, 0.1f, c.f1) : 0.0f;
    Cell c2 = worley(u * 90, v * 90, 90, 332, 0.9f);
    float pore2 = idf(c2.id, 0) < 0.25f ? sstep(0.35f, 0.12f, c2.f1) : 0.0f;
    Cell ag = worley(u * 24, v * 24, 24, 333, 0.8f);
    float agg = idf(ag.id, 0) < 0.35f ? sstep(0.4f, 0.25f, ag.f1) : 0.0f;
    float n = gnoise(u * 128, v * 128, 128, 128, 334) * 0.6f + fbm(u, v, 12, 3, 335) * 0.4f;
    o.h = n * 0.3f + agg * 0.3f - pore * 0.8f - pore2 * 0.4f;
    o.a = n * 0.25f + (agg > 0 ? (idf(ag.id, 8) - 0.5f) * 0.6f * agg : 0.0f) - pore * 0.5f - pore2 * 0.3f;
    o.r = pore * 0.2f - agg * 0.1f;
}

// Wood: fibres and pores along v.
void detWood(float u, float v, DTexel& o) {
    float f = gnoise(u * 96, v * 6, 96, 6, 341) * 0.6f + gnoise(u * 192, v * 12, 192, 12, 342) * 0.4f;
    Cell p = worley(u * 64, v * 8, 64, 343, 0.9f);
    float pore = idf(p.id, 0) < 0.3f ? sstep(0.3f, 0.1f, p.f1) : 0.0f;
    float n = fbm(u, v, 8, 3, 344);
    o.h = f * 0.5f - pore * 0.4f + n * 0.2f;
    o.a = f * 0.3f - pore * 0.3f + n * 0.2f;
    o.r = f * 0.15f + pore * 0.2f;
}

// Painted / bare metal: orange peel, pitting, fine scratches.
void detMetal(float u, float v, DTexel& o) {
    float peel = gnoise(u * 48, v * 48, 48, 48, 351) * 0.6f + gnoise(u * 96, v * 96, 96, 96, 352) * 0.4f;
    Cell p = worley(u * 40, v * 40, 40, 353, 0.9f);
    float pit = idf(p.id, 0) < 0.08f ? sstep(0.25f, 0.06f, p.f1) : 0.0f;
    float s1 = sstep(0.9f, 0.985f, ridged(u, v * 0.15f, 16, 2, 354));
    float s2 = sstep(0.92f, 0.99f, ridged(v, u * 0.2f + 0.3f, 12, 2, 355));
    float scratch = std::max(s1, s2) * sstep(0.0f, 0.3f, fbm(u, v, 4, 2, 356));
    o.h = peel * 0.2f - pit * 0.6f - scratch * 0.25f;
    o.a = peel * 0.1f - pit * 0.5f + scratch * 0.5f;
    o.r = -scratch * 0.6f + pit * 0.4f + peel * 0.08f;
}

const DetFn kDetail[DET_COUNT] = {detSand, detPlaster, detStone, detConcrete, detWood, detMetal};
const float kDetailBump[DET_COUNT] = {2.2f, 1.6f, 1.8f, 2.0f, 1.2f, 0.9f};

void generateDetailLayer(int d, int size, std::vector<uint8_t>& out) {
    std::vector<DTexel> t((size_t)size * size);
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) kDetail[d]((x + 0.5f) / size, (y + 0.5f) / size, t[(size_t)y * size + x]);
    out.resize((size_t)size * size * 4);
    auto h = [&](int x, int y) { return t[(size_t)((y + size) % size) * size + ((x + size) % size)].h; };
    auto b = [](float f) { return (uint8_t)(saturate(f) * 255.0f + 0.5f); };
    const float bump = kDetailBump[d] * (size / 512.0f);
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) {
            size_t i = (size_t)y * size + x;
            float dx = (h(x + 1, y - 1) + 2 * h(x + 1, y) + h(x + 1, y + 1) - h(x - 1, y - 1) - 2 * h(x - 1, y) - h(x - 1, y + 1)) * 0.25f * bump;
            float dy = (h(x - 1, y + 1) + 2 * h(x, y + 1) + h(x + 1, y + 1) - h(x - 1, y - 1) - 2 * h(x, y - 1) - h(x + 1, y - 1)) * 0.25f * bump;
            vec3 n = normalize(vec3(-dx, -dy, 1.0f));
            out[i * 4 + 0] = b(n.x * 0.5f + 0.5f);
            out[i * 4 + 1] = b(n.y * 0.5f + 0.5f);
            out[i * 4 + 2] = b(t[i].a * 0.5f + 0.5f);
            out[i * 4 + 3] = b(t[i].r * 0.5f + 0.5f);
        }
}

const GenFn kGenerators[MAT_COUNT] = {genSand, genSandstone, genPlaster, genTiles, genCrate, genDoor,
                                      genMetal, genConcrete, genTrim, genBrick, genCorrugated, genCobble};

// name, surface, bump, avgAlbedo, uvScale, antiTile, macro, grime, parallax depth, detail layer, detail strength, detail scale
MaterialInfo g_info[MAT_COUNT] = {
    {"sand", SURF_SAND, 3.4f, {}, 0.5f, 1.0f, 1.0f, 0.6f, 0.0f, DET_SAND, 1.0f, 8.0f},
    {"sandstone", SURF_STONE, 5.5f, {}, 1.0f, 0.0f, 0.7f, 1.0f, 2.6f, DET_STONE, 0.8f, 4.0f},
    {"plaster", SURF_STONE, 3.4f, {}, 0.5f, 1.0f, 1.0f, 1.0f, 0.0f, DET_PLASTER, 1.0f, 8.0f},
    {"tiles", SURF_STONE, 5.0f, {}, 1.0f, 0.0f, 0.8f, 0.8f, 1.3f, DET_STONE, 0.6f, 4.0f},
    {"crate", SURF_WOOD, 5.0f, {}, 1.0f, 0.0f, 0.5f, 0.5f, 1.4f, DET_WOOD, 0.5f, 3.0f},
    {"door", SURF_WOOD, 4.0f, {}, 1.0f, 0.0f, 0.3f, 0.6f, 0.9f, DET_WOOD, 0.5f, 3.0f},
    {"metal", SURF_METAL, 3.0f, {}, 1.0f, 0.0f, 0.5f, 0.8f, 0.5f, DET_METAL, 0.6f, 4.0f},
    {"concrete", SURF_CONCRETE, 3.4f, {}, 0.5f, 1.0f, 0.8f, 1.0f, 0.0f, DET_CONCRETE, 1.0f, 8.0f},
    {"trim", SURF_STONE, 3.0f, {}, 1.0f, 0.0f, 0.6f, 0.8f, 0.9f, DET_STONE, 0.8f, 4.0f},
    {"brick", SURF_STONE, 5.0f, {}, 1.0f, 0.0f, 0.6f, 0.8f, 1.8f, DET_STONE, 0.7f, 4.0f},
    {"corrugated", SURF_METAL, 6.0f, {}, 1.0f, 0.0f, 0.4f, 0.6f, 1.6f, DET_METAL, 0.5f, 4.0f},
    {"cobble", SURF_STONE, 6.0f, {}, 0.75f, 0.0f, 0.8f, 0.8f, 3.2f, DET_STONE, 0.7f, 5.0f},
};

struct GenJob {
    int size = 0;
    std::vector<Texel> tex;
    std::vector<float> height;
};

void generateRows(int m, GenJob& job, int y0, int y1) {
    const int size = job.size;
    for (int y = y0; y < y1; y++)
        for (int x = 0; x < size; x++) {
            Texel t;
            kGenerators[m]((x + 0.5f) / size, (y + 0.5f) / size, t);
            job.tex[(size_t)y * size + x] = t;
            job.height[(size_t)y * size + x] = t.h;
        }
}

void finishMaterial(int m, GenJob& job, std::vector<uint8_t>& alb, std::vector<uint8_t>& nrm, std::vector<uint8_t>& hgt) {
    const int size = job.size;
    const std::vector<float>& height = job.height;
    // Local average of height for the cavity term (radius scales with resolution).
    const int R = std::max(2, 3 * size / 512);
    std::vector<float> tmp(height.size()), blur(height.size());
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) {
            float s = 0;
            for (int k = -R; k <= R; k++) s += height[(size_t)y * size + ((x + k + size) % size)];
            tmp[(size_t)y * size + x] = s / (2 * R + 1);
        }
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) {
            float s = 0;
            for (int k = -R; k <= R; k++) s += tmp[(size_t)((y + k + size) % size) * size + x];
            blur[(size_t)y * size + x] = s / (2 * R + 1);
        }
    alb.resize((size_t)size * size * 4);
    nrm.resize((size_t)size * size * 4);
    // Height for parallax occlusion mapping, normalized to the full 0..1 range of this material (1 = top surface).
    {
        float hmin = 1e30f, hmax = -1e30f;
        for (float hv : height) { hmin = std::min(hmin, hv); hmax = std::max(hmax, hv); }
        float inv = 1.0f / std::max(hmax - hmin, 1e-4f);
        hgt.resize((size_t)size * size);
        for (size_t i = 0; i < height.size(); i++) hgt[i] = (uint8_t)(saturate((height[i] - hmin) * inv) * 255.0f + 0.5f);
    }
    const float bump = g_info[m].bump * (size / 512.0f);
    double sum[3] = {0, 0, 0};
    auto h = [&](int x, int y) { return height[(size_t)((y + size) % size) * size + ((x + size) % size)]; };
    auto b = [](float f) { return (uint8_t)(saturate(f) * 255.0f + 0.5f); };
    for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++) {
            size_t i = (size_t)y * size + x;
            const Texel& t = job.tex[i];
            // Sobel gradient gives smoother normals than central differences.
            float dx = (h(x + 1, y - 1) + 2 * h(x + 1, y) + h(x + 1, y + 1) - h(x - 1, y - 1) - 2 * h(x - 1, y) - h(x - 1, y + 1)) * 0.25f * bump;
            float dy = (h(x - 1, y + 1) + 2 * h(x, y + 1) + h(x + 1, y + 1) - h(x - 1, y - 1) - 2 * h(x, y - 1) - h(x + 1, y - 1)) * 0.25f * bump;
            vec3 n = normalize(vec3(-dx, -dy, 1.0f));
            float cavity = saturate(1.0f - std::max(0.0f, blur[i] - height[i]) * 3.5f);
            alb[i * 4 + 0] = b(t.col.x);
            alb[i * 4 + 1] = b(t.col.y);
            alb[i * 4 + 2] = b(t.col.z);
            alb[i * 4 + 3] = b(t.rough);
            nrm[i * 4 + 0] = b(n.x * 0.5f + 0.5f);
            nrm[i * 4 + 1] = b(n.y * 0.5f + 0.5f);
            nrm[i * 4 + 2] = b(cavity);
            nrm[i * 4 + 3] = b(t.metal);
            sum[0] += std::pow(saturate(t.col.x), 2.2f);
            sum[1] += std::pow(saturate(t.col.y), 2.2f);
            sum[2] += std::pow(saturate(t.col.z), 2.2f);
        }
    double inv = 1.0 / ((double)size * size);
    g_info[m].avgAlbedo = vec3((float)(sum[0] * inv), (float)(sum[1] * inv), (float)(sum[2] * inv));
}

}  // namespace

MaterialInfo& materialInfo(int m) { return g_info[std::max(0, std::min(m, (int)MAT_COUNT - 1))]; }

int worldTextureSize(int quality) { return quality <= 0 ? 256 : quality == 1 ? 512 : quality == 2 ? 1024 : 2048; }
int worldDetailSize(int quality) { return quality <= 0 ? 256 : quality >= 3 ? 1024 : 512; }

void generateWorldTextures(WorldTextureSet& out, int size) {
    out.size = size;
    g_genSize = size;
    out.albedo.assign(MAT_COUNT, {});
    out.normal.assign(MAT_COUNT, {});
    out.height.assign(MAT_COUNT, {});
    std::vector<GenJob> jobs(MAT_COUNT);
    for (auto& j : jobs) {
        j.size = size;
        j.tex.resize((size_t)size * size);
        j.height.resize((size_t)size * size);
    }
    // Row bands of all materials share one worker pool so the cost spreads over every core.
    const int band = 16;
    const int bandsPer = (size + band - 1) / band;
    const int total = bandsPer * MAT_COUNT;
    std::atomic<int> next{0};
    auto worker = [&] {
        for (;;) {
            int k = next.fetch_add(1);
            if (k >= total) break;
            int m = k / bandsPer, y0 = (k % bandsPer) * band;
            generateRows(m, jobs[m], y0, std::min(size, y0 + band));
        }
    };
    int nt = (int)std::max(1u, std::thread::hardware_concurrency());
    std::vector<std::thread> threads;
    for (int t = 0; t < nt; t++) threads.emplace_back(worker);
    for (auto& t : threads) t.join();
    threads.clear();
    std::atomic<int> nextM{0};
    for (int t = 0; t < std::min(nt, (int)MAT_COUNT); t++)
        threads.emplace_back([&] {
            for (;;) {
                int m = nextM.fetch_add(1);
                if (m >= MAT_COUNT) break;
                finishMaterial(m, jobs[m], out.albedo[m], out.normal[m], out.height[m]);
                std::vector<Texel>().swap(jobs[m].tex);
            }
        });
    for (auto& t : threads) t.join();
    // Detail layers (one thread each; they are small).
    int ds = size <= 256 ? 256 : size >= 2048 ? 1024 : 512;
    out.detailSize = ds;
    out.detail.assign(DET_COUNT, {});
    g_genSize = ds;
    threads.clear();
    std::atomic<int> nextD{0};
    for (int t = 0; t < std::min(nt, (int)DET_COUNT); t++)
        threads.emplace_back([&] {
            for (;;) {
                int d = nextD.fetch_add(1);
                if (d >= DET_COUNT) break;
                generateDetailLayer(d, ds, out.detail[d]);
            }
        });
    for (auto& t : threads) t.join();
}
